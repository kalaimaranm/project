/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.demo.filter;

/**
 *
 * @author bas200186
 */
public class Customer
{
    private String name;
    private String address;
    private String phoneNo;
    private String aadharid;

    public Customer() {
    }

    
    public Customer(String name, String address, String phoneNo, String aadharid) {
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
        this.aadharid = aadharid;
   
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getAadharid() {
        return aadharid;
    }

    public void setAadharid(String aadharid) {
        this.aadharid = aadharid;
    }


    

    
}
