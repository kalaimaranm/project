/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.customer;

import com.mordernmart.buisnesslayer.CustomerBuisnessLogicImpl;
import com.mordernmart.buisnesslayer.PaymentBuisnessLogicImpl;
import com.mordernmart.buisnesslayer.ProductsBuisnessLogicImpl;
import com.mordernmart.model.Customer;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 *
 * @author bas200186
 */
public class AcceptPaymentsServlet extends GenericServlet
{
    private  PaymentBuisnessLogicImpl paymentBuisnessLogic;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
    {

     ServletContext a = this.getServletContext();
     this.paymentBuisnessLogic = new PaymentBuisnessLogicImpl(getServletContext().getInitParameter("db"));
     double payment=0.0;
     try{
     payment=Double.parseDouble(request.getParameter("payment"));
     }
     catch(Exception e)
     {
        response.getWriter().print("Enter a Valid Number");

     }
     String phoneNo=request.getParameter("phoneNo");
     if(payment>0&&phoneNo.length()>0)
           {
              boolean value=false;
               
               try 
               {
                   value = paymentBuisnessLogic.addPayment(phoneNo, payment);
               } 
               catch (SQLException ex) 
               {
                   response.getWriter().print("Payment Failed");
               }
               
               
                if (value) 
                {
                   response.getWriter().print("Payment Successfull");
 
                } 
                else
                {
                  
                  response.getWriter().print("Payment Failed");


               }

           } 
          
    }
}
