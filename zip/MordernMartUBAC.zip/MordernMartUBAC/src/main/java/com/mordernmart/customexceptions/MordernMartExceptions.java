
package com.mordernmart.customexceptions;


public class MordernMartExceptions extends Exception
{
   public MordernMartExceptions()
   {
       super();
   }
    

    public MordernMartExceptions(String message) {
        super(message);
    }

    public MordernMartExceptions(String message, Throwable cause) {
        super(message, cause);
    }

    public MordernMartExceptions(Throwable cause) {
        super(cause);
    }

    public MordernMartExceptions(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
  
  
    
}
