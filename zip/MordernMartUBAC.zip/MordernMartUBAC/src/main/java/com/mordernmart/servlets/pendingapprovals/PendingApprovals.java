/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.pendingapprovals;

import com.mordernmart.main.EstablishConnection;
import com.mordernmart.model.Order;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
public class PendingApprovals extends HttpServlet
{
    private List<Order> orderlist=new ArrayList();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp); 
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
       EstablishConnection connection=new EstablishConnection();
        ResultSet set=null;
       try {
         set=  connection.startConnection().createStatement().executeQuery("Select order_id,Customer_ID,total_amount,TotalQuantity,order_date,OrderStatus from Orders where OrderStatus='PENDING'");
        } catch (SQLException ex) {
            Logger.getLogger(PendingApprovals.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            while(set.next())
            {
             int orderid= set.getInt(1);
             int customerid=set.getInt(2);
             double totalamount=set.getDouble(3);
             int quantity=set.getInt(4);
             LocalDate date=set.getDate(5).toLocalDate();
             String approval=set.getString(6);
             orderlist.add(new Order(customerid,orderid,totalamount,quantity,date,approval));
            }
            request.setAttribute("orderlist",orderlist);
               RequestDispatcher rd=request.getRequestDispatcher("ShowPendingOrders.jsp");
                      rd.forward(request,response);
        } catch (SQLException ex) {
            Logger.getLogger(PendingApprovals.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    
}
