/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.main;

import com.mordernmart.buisnesslayer.CustomerBuisnessLogic;
import com.mordernmart.buisnesslayer.CustomerBuisnessLogicImpl;
import com.mordernmart.buisnesslayer.OrderBuisnessLogic;
import com.mordernmart.buisnesslayer.OrderBuisnessLogicImpl;
import com.mordernmart.buisnesslayer.PaymentBuisnessLogic;
import com.mordernmart.buisnesslayer.PaymentBuisnessLogicImpl;
import com.mordernmart.buisnesslayer.ProductsBuisnessLogic;
import com.mordernmart.buisnesslayer.ProductsBuisnessLogicImpl;
import com.mordernmart.customexceptions.MordernMartExceptions;
import com.mordernmart.daointerface.KhataBookDao;
import com.mordernmart.model.Customer;
import com.mordernmart.model.Products;
import com.mordernmart.dao.mysqlimpl.MySqlKhataBookDaoImpl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
public class Menu 
{
  private int input;
    private  BufferedReader sc;
    private KhataBookDao khataBook;
    private GoodsInStock goodsinstock;
    {
        input = 0;
        sc = new BufferedReader(new InputStreamReader(System.in));
        khataBook = new MySqlKhataBookDaoImpl();
        goodsinstock=new GoodsInStock();
    }

    public void mainMenu() throws IOException,  SQLException{
        Statistics statistics=        new Statistics();


        System.out.println("---------------");
        System.out.println("| 1)Customer  |");
        System.out.println("| 2)Inventory |");
        System.out.println("| 3)Statistics|");
        System.out.println("| 4)Exit      |");
        System.out.println("---------------");
        try {
            
            input = Integer.parseInt(sc.readLine());
            switch (input) {
                case 1:
                    try {
                    customerMenu();
                    break;
                } 
                    catch (NumberFormatException m1) {
                    System.out.println("Enter a Valid Number");

                    customerMenu();
                }
                case 2:try {
                    inventoryMenu();
                    break;
                } catch (NumberFormatException m1) {
                    System.out.println("Enter a Valid Number");

                    inventoryMenu();

                }
                case 3:
                    
                    try {
                    statistics.stats();
                    break;
                } 
                catch (NumberFormatException m1) {

                    System.out.println("Enter a Valid Number");

                    statisticsMenu();

                }

                case 4:
                    System.out.println("ThankYou");

                    break;
                default:
                    System.out.println("Please Select From The Below Options");
                    mainMenu();

            }
        } catch (NumberFormatException m1) {
            System.out.println("Enter a Valid Number");
            mainMenu();
        }

    }

    public  void customerMenu() throws IOException,SQLException{

        System.out.println("       Customer Menu ");
        System.out.println("----------------------------");
        System.out.println("|Select 1 To Place Order     |");
        System.out.println("|Select 2 To Accept Payments |");
        System.out.println("|Select 3 To Add Customer    |");
        System.out.println("|Select 4 To View Customer   |");
        System.out.println("|Select 5 To Update Customer |");
        System.out.println("|Select 6 To Soft Delete     |");
        System.out.println("|Select 7 For Mainmenu       |");
        System.out.println("-----------------------------");
        CustomerBuisnessLogic customervalidation = new CustomerBuisnessLogicImpl();
        String phoneNo;
//        CustomerBuisnessLogicImpl.UpdateDetails details;
        try {
            input = Integer.parseInt(sc.readLine());
        } catch (NumberFormatException a) {
            System.out.println("Enter a Valid Number");
            customerMenu();
        }
        switch (input) {
            case 1:
//                OrderBuisnessLogic newOrder = new OrderBuisnessLogicImpl();
//                phoneNo = newOrder.placeOrder();
//                khataBook.getOrderDao().placeOrder(phoneNo);
//                mainMenu();

                break;
            case 2:
//                PaymentBuisnessLogic newPayment = new PaymentBuisnessLogicImpl();
//                phoneNo = newPayment.addPayment();
//                khataBook.getPaymentDao().acceptPayments(phoneNo);
//                mainMenu();

                break;
            case 3:
////                Customer newcustomer = customervalidation.addcustomer();
//                khataBook.getCustomerDao().addCustomer(newcustomer);
//                mainMenu();
//                break;
            case 4:
//                phoneNo = customervalidation.viewCustomer();
//                khataBook.getCustomerDao().viewCustomer(phoneNo);
//                mainMenu();
//                break;
            case 5:
//                details = customervalidation.updateCustomer();
//                khataBook.getCustomerDao().updateCustomer(details);
//                break;
            case 6:
//                phoneNo = customervalidation.deleteCustomer();
//                khataBook.getCustomerDao().deleteCustomer(phoneNo);
//                mainMenu();
//                break;
            case 7:
                mainMenu();
                break;
            default:
                mainMenu();
                break;
        }

    }

    public  void inventoryMenu() throws IOException,  SQLException{

        System.out.println("      Inventory       ");

        System.out.println("------------------------------------------------");
        System.out.println("|1)Goods In Stock                              |");
        System.out.println("|2)Add New Product                             |");
        System.out.println("|3)Increase The Quantity of Existing Product   |");
        System.out.println("|4)Return To MainMenu                          |");
        System.out.println("------------------------------------------------");
        try {
            input = Integer.parseInt(sc.readLine());
        } catch (NumberFormatException a) {
            System.out.println("Enter a Valid Number");
            inventoryMenu();
        }
        ProductsBuisnessLogic buisnessProduct = new ProductsBuisnessLogicImpl();
        switch (input) {
            case 1:
                goodsinstock.stock();
                inventoryMenu();
                break;
            case 2:
//                Products newProduct=null;
//            try {
//                newProduct = buisnessProduct.newProduct();
//            } catch (MordernMartExceptions ex) {
//                Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
//            }
//                if (khataBook.getProductsDao().newProduct(newProduct)) {
//                    System.out.println("Product added Successfully");
//                    mainMenu();
//
//                } else {
//                    System.out.println("Product Not added Successfully");
//                    mainMenu();
//                }
//                break;
            case 3:
//                int a = buisnessProduct.updateProduct();
//                if (khataBook.getProductsDao().updateProduct(a)) {
//                    System.out.println("Updated Successfully");
//                } else {
//                    System.out.println("There is no Product");
//                }
//                mainMenu();
//
//                break;
            case 4:
                mainMenu();
                break;
            default:
                mainMenu();
                break;
        }
    }

    public void statisticsMenu() throws IOException {
    }

    public  void selectioncust() throws IOException, SQLException{

        System.out.println("Press 1 To Go Back To Customer Menu");
        System.out.println("Press 2 To Go Back To Main Menu");

        int selection = Integer.parseInt(sc.readLine());
        if (selection == 1) {
            customerMenu();
        }
        if (selection == 2) {
            mainMenu();
        }
    }

    public  void selectioninventory() throws IOException ,SQLException
    {

        System.out.println("Press 1 To Go Back To Inventory Menu");
        System.out.println("Press 2 To Go Back To Main Menu");

        int selection = Integer.parseInt(sc.readLine());
        if (selection == 1) {
            inventoryMenu();
        }
        if (selection == 2) {
           mainMenu();
        }
    }  
}
