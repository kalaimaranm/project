/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.demo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.apache.catalina.realm.GenericPrincipal;

/**
 *
 * @author bas200186
 */
public class Employee extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Principal name = request.getUserPrincipal();
        GenericPrincipal principal = (GenericPrincipal) name;
        List roles = new ArrayList(Arrays.asList(principal.getRoles()));
        Iterator i = roles.iterator();
        while (i.hasNext()) {
            String a = (String) i.next();
            if (a.equals("Employee")) {
                i.remove();
            }
        }
        String  allroles=roles.toString();
        
        String username = name.getName();
        HttpSession session=request.getSession(false);
        session.setAttribute("roles",allroles);
        session.setAttribute("name",username);
        response.sendRedirect(request.getContextPath() +"/MainMenu.jsp");
//        response.getWriter().println(username+" "+allroles);
//        NameandRoles data=new NameandRoles(username,allroles);
//       response.getWriter().print(session);


//        boolean exp = true;
//        if (request.isUserInRole("Owner")) {
//            exp = false;
//            request.setAttribute("name", username);
//            request.setAttribute("roles", roles);
//            response.sendRedirect(request.getContextPath() + "/owner");
//        }
//
//        if (request.isUserInRole("Manager") && exp == true) {
//            exp = false;
//            request.setAttribute("name", username);
//            request.setAttribute("roles", roles);
//
//            response.sendRedirect(request.getContextPath() + "/manager");
//        }
//        if (request.isUserInRole("FinanceManager") && exp == true) {
//            exp = false;
//
//            request.setAttribute("name", username);
//            request.setAttribute("roles", roles);
//
//            response.sendRedirect(request.getContextPath() + "/financemanager");
//        }
//        if (request.isUserInRole("Cashier") && exp == true) {
//            request.setAttribute("name", username);
//            request.setAttribute("roles", roles);
//
//            response.sendRedirect(request.getContextPath() + "/cashier");
//
//        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);

    }

}
