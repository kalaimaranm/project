/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.dao.mysqlimpl;

import com.mordernmart.buisnesslayer.PaymentBuisnessLogic;
import com.mordernmart.buisnesslayer.PaymentBuisnessLogicImpl;
import com.mordernmart.daointerface.OrderDao;
import com.mordernmart.main.EstablishConnection;
import com.mordernmart.main.GoodsInStock;
import com.mordernmart.model.Lineitem;
import com.mordernmart.model.Order;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author bas200186
 */
public class OrderDaoImpl implements OrderDao {

    private Order newOrder;
    private ResultSet set;
    private int noofproductstobeaddeddinlineitem;
    private int noofproductstobeaddeddinlineitempassed;
    private int id;
    private double totalAmount;
    private int quantity;
    private int count;
    private int requiredquantity;
    private int existingQuantity;
    private double Selling_Price;
    private Connection connect;
    private EstablishConnection connection;
    private GoodsInStock goodsinstock;
    private List<Lineitem> listoflineitems;
    private Lineitem newLineItem;
    private PaymentBuisnessLogic payment;

    {
        id = 0;
        totalAmount = 0;
        quantity = 0;
        count = 0;
        newOrder = null;
        requiredquantity = 0;
        existingQuantity = 0;
        Selling_Price = 0;
        connection = new EstablishConnection();
        goodsinstock = new GoodsInStock();
        noofproductstobeaddeddinlineitem = 0;
        noofproductstobeaddeddinlineitempassed = 0;
        listoflineitems=new ArrayList();
        payment=new PaymentBuisnessLogicImpl("mysql");
    }
   

    @Override
    public boolean placeOrder(List<Lineitem> orderdetails, String phoneNo,String payingoptions,String mainrole) throws SQLException, IOException {
        System.out.println("hii3");
        connect = connection.startConnection();
        set = connect.createStatement().executeQuery("Select Customer_ID,Customer_Status,Remaining_Amount from Customer where Phone_No=" + phoneNo);
        while (set.next()) {
            id = set.getInt(1);
            if (set.getString(2).equals("REMOVED")) {
                System.out.println("hii4");

                return false;
            } 
            else {
                if(set.getDouble(3)<0)
                {
                    return false;
                }

                totalAmount = 0;
                for (Lineitem lineitem : orderdetails) {
                    System.out.println("100");
                    noofproductstobeaddeddinlineitem++;
                    count = 0;
                    set = connect.createStatement().executeQuery("Select Product_Quantity,Selling_Price,Product_Name from Products where Product_ID=" + lineitem.getProduct_id());
                    requiredquantity = lineitem.getProduct_quantity();
                    System.out.println(requiredquantity);
                    while (set.next()) {
                        
                        existingQuantity = set.getInt(1);
                        System.out.println(existingQuantity);
                        Selling_Price = set.getDouble(2);
                        if (existingQuantity < requiredquantity) {
                            System.out.println("hii6");
                            return false;
                        }
                        count++;
                        System.out.println("hii7");
                        if (count != 0) {
                            newLineItem = new Lineitem(id, lineitem.getProduct_id(), set.getString(3), Selling_Price, requiredquantity, requiredquantity * Selling_Price, LocalDate.now());
                            listoflineitems.add(newLineItem);
                            noofproductstobeaddeddinlineitempassed++;
                            totalAmount = totalAmount + (requiredquantity * Selling_Price);
                            System.out.println(requiredquantity);
                            System.out.println(totalAmount);

                            quantity = quantity + requiredquantity;
                        }
                    }

                }
                System.out.println("I"+noofproductstobeaddeddinlineitem);
                System.out.println("I"+noofproductstobeaddeddinlineitempassed);


                if (noofproductstobeaddeddinlineitem == noofproductstobeaddeddinlineitempassed && count != 0) {
                    newOrder = new Order(id, totalAmount, count, quantity, LocalDate.now());
                    PreparedStatement order = connect.prepareStatement("insert into Orders (Customer_ID,total_amount,lineitems,TotalQuantity,order_date,OrderStatus) values (?,?,?,?,?,?)");
                    order.setInt(1, newOrder.getCust_id());
                    order.setDouble(2, newOrder.getTotal_amount());
                    order.setInt(3, newOrder.getLineitems());
                    order.setInt(4, newOrder.getQuantity());
                    order.setDate(5, Date.valueOf(newOrder.getDate()));
                    if(mainrole.equals("Employee"))
                    {
                        order.setString(6,"APPROVED");
                    }
                    else
                    {
                        
                        order.setString(6,"PENDING");
                    }
                    order.executeUpdate();
                    set = connect.createStatement().executeQuery(" select order_id from Orders ORDER BY order_id DESC LIMIT 1");
                    set.next();
                    int orderid=set.getInt(1);
                    Iterator iterate = listoflineitems.iterator();
                    while (iterate.hasNext())
                    {
                        if(mainrole.equals("Employee"))
                        {
                        newLineItem = (Lineitem) iterate.next();
                        PreparedStatement newLine = connect.prepareStatement("insert into LineItem(order_id,Product_ID,Product_Name,Selling_Price,Product_Quantity,Lineitem_Price,Date_) values (?,?,?,?,?,?,?)");

                        newLine.setInt(1,orderid);
                        newLine.setInt(2,newLineItem.getProduct_id());
                        newLine.setString(3,newLineItem.getProduct_name());
                        newLine.setDouble(4,newLineItem.getselling_price());
                        newLine.setInt(5, newLineItem.getProduct_quantity());
                        newLine.setDouble(6,newLineItem.getLine_item_price());

                        newLine.setDate(7, Date.valueOf(newLineItem.getDate()));
                        newLine.executeUpdate();
                          set = connect.createStatement().executeQuery("Select Product_Quantity from Products where Product_ID="+newLineItem.getProduct_id());
                        requiredquantity = newLineItem.getProduct_quantity();
                        set.next();
                        existingQuantity = set.getInt(1);
                      System.out.println(newLineItem.getProduct_id());

                        int qua = existingQuantity - requiredquantity;
                        connect.createStatement().executeUpdate("Update Products set Product_Quantity =" + "'" + qua + "'" + "where Product_ID=" + newLineItem.getProduct_id());
                           set = connect.createStatement().executeQuery("Select Remaining_Amount from Customer where Customer_ID=" + id);
                    set.next();
                    double amount = set.getDouble(1);
                    amount = amount + totalAmount;
                    connect.createStatement().executeUpdate("Update Customer set Remaining_Amount = " + "'" + amount + "'" + " where Customer_ID=" + id);
         
                    
                    if(payingoptions.equals("PayNow"))
                    
                    {  
                        return (payment.addPayment(phoneNo, totalAmount));
                       
                    }
                    return true;
                        }
                       else
                        {
                        newLineItem = (Lineitem) iterate.next();
                        PreparedStatement newLine = connect.prepareStatement("insert into TemproryLineItem(order_id,Product_ID,Product_Name,Selling_Price,Product_Quantity,Lineitem_Price,Date_) values (?,?,?,?,?,?,?)");

                        newLine.setInt(1,orderid);
                        newLine.setInt(2,newLineItem.getProduct_id());
                        newLine.setString(3,newLineItem.getProduct_name());
                        newLine.setDouble(4,newLineItem.getselling_price());
                        newLine.setInt(5, newLineItem.getProduct_quantity());
                        newLine.setDouble(6,newLineItem.getLine_item_price());

                        newLine.setDate(7, Date.valueOf(newLineItem.getDate()));
                        newLine.executeUpdate();  
                        }
                      
                    }
                   return true;

                    

                 

                }
                
                
                
                else {
                    return false;
                }

            }
        }

        return false;
    }

}
