/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.main.Menu;
import com.mordernmart.commonvalidation.Validation;
import com.mordernmart.commonvalidation.ValidationImpl;
import com.mordernmart.dao.mysqlimpl.DbSelection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
public class PaymentBuisnessLogicImpl implements PaymentBuisnessLogic 
{  
   
    private boolean check;
    private Validation validation;
    private DbSelection getdb;

    {
        validation = new ValidationImpl();

        check = true;

    }

    public PaymentBuisnessLogicImpl() {
    }
    
     public PaymentBuisnessLogicImpl(String a)
    {
        this.getdb=new DbSelection(a);
    }
    @Override
    public boolean addPayment(String phoneNo,double payment) throws IOException, SQLException
    {
        System.out.println("Hello");
        
        check = validation.phoneNoValidation(phoneNo);

        if (check == false) {
          return false;
        } 
        else 
        {
            return getdb.getGetdb().getPaymentDao().acceptPayments(phoneNo,payment);
        }
    }
  }   

