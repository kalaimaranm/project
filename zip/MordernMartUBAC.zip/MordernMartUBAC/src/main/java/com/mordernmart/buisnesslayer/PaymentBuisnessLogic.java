
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import java.io.IOException;
import java.sql.SQLException;

/**
 *
 * @author bas200186
 */
public interface PaymentBuisnessLogic {
        public boolean addPayment(String phoneNo,double payment) throws IOException, SQLException;

}
