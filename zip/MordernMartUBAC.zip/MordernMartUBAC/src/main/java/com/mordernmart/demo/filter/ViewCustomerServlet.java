/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.demo.filter;

import com.mordernmart.main.EstablishConnection;
import com.mordernmart.model.Customer;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
@WebServlet(name ="viewcustomerservlet",urlPatterns ={"/customerservlet"})
public class ViewCustomerServlet extends HttpServlet
{
   private Connection establishconnection;
   private ResultSet set;
   private String name;
   private String address;
   private String aadharid;
   private String phoneno;
   private List<Customer> listofcustomers;
   {
       listofcustomers=new ArrayList();
   }
   
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    EstablishConnection connection= new EstablishConnection();
       try {
           establishconnection=connection.startConnection();
       } catch (SQLException ex) {
           Logger.getLogger(ViewCustomerServlet.class.getName()).log(Level.SEVERE, null, ex);
       }
       try {
           set=establishconnection.createStatement().executeQuery("Select * from CustomerDetails");
       } catch (SQLException ex) {
           Logger.getLogger(ViewCustomerServlet.class.getName()).log(Level.SEVERE, null, ex);
       }
       try {
           while(set.next())
           {
               
               
               name=set.getString(1);
               
               address=set.getString(2);
                              phoneno=set.getString(3);

               aadharid=set.getString(4);
               Customer viewCustomer=new Customer(name,address,phoneno,aadharid);
               listofcustomers.add(viewCustomer);
               req.setAttribute("listofcustomers",listofcustomers);
           }
       } catch (SQLException ex) {
           Logger.getLogger(ViewCustomerServlet.class.getName()).log(Level.SEVERE, null, ex);
       }
       try {
                      establishconnection.close();

        resp.sendRedirect("ViewCustomer.jsp");

       } catch (SQLException ex) {
           Logger.getLogger(ViewCustomerServlet.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    

    
}
