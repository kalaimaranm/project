/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.dao.mysqlimpl;

import com.mordernmart.daointerface.KhataBookDao;

/**
 *
 * @author bas200186
 */
public class DbSelection 
{
private KhataBookDao getdb;

    public DbSelection(String db) 
    {
        System.out.println("From Db Selection");
        if(db.equalsIgnoreCase("mysql"))
        getdb = new MySqlKhataBookDaoImpl();
    }

    public KhataBookDao getGetdb()
    {
        System.out.println("getting db");
        return getdb;
    }
    
}
