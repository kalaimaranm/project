
package com.mordernmart.model;

import java.time.LocalDate;

public class Payment 
{
    private int cust_id;
    private int payment_id;
    private double total_amount;
    private LocalDate date;

    public Payment(int cust_id,  double total_amount, LocalDate date) {
        this.cust_id = cust_id;
        this.total_amount = total_amount;
        this.date = date;
    }

    @Override
    public String toString() {
        return "Payment{" + "cust_id=" + cust_id + ", payment_id=" + payment_id + ", total_amount=" + total_amount + ", date=" + date + '}';
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    

    public void setPayment_id(int payment_id) {
        this.payment_id = payment_id;
    }

    public void settotal_amount(double total_amount) {
        this.total_amount = total_amount;
    }

    public int getPayment_id() {
        return payment_id;
    }

    public double gettotal_amount() {
        return total_amount;
    }


    public void setCust_id(int cust_id) {
        this.cust_id = cust_id;
    }


    public int getCust_id() {
        return cust_id;
    }

  
}
