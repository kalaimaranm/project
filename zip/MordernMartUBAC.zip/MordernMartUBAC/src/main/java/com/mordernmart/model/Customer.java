package com.mordernmart.model;

public class Customer {

    private String name;
    private String address;
    private String phoneNo;
    private String aadharid;
    private double remainingamount;
    private String customer_status;
    private int id;

   

    public Customer(String name, String address, String phoneNo, String aadharid, String customer_status, double remainingamount) {
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
        this.aadharid = aadharid;
        this.customer_status = customer_status;
        this.remainingamount = remainingamount;
    }

    public Customer(String name, String address, String phoneNo, String aadharid) {
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
        this.aadharid = aadharid;

    }

    public Customer(String name, String address, String phoneNo, String aadharid, double remainingamount, String customer_status, int id) {
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
        this.aadharid = aadharid;
        this.remainingamount = remainingamount;
        this.customer_status = customer_status;
        this.id = id;
    }

    public Customer(String name, String address, String aadharid) {
        this.name = name;
        this.address = address;
        this.aadharid = aadharid;
    }
    

    public double getRemainingamount() {
        return remainingamount;
    }

    public void setRemainingamount(double remainingamount) {
        this.remainingamount = remainingamount;
    }

    public String getName() {
        return name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomer_status() {
        return customer_status;
    }

    public void setCustomer_status(String customer_status) {
        this.customer_status = customer_status;
    }


    public void setAadharid(String aadharid) {
        this.aadharid = aadharid;
    }

    public String getAadharid() {
        return aadharid;
    }

    public int getId() {
        return id;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getAddress() {
        return address;
    }
    
    @Override
    public String toString() {
        return "Customer{" + " Name=" + name + ", Address=" + address + ", PhoneNo=" + phoneNo + ", Aadharid=" + aadharid + ", Remainingamount=" + remainingamount + ", Customer_status=" + customer_status + '}';
    }
}
