
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.model.Customer;
import java.io.IOException;
import java.sql.SQLException;

/**
 *
 * @author bas200186
 */
public interface CustomerBuisnessLogic 
{
 public boolean addcustomer(Customer theCustomer) throws IOException,SQLException;
 public Customer viewCustomer(String phoneno) throws IOException,SQLException;
 public boolean updateCustomer(Customer theCustomer) throws IOException,SQLException;
 public boolean deleteCustomer(String phoneNo) throws IOException,SQLException;

}
