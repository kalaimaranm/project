/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.customer;

import com.mordernmart.buisnesslayer.CustomerBuisnessLogicImpl;
import com.mordernmart.buisnesslayer.OrderBuisnessLogicImpl;
import com.mordernmart.buisnesslayer.ProductsBuisnessLogicImpl;
import com.mordernmart.model.Customer;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.catalina.realm.GenericPrincipal;

/**
 *
 * @author bas200186
 */
public class SelectCustomerForPlaceOrder extends HttpServlet
{
        private CustomerBuisnessLogicImpl customerBuisnessLogic;
        private ProductsBuisnessLogicImpl productsBuisnessLogic;
        private OrderBuisnessLogicImpl orderBuisnessLogic;
        private List productlist;
    @Override
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
          ServletContext a = this.getServletContext();
           PrintWriter out=response.getWriter();
          this.customerBuisnessLogic = new CustomerBuisnessLogicImpl(getServletContext().getInitParameter("db"));
          String phoneNo =request.getParameter("phoneNo");
          System.out.print(phoneNo);
          if(phoneNo.length()>0&&phoneNo.length()==10)
           {
              try {
                  Customer getCustomer=customerBuisnessLogic.viewCustomer(phoneNo);            
                  if(Objects.nonNull(getCustomer))
                  {
                      ServletContext context=getServletContext();
                      request.setAttribute("customer",getCustomer);
                      productsBuisnessLogic=new ProductsBuisnessLogicImpl(getServletContext().getInitParameter("db"));
                      productlist=productsBuisnessLogic.showAllProduct();
                      request.setAttribute("productlist",productlist);
                      RequestDispatcher rd=request.getRequestDispatcher("PlaceOrder.jsp");
                      rd.include(request, response);
                  }
                  else
                  {
                      out.println("Customer Not Found");
                  }
              } catch (SQLException ex) {
                  Logger.getLogger(ViewCustomerServlet.class.getName()).log(Level.SEVERE, null, ex);
              }
            }
          else
          {
              response.getWriter().println("Please Enter a Valid Phone No");
          }

    }
    
}
