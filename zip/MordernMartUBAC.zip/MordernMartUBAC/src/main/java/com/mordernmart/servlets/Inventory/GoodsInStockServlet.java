/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.Inventory;

import com.mordernmart.buisnesslayer.ProductsBuisnessLogicImpl;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author bas200186
 */
public class GoodsInStockServlet extends GenericServlet{
        private ProductsBuisnessLogicImpl productsBuisnessLogic;
                private List productlist;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
    {
          productsBuisnessLogic=new ProductsBuisnessLogicImpl(getServletContext().getInitParameter("db"));
          productlist=productsBuisnessLogic.showAllProduct();

          request.setAttribute("productlist",productlist);

                      RequestDispatcher rd=request.getRequestDispatcher("GoodsInStock.jsp");
                      rd.include(request, response);


    }
    
}
