/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.Inventory;

import com.mordernmart.buisnesslayer.ProductsBuisnessLogicImpl;
import com.mordernmart.model.Products;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 *
 * @author bas200186
 */
public class UpdateProductServlet extends GenericServlet
{
        private ProductsBuisnessLogicImpl productsBuisnessLogic;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException
    {
        PrintWriter writer=response.getWriter();
        productsBuisnessLogic=new ProductsBuisnessLogicImpl(getServletContext().getInitParameter("db"));
        int quantity=0;
        int productid=0;
         try{
         quantity=Integer.parseInt(request.getParameter("productquantity"));
        }
        catch(Exception e)
        {
            writer.print("Enter a Valid Number and Number must be Non Decimal");
        }
        try
        {
         productid=Integer.parseInt(request.getParameter("productid"));
        }
        catch(Exception e)
        {
            writer.print("Enter a Valid Number and Number must be Non Decimal");
        }
             if(quantity>0&&productid>0)
        {
            if(productsBuisnessLogic.updateProduct(productid,quantity)) 
            {
                writer.print("Stock Loaded");
                
            }
            else
            {
              writer.print("Stock Not Loaded");

            }
        }
             else
             {
                               writer.print("Stock Not Loaded");

             }

    }
    
}
