/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.model.Lineitem;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author bas200186
 */
public interface OrderBuisnessLogic
{
    public boolean placeOrder(List<Lineitem> orderdetails,String phoneNo,String payingoptions,String mainrole) throws IOException,SQLException;
    
}
