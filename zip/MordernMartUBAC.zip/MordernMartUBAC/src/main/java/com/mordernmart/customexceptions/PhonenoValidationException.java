/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.customexceptions;

/**
 *
 * @author bas200186
 */
public class PhonenoValidationException extends RuntimeException
{

    public PhonenoValidationException() {
    }

    public PhonenoValidationException(String message) {
        super(message);
    }

    public PhonenoValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public PhonenoValidationException(Throwable cause) {
        super(cause);
    }

    public PhonenoValidationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
