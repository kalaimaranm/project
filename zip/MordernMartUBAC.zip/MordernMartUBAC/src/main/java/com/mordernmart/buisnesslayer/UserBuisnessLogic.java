/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.model.User;

/**
 *
 * @author bas200186
 */
public interface UserBuisnessLogic 
{
  public User createUser(User user);
  public boolean validateUser(User user);
  public boolean deleteUser(int userid);
  public boolean updateUser();
  public User viewUser(int userid);
}
