/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.dao.mysqlimpl;

import com.mordernmart.daointerface.UserDao;
import com.mordernmart.main.EstablishConnection;
import com.mordernmart.model.User;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author bas200186
 */
public class UserDaoImpl implements UserDao {

   private EstablishConnection connection;
    {
         System.out.println("UserDaoImpl");

        connection=new EstablishConnection();
    }
    @Override
    public User createUser(User user) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean validateUser(User user) 
    {
        System.out.println("validate User");
       ResultSet rs=null;
       try 
       {
           rs  = connection.startConnection().createStatement().executeQuery("Select * from UserDetails where Username="+"'"+user.getUserName()+"'");
       } 
       catch (SQLException ex)
       {

         ex.printStackTrace();
       }
       try {
           while(rs.next())
           {
               if(user.getUserName().equals(rs.getString(1))&&user.getPassWord().equals(rs.getString(2)))
               {
                   return true;
               }
               
           }
       } catch (SQLException ex) {
         System.out.println("Problem in getting User");

       }
       return false;
    }

    @Override
    public boolean deleteUser(int userid) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean updateUser() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public User viewUser(int userid) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
