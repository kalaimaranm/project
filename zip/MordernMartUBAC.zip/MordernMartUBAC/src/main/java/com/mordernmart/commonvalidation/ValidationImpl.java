/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.commonvalidation;

/**
 *
 * @author bas200186
 */
public class ValidationImpl implements Validation
{
    private  int count;
    public ValidationImpl()
    {
        
    }

    @Override
    public boolean phoneNoValidation(String phoneNo)
    {
        count=0;
        for (int i = 0; i < phoneNo.length(); i++) {
            try {
                if (phoneNo.charAt(i) <= '9' && phoneNo.charAt(i) >= '0')
                {
                    count++;
                }
            }
            catch (Exception e) {
                System.out.println("Index Out Of Bounds");
            }

        }
        if(count==10)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public boolean aadharNoValidation(String aadhar_id) 
    {
        count=0;
        for (int i = 0; i < aadhar_id.length(); i++) {
            try {
                if (aadhar_id.charAt(i) <= '9' && aadhar_id.charAt(i) >= '0')
                {
                    count++;
                }
            }
            catch (Exception e) {
                System.out.println("Index Out Of Bounds");
            }

        }
        if(count==12)
        {
            return true;
        }
        else
        {
            return false;
        }
        
        
    }
    
}
