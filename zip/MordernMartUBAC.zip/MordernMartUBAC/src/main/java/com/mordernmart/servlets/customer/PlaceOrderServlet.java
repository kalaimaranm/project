/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.customer;

import com.mordernmart.buisnesslayer.OrderBuisnessLogicImpl;
import com.mordernmart.model.Lineitem;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.catalina.realm.GenericPrincipal;

/**
 *
 * @author bas200186
 */
public class PlaceOrderServlet extends HttpServlet
{
    private OrderBuisnessLogicImpl orderBuisnessLogic;
    private List<Lineitem> orderdetails;
    private Lineitem lineitem;
    private int quantity;
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        
     this.orderBuisnessLogic = new OrderBuisnessLogicImpl(getServletContext().getInitParameter("db"));
     String phoneNo= request.getParameter("customerphoneNo");
     orderdetails=new ArrayList<>();
      String [] product_id=request.getParameterValues("product_id");
      String[] quantity_required=request.getParameterValues("quantity");
      String payingoptions=request.getParameter("paymentdecision");
           Principal name = request.getUserPrincipal();
        GenericPrincipal principal = (GenericPrincipal) name;
        List roles = new ArrayList(Arrays.asList(principal.getRoles()));
        Iterator q = roles.iterator();
        String mainrole=null;
        while (q.hasNext()) {
            String a = (String) q.next();
            if (a.equals("Employee")||a.equals("Customer")) 
            {
                 mainrole=a;
                 break;
            }
           
        }
        for (int i = 0; i <quantity_required.length; i++)
        {
            try
            {
                quantity=Integer.parseInt(quantity_required[i]);
            }
            catch(Exception e)
            {
                continue;
            }
            if(quantity>0)
            {
            
            lineitem=new Lineitem(Integer.parseInt(product_id[i]),Integer.parseInt(quantity_required[i]));
            orderdetails.add(lineitem);
            }
        
        }
        try {

          boolean value=  orderBuisnessLogic.placeOrder(orderdetails,phoneNo,payingoptions,mainrole);
          if(value)
          {
              response.getWriter().println("Order is Placed");
          }
          else
          {
             response.getWriter().println("Order failed");

          }
        }
         catch (SQLException ex) {
            Logger.getLogger(PlaceOrderServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
}
}
