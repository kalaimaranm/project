/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.customer;

import com.mordernmart.buisnesslayer.CustomerBuisnessLogicImpl;
import com.mordernmart.model.Customer;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
public class SelectCustomerServlet extends GenericServlet 
{
    private CustomerBuisnessLogicImpl customerBuisnessLogic;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
    {
          ServletContext a = this.getServletContext();
           PrintWriter out=response.getWriter();
          this.customerBuisnessLogic = new CustomerBuisnessLogicImpl(getServletContext().getInitParameter("db"));
          String phoneNo =request.getParameter("phoneNo");
          if(phoneNo.length()>0&&phoneNo.length()==10)
           {
              try {
                  Customer getCustomer=customerBuisnessLogic.viewCustomer(phoneNo);            
                  if(Objects.nonNull(getCustomer))
                  {
                      ServletContext context=getServletContext();
                     request.setAttribute("customer",getCustomer);
                      RequestDispatcher rd=request.getRequestDispatcher("UpdateCustomer.jsp");
                      rd.include(request, response);
                  }
                  else
                  {
                      out.println("Customer Not Found");
                  }
              } catch (SQLException ex) {
                  Logger.getLogger(ViewCustomerServlet.class.getName()).log(Level.SEVERE, null, ex);
              }
            }
          else
          {
              response.getWriter().println("Please Enter a Valid Phone No");
          }

    }
    
}
