/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.main.Menu;
import com.mordernmart.model.Customer;
import com.mordernmart.commonvalidation.Validation;
import com.mordernmart.commonvalidation.ValidationImpl;
import com.mordernmart.customexceptions.CustomerValidationException;
import com.mordernmart.dao.mysqlimpl.DbSelection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Objects;

/**
 *
 * @author bas200186
 */
public class CustomerBuisnessLogicImpl implements CustomerBuisnessLogic {

    private String name;
    private String address;
    private String phoneNo;
    private String aadhar_id;
    private BufferedReader sc;
    private boolean check;
    private Menu menu;
    private Validation validation;
    private DbSelection getdb;

    private int input;

    {
        validation = new ValidationImpl();
        name = "";
        address = "";
        phoneNo = "";
        aadhar_id = "";
        sc = new BufferedReader(new InputStreamReader(System.in));
        check = true;
        input = 0;
        menu=new Menu();
    }

    public CustomerBuisnessLogicImpl() {
    }
    
    public CustomerBuisnessLogicImpl(String a)
    {
        System.out.println("UserBuisnessLogicImpl");
        this.getdb=new DbSelection(a);
    }
    public boolean addcustomer(Customer thecustomer) throws IOException,  SQLException 
    {

        Customer newCustomer=null;
        check = validation.phoneNoValidation(thecustomer.getPhoneNo());
        //Checking phoneno
        if (check == false)
        {

            return false;
//            throw new CustomerValidationException("Phone No Has many characters or contains Alphabets");
        }
       check = validation.aadharNoValidation(thecustomer.getAadharid());
        if (check == false) 
        {
            
                        return false;

//            throw new CustomerValidationException("Aadhar no Has many characters or contains Alphabets");
        }
        if(Objects.nonNull(thecustomer.getName())&&Objects.nonNull(thecustomer.getPhoneNo())&&Objects.nonNull(thecustomer.getAddress())&&Objects.nonNull(thecustomer.getAadharid()))
        {
        newCustomer = new Customer(thecustomer.getName(),thecustomer.getAddress(),thecustomer.getPhoneNo(),thecustomer.getAadharid(), "ACTIVE", 0.0);
        }
        if(getdb.getGetdb().getCustomerDao().addCustomer(newCustomer))
        {
           return true;

        }
        else
        {
            return false;
        }

    }

    @Override
    public Customer viewCustomer(String phoneNo) throws IOException, SQLException{
        check = validation.phoneNoValidation(phoneNo);

        if (check == false) 
        {      

          return null;
        } 
        else {
           Customer getCustomer= getdb.getGetdb().getCustomerDao().viewCustomer(phoneNo);
               
 
           return getCustomer;
        }
    }

    @Override
    public boolean updateCustomer(Customer theCustomer) throws IOException,SQLException {
        check = validation.phoneNoValidation(theCustomer.getPhoneNo());

        if (check == false) 
        {

          return false;

        } 
      check = validation.aadharNoValidation(theCustomer.getAadharid());
        if (check == false) 
        {

            
              return false;        }
        else {
       
            return    getdb.getGetdb().getCustomerDao().updateCustomer(theCustomer);


            }
        }
       

    @Override
    public boolean deleteCustomer(String phoneNo) throws IOException,  SQLException
    {
        
      
        check = validation.phoneNoValidation(phoneNo);

        if (check == false) 
        {
             return false;
        } 
        else {
            return getdb.getGetdb().getCustomerDao().deleteCustomer(phoneNo);
        }
    }

 
   
}
