/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.dao.mysqlimpl.DbSelection;
import com.mordernmart.main.EstablishConnection;
import com.mordernmart.model.Products;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
public class ProductsBuisnessLogicImpl implements ProductsBuisnessLogic 
{
    private  String product_name;
    private  double cost_price;
    private  double selling_price;
    private  int product_quantity;
    private  String net_weight;
    private  int input;
    private  ResultSet set;
    private EstablishConnection connection;
    private List productlist;
    private LocalDate date;
    private int productId;
    private DbSelection getdb;

    {
        product_name = "";
        cost_price = 0;
        selling_price = 0;
        product_quantity = 0;
        input=0;
   
    }
    
    
          public ProductsBuisnessLogicImpl() {
    }
    public ProductsBuisnessLogicImpl(String a) 
    {
        this.getdb=new DbSelection(a);
    }
    
  
                
   @Override
   public boolean newProduct(Products product) throws IOException, SQLException
   {
                  try{
                 
                    Products newProduct = new Products(product.getProduct_name(),product.getselling_price(),product.getCost_price(),product.getNet_weight(),product.getProduct_quantity(),LocalDate.now());
                    getdb.getGetdb().getProductsDao().newProduct(newProduct);
                    return true;
                  }
                    catch(NumberFormatException e)
                  {
                     return false;
                  }
                 
                                          
                  } 

    @Override
    public boolean updateProduct(int productid,int productquantity) throws IOException
    {
        if(productquantity>0&&productid>0)
        {
            try {
                if(getdb.getGetdb().getProductsDao().updateProduct(productid,productquantity))
                {
                    return true;
                }
                else
                {
                    return false;
                }   } catch (SQLException ex) {
                Logger.getLogger(ProductsBuisnessLogicImpl.class.getName()).log(Level.SEVERE, null, ex);
            }

    }
        return false;
    }

    @Override
    public List showAllProduct()
    {
        return getdb.getGetdb().getProductsDao().showAllProduct();
    }


    
    
   }   

