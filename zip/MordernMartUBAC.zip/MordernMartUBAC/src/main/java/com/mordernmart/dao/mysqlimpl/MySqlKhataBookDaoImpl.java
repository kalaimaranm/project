/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.dao.mysqlimpl;

import com.mordernmart.daointerface.CustomerDao;
import com.mordernmart.daointerface.KhataBookDao;
import com.mordernmart.daointerface.LineitemDao;
import com.mordernmart.daointerface.OrderDao;
import com.mordernmart.daointerface.PaymentDao;
import com.mordernmart.daointerface.ProductsDao;
import com.mordernmart.daointerface.UserDao;


/**
 *
 * @author bas200186
 */
public class MySqlKhataBookDaoImpl implements KhataBookDao
{
    

    public CustomerDao getCustomerDao() {
        return new CustomerDaoImpl();
    }

    public ProductsDao getProductsDao() {
        return new ProductsDaoImpl();
    }
      public OrderDao getOrderDao() {
        return new OrderDaoImpl();
    }

    public PaymentDao getPaymentDao() {
        return new PaymentDaoImpl();
    }  
    public LineitemDao getLineitemDao() {
        return new LineitemDaoImpl();
    }
    
    public UserDao getUserDao()
    {
        return new UserDaoImpl();
    }
   
}
