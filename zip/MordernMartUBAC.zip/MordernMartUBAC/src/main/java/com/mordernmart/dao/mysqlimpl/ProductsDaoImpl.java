/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.dao.mysqlimpl;

import com.mordernmart.buisnesslayer.ProductsBuisnessLogicImpl;
import com.mordernmart.daointerface.ProductsDao;
import com.mordernmart.main.EstablishConnection;
import com.mordernmart.main.Menu;
import com.mordernmart.model.Products;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
public class ProductsDaoImpl implements ProductsDao {

    private int input;
    private BufferedReader sc;
    private String phoneNo;
    private boolean check;
    private EstablishConnection connection;
    private ResultSet set;
    private int temp;
    private int existingQuantity;
    private double Selling_Price;
    private String productname;
    private int a;
    private int count;
    private Connection connect;
    private Menu menu;
     private  String product_name;
    private  double cost_price;
    private  double selling_price;
    private  int product_quantity;
    private  String net_weight;
     private List productlist;
    private LocalDate date;
    private int productId;

    {
        input = 0;
        sc = new BufferedReader(new InputStreamReader(System.in));
        phoneNo = "";
        check = true;
        temp = 0;
        existingQuantity = 0;
        Selling_Price = 0;
        productname = "";
        a = 0;
        count=0;
        connection= new EstablishConnection();
        menu=new Menu();
        product_name = "";
        cost_price = 0;
        selling_price = 0;
        product_quantity = 0;
        productlist= new ArrayList();
     }


    public boolean newProduct(Products newProduct) throws SQLException, IOException{
        try {
            connect = connection.startConnection();
        } catch (Exception e) {
                return false;
        }
        PreparedStatement newProducts = connect.prepareStatement("insert into Products (Product_Name,Selling_Price,Cost_Price,Net_Weight,Product_Quantity,Date_) values (?,?,?,?,?,?)");
        newProducts.setString(1, newProduct.getProduct_name());
        newProducts.setDouble(2, newProduct.getselling_price());
        newProducts.setDouble(3, newProduct.getCost_price());
        newProducts.setString(4, newProduct.getNet_weight());
        newProducts.setInt(5, newProduct.getProduct_quantity());
        newProducts.setDate(6, Date.valueOf(newProduct.getDate()));
        newProducts.executeUpdate();
        return true;
    }

    @Override
    public boolean updateProduct(int productid,int productquantity) throws IOException, SQLException{
       
        connect = connection.startConnection();
        set = connect.createStatement().executeQuery("Select Product_Quantity,Selling_Price,Product_Name from Products where Product_ID=" +productid);
        existingQuantity = 0;
        Selling_Price = 0;
        productname = "";
        while (set.next()) {
            try{
            existingQuantity = set.getInt(1);
            Selling_Price = set.getDouble(2);
            productname = set.getString(3);
            }
            catch(Exception e)
            {
                return false;
            }
        }
        a = existingQuantity +productquantity;
        connect.createStatement().executeUpdate("Update Products set Product_Quantity =" + "'" + a + "'" + "where Product_ID=" +productid);
        return true;

        }
    
   

    @Override
    public List showAllProduct()
    {
        try
        {
            set=connection.startConnection().createStatement().executeQuery("Select * from Products");
        }
        catch (SQLException ex) {
            Logger.getLogger(ProductsBuisnessLogicImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            while(set.next())
            {
                productId= set.getInt(1);
                product_name=set.getString(2);
                cost_price=set.getDouble(3);
                selling_price=set.getDouble(4);
                net_weight=set.getString(5);
                product_quantity=set.getInt(6);
                date=  set.getDate(7).toLocalDate();
                Products newProduct = new Products(productId,product_name,selling_price,cost_price,net_weight, product_quantity,date);
                 productlist.add(newProduct);
                
                
                
            }  
        } 
        catch (SQLException ex) {
            Logger.getLogger(ProductsBuisnessLogicImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productlist;
    }

}
