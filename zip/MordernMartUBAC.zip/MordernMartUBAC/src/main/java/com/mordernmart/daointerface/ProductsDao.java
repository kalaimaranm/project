/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.daointerface;

import com.mordernmart.customexceptions.MordernMartExceptions;
import com.mordernmart.model.Products;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author bas200186
 */
public interface ProductsDao
{
    
    public boolean newProduct(Products newProduct) throws SQLException, IOException;    
  public boolean updateProduct(int productid,int productquantity) throws IOException, SQLException;
      public List showAllProduct();

}
