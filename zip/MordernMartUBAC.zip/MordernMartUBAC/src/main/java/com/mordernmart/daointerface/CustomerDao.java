/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.daointerface;

import com.mordernmart.model.Customer;
import com.mordernmart.customexceptions.MordernMartExceptions;
import java.io.IOException;
import java.sql.SQLException;

/**
 *
 * @author bas200186
 */
public interface CustomerDao 
{
   public boolean addCustomer(Customer customer) throws IOException, SQLException;
   public Customer viewCustomer(String phone_no) throws IOException, SQLException;
   public boolean updateCustomer(Customer theCustomer) throws IOException, SQLException;
   public boolean deleteCustomer(String phone_no) throws IOException, SQLException; 
}
