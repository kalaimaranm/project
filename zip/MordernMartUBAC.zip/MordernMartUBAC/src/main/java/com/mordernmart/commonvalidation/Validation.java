/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.commonvalidation;

/**
 *
 * @author bas200186
 */
public interface Validation 
{
  public boolean phoneNoValidation(String phoneNo);
  public boolean aadharNoValidation(String aadhar_id);
}
