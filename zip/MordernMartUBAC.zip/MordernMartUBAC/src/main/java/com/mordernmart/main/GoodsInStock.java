/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author bas200186
 */
public class GoodsInStock 
{
        private  Connection connect;
        private  ResultSet set;
        private EstablishConnection connection;
        {
            connection=new EstablishConnection();
        }

   public  void stock() throws SQLException, IOException
   {
     

      System.out.print("\n+" + "-".repeat(10) + "+" + "-".repeat(20) + "+" + "-".repeat(22) + "+" + "-".repeat(18) + "+" + "-".repeat(14) + "+"+ "-".repeat(16)+ "+" +"-".repeat(15)+"+");
      System.out.format("\n|%-10s|%-20s|%-22s|%-18s|%-14s|%-12s|%-10s|", "Product_Id", "Product_Name", "Cost_Price", "Selling_Price", "Net_Weight","Product_Quantity","First_installed");
      System.out.print("\n+" + "-".repeat(10) + "+" + "-".repeat(20) + "+" + "-".repeat(22) + "+" + "-".repeat(18) + "+" + "-".repeat(14) + "+"+ "-".repeat(16)+ "+" +"-".repeat(15)+"+");
      set=connection.startConnection().createStatement().executeQuery("Select * from Products");
      while(set.next())
      {
        System.out.format("\n|%-10s|%-20s|%-22s|%-18s|%-14s|%-16s|%-15s|", set.getInt(1), set.getString(2),set.getDouble(3),set.getDouble(4),set.getString(5),set.getInt(6),set.getDate(7));

        System.out.print("\n+" + "-".repeat(10) + "+" + "-".repeat(20) + "+" + "-".repeat(22) + "+" + "-".repeat(18) + "+" + "-".repeat(14) + "+"+ "-".repeat(16)+ "+" +"-".repeat(15)+"+");

          

   }
       System.out.println("");
                           

}
}
