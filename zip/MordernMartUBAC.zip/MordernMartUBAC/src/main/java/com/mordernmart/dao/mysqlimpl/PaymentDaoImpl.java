/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.dao.mysqlimpl;


import com.mordernmart.daointerface.PaymentDao;
import com.mordernmart.main.EstablishConnection;
import com.mordernmart.main.Menu;
import com.mordernmart.model.Payment;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 *
 * @author bas200186
 */
public class PaymentDaoImpl implements PaymentDao
{
    private  int input;
    private  BufferedReader sc;
    private  String phoneNo;
    private  boolean check;
    private   ResultSet set;
    private  int id;
    private double remainingamount;
    
    private Menu menu;

    private  Connection connect;
private EstablishConnection connection;
    
    
    {
      input = 0;
      sc = new BufferedReader(new InputStreamReader(System.in));
      phoneNo = "";
      check = true;
      id=0;
      remainingamount=0;
      connection =new EstablishConnection();
      menu=new Menu();
    }

  public boolean acceptPayments(String phoneNo,double payment) throws IOException, SQLException
  {
                      int count=0;
                  
                     connect=connection.startConnection();

                     set= connect.createStatement().executeQuery("Select Customer_ID,Remaining_Amount,Customer_Status from Customer where Phone_No="+phoneNo);
                     while(set.next()){
                         id=set.getInt(1);
                         remainingamount=set.getDouble(2);
                        if(set.getString(3).equals("REMOVED"))
                        {
                          return false;
                        }
                        if(remainingamount>0)
                        {
                            remainingamount=remainingamount-payment;
                            connect.createStatement().executeUpdate( "Update Customer set Remaining_Amount = "+"'"+remainingamount+"'"+" where Customer_ID="+id);
                            Payment newPayment=new Payment(id,payment,LocalDate.now());
                                            
         PreparedStatement payee= connect.prepareStatement("insert into Payments (Customer_ID,TotalAmount,PaymentDate) values (?,?,?)");
         payee.setInt(1, newPayment.getCust_id());
         payee.setDouble(2,newPayment.gettotal_amount() );
         payee.setDate(3,Date.valueOf(newPayment.getDate()));
         
         payee.executeUpdate();
         return true;
                            
                        }
                        else
                        {
                            return false;
                        }
  }
                        if(count==0)
                    {
                       return false;
                        
                    }   
return false;
  }
                 
}
