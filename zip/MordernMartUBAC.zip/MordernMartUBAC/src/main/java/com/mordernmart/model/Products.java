
package com.mordernmart.model;

import java.time.LocalDate;

public class Products 
{
    private int product_id;
    private String product_name;
    private double selling_price;
    private double cost_price;
    private String net_weight; 
    private int product_quantity;
    private LocalDate date;

    

    public Products(int productId, String product_name, double selling_price, double cost_price, String net_weight, int product_quantity, LocalDate date) {
        this.product_id=productId;
        this.product_name = product_name;
        this.selling_price =selling_price;
        this.cost_price=cost_price;
        this.net_weight = net_weight;
        this.product_quantity = product_quantity;
        this.date=date;
    }
   

    public void setProduct_quantity(int product_quantity) {
        this.product_quantity = product_quantity;
    }

    public int getProduct_quantity() {
        return product_quantity;
    }

    public String getNet_weight() {
        return net_weight;
    }

    public void setNet_weight(String  net_weight) {
        this.net_weight = net_weight;
    }

    @Override
    public String toString() {
        return "{" + "product_id=" + product_id + ", product_name=" + product_name + ", selling_price=" + selling_price + ", net_weight=" + net_weight + ", product_quantity=" + product_quantity + '}';
    }

    public Products( String product_name, double selling_price, double cost_price,String net_weight, int product_quantity,LocalDate date) {
        this.product_name = product_name;
        this.selling_price =selling_price;
        this.cost_price=cost_price;
        this.net_weight = net_weight;
        this.product_quantity = product_quantity;
        this.date=date;
    }

    public double getCost_price() {
        return cost_price;
    }

    public void setCost_price(double cost_price) {
        this.cost_price = cost_price;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
    
    public void setselling_price(double selling_price) {
        this.selling_price = selling_price;
    }

    public int getProduct_id() {
        return product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public double getselling_price() {
        return selling_price;
    }
    
}
