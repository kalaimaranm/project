/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 *
 * @author bas200186
 */
public class Statistics 
{
    private  int input;
    private  BufferedReader sc;
    private  String phoneNo;
    private  boolean check;
    private  EstablishConnection connection;
    private   ResultSet setlineitem;
    private   ResultSet setproduct;
    private Connection connect;
    
     
    {
      input = 0;
      sc = new BufferedReader(new InputStreamReader(System.in));
      phoneNo = "";
      check = true;
      connection=new EstablishConnection();

    }
    {
       
    }
   public  void stats() throws IOException, SQLException
   {
         System.out.println("----------------------------------------------------------------");
        System.out.println("|              Statistics Menu                                 |");
        System.out.println("---------------------------------------------------------------|");
        System.out.println("|1)Product                                                     |");
        System.out.println("|  a)The Product Which Gives Maximum Profit From a given date  |");
        System.out.println("|  b)Products which are stored in inventory From a given date  |");
        System.out.println("|  c)Product which were sold for a maximum quantity given date |");
        System.out.println("---------------------------------------------------------------|");
        System.out.println("|2)Customer                                                    |");
        System.out.println("|  a)The Customers Having Debt                                     |");
        System.out.println("---------------------------------------------------------------|");
        System.out.println("|3)Product                                                     |");
        System.out.println("|  a)Max Order Amount From Given Date                                   |");
        System.out.println("|  b)Min Order Amount From Given Date                          |");
        System.out.println("---------------------------------------------------------------|");
        System.out.println("|4)Exit To MainMenu                                            |");
        System.out.println("---------------------------------------------------------------|");

        System.out.println("");
        System.out.println("");
        System.out.println("Select The Options From The Above Menu");
        int selectionsta = Integer.parseInt(sc.readLine());
        switch (selectionsta) {
            case 1:
                System.out.println("---------------------------------------------------------------|");
                System.out.println("|1)Product                                                     |");
                System.out.println("|  a)The Product Which Gives Maximum Profit From Given Date    |");
                System.out.println("|  b)Products which are stored in inventory From a given date  |");
                System.out.println("|  c)Product which were sold from a maximum quantity given date|");
                System.out.println("---------------------------------------------------------------|");
                switch (sc.readLine()) 
                {
                    case "a":
                        System.out.println("Enter The Date");
                        System.out.println("Year");
                        int yearp = Integer.parseInt(sc.readLine());
                        System.out.println("Month");
                        int monthp = Integer.parseInt(sc.readLine());
                        System.out.println("Date");
                        int datep = Integer.parseInt(sc.readLine());
                        LocalDate fulldatep = LocalDate.of(yearp, monthp, datep);
                        double profit = 0;
                        String name = "",
                        name1 = "";
                        connect=connection.startConnection();
                        setproduct=connect.createStatement().executeQuery("Select * From Products");

                        while(setproduct.next()) {
                            double totalsellingprice = 0;
                            double totalcostprice = 0;
                            int j;
                        setlineitem=connect.createStatement().executeQuery("Select * From LineItem");

                            while(setlineitem.next()) {
                            
                                if ((setproduct.getInt(1) == setlineitem.getInt(3)) && (fulldatep.isBefore(setlineitem.getDate(8).toLocalDate()))) 
                                {
                                    totalsellingprice = (setlineitem.getDouble(5) * setlineitem.getInt(6));
                                    totalcostprice = (setproduct.getDouble(3) * setlineitem.getInt(6));
                                    name1 = setlineitem.getString(4);

                                }
                                //name=lineitem_[j].getProduct_name();
                            }
                            if (profit < totalsellingprice - totalcostprice) {
                                profit = totalsellingprice - totalcostprice;
                                name = name1;
                            } else {

                                continue;
                            }
                        }
                        System.out.println("The Product Which Gives Maximum Profit = " + name + "of Rs = " + profit + "From: " + fulldatep);

                        break;
//                    case "b":
//                        System.out.println("Enter The From Date");
//                        System.out.println("Year");
//                        int yearp2 = Integer.parseInt(sc.readLine());
//                        System.out.println("Month");
//                        int monthp2 = Integer.parseInt(sc.readLine());
//                        System.out.println("Date");
//                        int datep2 = Integer.parseInt(sc.readLine());
//                        LocalDate fulldatep2 = LocalDate.of(yearp2, monthp2, datep2);
//                        System.out.println("Enter The To Date");
//                        System.out.println("Year");
//                        int yearp3 = Integer.parseInt(sc.readLine());
//                        System.out.println("Month");
//                        int monthp3 = Integer.parseInt(sc.readLine());
//                        System.out.println("Date");
//                        int datep3 = Integer.parseInt(sc.readLine());
//                        LocalDate fulldatep3 = LocalDate.of(yearp3, monthp3, datep3);
//                        System.out.println("Inventory Storage From " + fulldatep2 + " To " + fulldatep3);
//
//                        for (int i = 0; i < lineitem_.length; i++) {
//                            if (lineitem_[i].getCust_id() == 0 && (lineitem_[i].getDate().isBefore(fulldatep3)) && (lineitem_[i].getDate().isAfter(fulldatep2))) {
//                                System.out.println(lineitem_[i].getProduct_name() + "-" + lineitem_[i].getProduct_quantity());
//                            }
//                        }
//                        statisticsMenu();
//
//                        break;

                    case "c":
                        System.out.println("Enter The From Date");
                        System.out.println("Year");
                        int yearp4 = Integer.parseInt(sc.readLine());
                        System.out.println("Month");
                        int monthp4 = Integer.parseInt(sc.readLine());
                        System.out.println("Date");
                        int datep4 = Integer.parseInt(sc.readLine());
                        LocalDate fulldatep4 = LocalDate.of(yearp4, monthp4, datep4);
                        int maxquantity = 0;
                        String proname = "";
                        connect=connection.startConnection();
    
                        setproduct=connect.createStatement().executeQuery("Select * From Products");

                        while(setproduct.next()) {

                            int quantity = 0;
                        setlineitem=connect.createStatement().executeQuery("Select * From LineItem");

                            while (setlineitem.next()) {
                                if ((setproduct.getInt(1) == setlineitem.getInt(3))  && (setlineitem.getDate(8).toLocalDate().isEqual(fulldatep4))) {
                                    quantity = quantity + setlineitem.getInt(6);
                                }
                            }
                            if (maxquantity < quantity) {
                                maxquantity = quantity;
                                proname = setproduct.getString(2);
                            }

                        }
                        System.out.println("Product which were sold for a maximum quantity given date =" + proname + " Quantity =" + maxquantity + "Date " + fulldatep4);

                        break;

                    default:
                        System.out.println("Select A Valid Option");

                }
                break;
            case 2:
                System.out.println("-----------------------------------------------|");
                System.out.println("|2)Customer                                    |");
                System.out.println("|  a)The Customers Having Debt                 |");
                System.out.println("-----------------------------------------------|");
                System.out.println("Enter From Above Options");
                String sel2 = sc.readLine();
                ResultSet setcustomer;
                switch (sel2) {

                    case "a":

                        System.out.println("Enter The Amount");
                        double max = Double.parseDouble(sc.readLine());
                        String name_;
                        String phno;
                        System.out.println("The Customers Having Debt Above " + max);
                        connect=connection.startConnection();
                        ResultSet setcustomerdetails;
                        setcustomer=connect.createStatement().executeQuery("SELECT * FROM Customer where Remaining_Amount >="+max);
                        while(setcustomer.next())
                        {
                        phno=setcustomer.getString(3);
                        System.out.println("The Customer Has RemainingAmount = "+setcustomer.getDouble(3));
                        }
                        setcustomerdetails=connect.createStatement().executeQuery("SELECT * FROM CustomerDetails where Remaining_Amount >="+max);
                        while(setcustomerdetails.next())
                        {
                            name_=setcustomerdetails.getString(3);
                            System.out.println("The Name Of The Customer is = "+name_);
                        }
                        break;
                }
                break;
//            case 3:
//                System.out.println("------------------------------------------------");
//                System.out.println("|3)Order                                       |");
//                System.out.println("|  a)Max Order Amount From Given Date          |");
//                System.out.println("|  b)Min Order Amount From Given Date          |");
//                System.out.println("-----------------------------------------------|");
//                System.out.println("Enter From Above Options");
//                String sel1 = sc.readLine();
//                ;
//                switch (sel1) {
//                    case "a":
//                        System.out.println("Enter The From Date");
//                        System.out.println("Year");
//                        int yearp2 = Integer.parseInt(sc.readLine());
//                        System.out.println("Month");
//                        int monthp2 = Integer.parseInt(sc.readLine());
//                        System.out.println("Date");
//                        int datep2 = Integer.parseInt(sc.readLine());
//                        LocalDate fulldatep2 = LocalDate.of(yearp2, monthp2, datep2);
//                        double max = 0;
//                        connection=EstablishConnection.startConnection();
//                        setorder=connection.createStatement().executeQuery("SELECT * FROM Customer where Remaining_Amount >="+max);
//
//                        for (int i = 1; i < order_.length; i++) {
//                            if ((max < order_[i].getTotal_amount()) && (fulldatep2.isBefore(order_[i].getDate()))) {
//                                max = order_[i].getTotal_amount();
//                            }
//                        }
//                        System.out.println("The Maximum Order Amount is = " + max);
//                            Hiii.statisticsMenu();
//                        break;
//                    case "b":
//                        System.out.println("Enter The From Date");
//                        System.out.println("Year");
//                        int yearp21 = Integer.parseInt(sc.readLine());
//                        System.out.println("Month");
//                        int monthp21 = Integer.parseInt(sc.readLine());
//                        System.out.println("Date");
//                        int datep21 = Integer.parseInt(sc.readLine());
//                        LocalDate fulldatep21 = LocalDate.of(yearp21, monthp21, datep21);
//                        double min = order_[0].getTotal_amount();
//                        int j;
//                        for (int i = 0; i < order_.length; i++) {
//                            if (order_[i].getTotal_amount() < min) {
//                                min = order_[i].getTotal_amount();
//                            }
//                        }
//                        System.out.println("The Minimum Order is = " + min);
//                        Hiii.statisticsMenu();
//                        break;
//
//                    default:
//                        System.out.println("Select A Valid Option");
//                        Hiii.statisticsMenu();
//
//                }
//                break;
//
            case 4:
                break;

       }

    }
   }

