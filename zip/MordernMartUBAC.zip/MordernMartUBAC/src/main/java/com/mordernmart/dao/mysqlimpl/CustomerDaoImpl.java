/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.dao.mysqlimpl;


import com.mordernmart.model.Customer;
import com.mordernmart.daointerface.CustomerDao;
import com.mordernmart.main.EstablishConnection;
import com.mordernmart.main.Menu;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author bas200186
 */
public class CustomerDaoImpl implements CustomerDao
{
    private  ResultSet set;
    private  int count;
    private  Menu menu;
    private  Connection connect;
    private String name;
    private String phoneNo;
    private String aadharid;
    private String address;
    private int customerid;
    private double remainingamount;
    private String status;

    
    

    private EstablishConnection connection;
    {
     menu=new Menu();
     connection =new EstablishConnection();
    }

    {
        count=0;
    }
    @Override
    public boolean addCustomer(Customer customer) throws IOException, SQLException
    {

               
              connect=connection.startConnection();

               set=connect.createStatement().executeQuery("select Phone_No from CustomerDetails");
               while(set.next())
               {

                if(set.getString(1).equals(customer.getPhoneNo()))
                {
                 connect.close();
                 return false;
                }
               }
      
               PreparedStatement CustomerDetails= connect.prepareStatement("insert into CustomerDetails values (?,?,?,?)");
               CustomerDetails.setString(1, customer.getName());
               CustomerDetails.setString(2, customer.getAddress());
               CustomerDetails.setString(3, customer.getPhoneNo());
               CustomerDetails.setString(4, customer.getAadharid());
               PreparedStatement Customer= connect.prepareStatement("insert into Customer(Phone_No,Customer_Status,Remaining_Amount) values (?,?,?)");
               Customer.setString(1,customer.getPhoneNo());
               Customer.setString(2,customer.getCustomer_status());
               Customer.setDouble(3, customer.getRemainingamount());
               CustomerDetails.executeUpdate();
               Customer.executeUpdate();
               connect.close();
               return true;
    }

    @Override
    public Customer viewCustomer(String phone_no) throws SQLException, IOException
    {
        connect=connection.startConnection();

     set= connect.createStatement().executeQuery("Select * from CustomerDetails where Phone_No="+phone_no );
                     while(set.next()){
                        count++;

                       name=set.getString(1);
                       address= set.getString(2);
                       phoneNo=set.getString(3);
                       aadharid= set.getString(4);
                        }
                            
                    if(count==0)
                    {
                      return null;          
                    }
        set= connect.createStatement().executeQuery("Select * from Customer where Phone_No="+phone_no );
                        while(set.next())
                        {

                        count++;
                        customerid=set.getInt(1);
                        remainingamount=set.getDouble(3);
                        status=set.getString(4);
                        }
                                             connect.close();

                     return new Customer(name,address,phoneNo,aadharid,remainingamount,status,customerid);
                    
            
 }
               

    @Override
    public boolean updateCustomer(Customer theCustomer) throws SQLException, IOException
    {
        connect=connection.startConnection();
        try{
        connect.createStatement().executeUpdate( "Update CustomerDetails set CustomerName = "+"'"+theCustomer.getName()+"'"+" where Phone_No="+theCustomer.getPhoneNo());
        connect.createStatement().executeUpdate( "Update CustomerDetails set Address = "+"'"+theCustomer.getAddress()+"'"+" where Phone_No="+theCustomer.getPhoneNo());
        connect.createStatement().executeUpdate( "Update CustomerDetails set Aadhar_ID= "+"'"+theCustomer.getAadharid()+"'"+" where Phone_No="+theCustomer.getPhoneNo());
        connect.close();

        return true;

        }
        catch(Exception e)
        {
            return false;
        }
    }

    @Override
    public boolean deleteCustomer(String phone_no) throws SQLException, IOException
    {        connect=connection.startConnection();

                     count=0;
                     set= connect.createStatement().executeQuery("Select * from CustomerDetails where Phone_No="+phone_no);
                     while(set.next()){
                        count++;
                    
                        } 
                     set= connect.createStatement().executeQuery("Select * from Customer where Phone_No="+phone_no);
                        while(set.next())
                        {
                        count++;
                       
                        }
                     
                    
                    if(count==0)
                    {
                        return false;
                        
                    }
                    else
                    {
                        connect.createStatement().executeUpdate( "Update Customer set Customer_Status ="+"'"+"REMOVED"+"'"+"where Phone_No="+phone_no);
                        System.out.println("---------------------------------------------------------------------------------------------------------");
                        System.out.println("Successfully Removed The Customer");
                        System.out.println("---------------------------------------------------------------------------------------------------------");
                        connect.close();
                        return true;
                    }
    }
    
}
