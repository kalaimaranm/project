/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.main;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author bas200186
 */
public class EstablishConnection { 
    private Connection connection;
    private String URL;
    private String USERNAME;
    private String PASSWORD;

    {
        System.out.println("From Establish Connection");
        URL = "jdbc:mysql://@bassure.in:3306/dineshmdb";
        USERNAME = "dineshm";
        PASSWORD = "Abdevillers28";
    }

    public Connection startConnection() throws SQLException {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            return connection;

        } catch (Exception e) {
            e.printStackTrace();

        }

        return null;

    }
}
