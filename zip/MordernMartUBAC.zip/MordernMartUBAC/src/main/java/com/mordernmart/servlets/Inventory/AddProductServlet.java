/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.Inventory;

import com.mordernmart.buisnesslayer.ProductsBuisnessLogicImpl;
import com.mordernmart.model.Products;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bas200186
 */
public class AddProductServlet extends GenericServlet{

     private ProductsBuisnessLogicImpl productsBuisnessLogic;
    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException
    {
        PrintWriter writer=response.getWriter();
        productsBuisnessLogic=new ProductsBuisnessLogicImpl(getServletContext().getInitParameter("db"));
        String productname=request.getParameter("productname");
        int quantity=0;
        double costprice=0;
        double sellingprice=0;
        String netweight=request.getParameter("netweight");
        try{
         quantity=Integer.parseInt(request.getParameter("quantity"));
        }
        catch(Exception e)
        {
            writer.print("Enter a Valid Number and Number must be Non Decimal");
        }
        try{
        costprice=Double.parseDouble(request.getParameter("costprice"));
        }
        catch(Exception e)
        {
           writer.print("Enter a Valid Number");

        }
        try{
      sellingprice=Double.parseDouble(request.getParameter("sellingprice"));
        }
        catch(Exception e)
        {

            writer.print("Enter a Valid Number");
            
        }
        if(productname.length()>0&&netweight.length()>0&&quantity>0&&costprice>0&&sellingprice>0)
        {
            Products newProduct=new Products(productname,sellingprice,costprice,netweight,quantity,LocalDate.now());
            try {
                if(productsBuisnessLogic.newProduct(newProduct))
                {
                   writer.print("Product Added");

                }
            } catch (SQLException ex) 
            {
                writer.print("Product Not Added");
            }
        }
    }
    
}
