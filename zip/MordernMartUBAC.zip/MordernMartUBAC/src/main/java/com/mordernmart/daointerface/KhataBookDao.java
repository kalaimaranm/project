/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mordernmart.daointerface;

/**
 *
 * @author bas200186
 */
public interface KhataBookDao 
{
public CustomerDao getCustomerDao(); 
public ProductsDao getProductsDao(); 
public OrderDao getOrderDao(); 
public PaymentDao getPaymentDao(); 
public LineitemDao getLineitemDao(); 
public UserDao getUserDao();
}
