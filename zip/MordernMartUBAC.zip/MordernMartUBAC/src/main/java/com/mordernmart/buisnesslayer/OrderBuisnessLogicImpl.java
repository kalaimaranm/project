


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.main.Menu;
import com.mordernmart.commonvalidation.Validation;
import com.mordernmart.commonvalidation.ValidationImpl;
import com.mordernmart.dao.mysqlimpl.DbSelection;
import com.mordernmart.model.Lineitem;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author bas200186
 */
public class OrderBuisnessLogicImpl implements OrderBuisnessLogic 
{
    private int input;
    private BufferedReader sc;
    private String phoneNo;
    private boolean check;
    private Connection connection;
    private  ResultSet set;
    private Validation validation;
    private Menu menu;
    private DbSelection getdb;

   
    {
      input = 0;
      sc = new BufferedReader(new InputStreamReader(System.in));
      phoneNo = "";
      validation = new ValidationImpl();
      menu= new Menu();
      check = true;
    }

    public OrderBuisnessLogicImpl() {
    }
    

    public OrderBuisnessLogicImpl(String a) {
        this.getdb = new DbSelection(a);
    }
    
    @Override
    public boolean placeOrder(List<Lineitem> orderdetails,String phoneNo,String payingoptions,String mainrole) throws IOException, SQLException
    {
       System.out.println("hii1");
        check = validation.phoneNoValidation(phoneNo);
        Iterator<Lineitem> iterate=orderdetails.iterator();

        for(Lineitem lineitem : orderdetails){
            if(lineitem.getProduct_id()<0||lineitem.getProduct_quantity()<0)
            {
            iterate.remove();
            }
       }

        if (check == false) {
          return false;

        } 
        else 
        {
            return getdb.getGetdb().getOrderDao().placeOrder( orderdetails,phoneNo,payingoptions,mainrole);
        }
    }
}
