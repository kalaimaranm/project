/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.customer;

import com.mordernmart.buisnesslayer.CustomerBuisnessLogicImpl;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author bas200186
 */
public class DeleteCustomerServlet extends GenericServlet
{
     private CustomerBuisnessLogicImpl customerBuisnessLogic;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
    {
           ServletContext a = this.getServletContext();
           PrintWriter out=response.getWriter();
           this.customerBuisnessLogic = new CustomerBuisnessLogicImpl(getServletContext().getInitParameter("db"));
            String phoneNo =request.getParameter("phoneNo");
          if(phoneNo.length()>0&&phoneNo.length()==10)
           {
              try {
                  boolean value=customerBuisnessLogic.deleteCustomer(phoneNo);
                  if(value)
                  {
                   response.getWriter().print("The Customer has  been Deleted");

                  }
                  else
                  {
                   response.getWriter().print("The Customer is Not Found");

                  }
              }
              catch(Exception e)
                      {
                          response.getWriter().print("The Customer has not been Deleted");
                      }
           }
          else
          {
             response.getWriter().println("Please Enter a Valid Phone No");

          }

    }
    
    
}
