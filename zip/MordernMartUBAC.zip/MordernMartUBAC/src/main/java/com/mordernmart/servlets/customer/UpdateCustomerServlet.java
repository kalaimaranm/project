/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.servlets.customer;

import com.mordernmart.buisnesslayer.CustomerBuisnessLogicImpl;
import com.mordernmart.model.Customer;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 *
 * @author bas200186
 */
public class UpdateCustomerServlet extends GenericServlet 
{
    private CustomerBuisnessLogicImpl customerBuisnessLogic;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException 
    {
        
        ServletContext a = this.getServletContext();
        this.customerBuisnessLogic = new CustomerBuisnessLogicImpl(getServletContext().getInitParameter("db"));
        String name=request.getParameter("name");
        String address =request.getParameter("address");
        String aadharid = request.getParameter("aadharid");
        String phoneNo=request.getParameter("phoneNo");
        if(name.length()>0&&address.length()>0&&aadharid.length()>0&&phoneNo.length()>0)
           {
               Customer newCustomer=new Customer(name,address,phoneNo,aadharid);
               boolean value=false;
               
               try 
               {
                   value = customerBuisnessLogic.updateCustomer(newCustomer);
               } 
               catch (SQLException ex) 
               {
                   response.getWriter().print("Customer Not Updated");
               }
               
               
                if (value) 
                {
                   response.getWriter().print("Customer Updated Successfully");
 
                } 
                else
                {
                  
                  response.getWriter().print("Please Check the Details You Have Filled");


               }

           } 
           else
           {
                   response.getWriter().print("Please fill the Required Details");

           }
    
    
    
    }
    
}
