
package com.mordernmart.model;

import java.time.LocalDate;
import java.util.List;

public class Lineitem 
{
  private int line_item_id;
  private int order_id;
  private int product_id;
  private String product_name;
  private double selling_price;
  private int product_quantity;
  private double line_item_price;
  private LocalDate date;

    public Lineitem(int product_id, String product_name, int product_quantity, double line_item_price) {
        this.product_id = product_id;
        this.product_name = product_name;
        this.product_quantity = product_quantity;
        this.line_item_price = line_item_price;
    }

    public Lineitem(int product_id, int product_quantity) {
        this.product_id = product_id;
        this.product_quantity = product_quantity;
    }
  
    public Lineitem(int order_id, int product_id, String product_name, double selling_price, int product_quantity, double line_item_price, LocalDate date) {
        this.order_id=order_id;
        this.product_id = product_id;
        this.product_name = product_name;
        this.selling_price = selling_price;
        this.product_quantity = product_quantity;
        this.line_item_price = line_item_price;
        this.date = date;
    }

    public int getLine_item_id() {
        return line_item_id;
    }


    public void setLine_item_id(int line_item_id) {
        this.line_item_id = line_item_id;
    }


    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public double getselling_price() {
        return selling_price;
    }

    public void setselling_price(double selling_price) {
        this.selling_price = selling_price;
    }

    public int getProduct_quantity() {
        return product_quantity;
    }

    public void setProduct_quantity(int product_quantity) {
        this.product_quantity = product_quantity;
    }

    public double getLine_item_price() {
        return line_item_price;
    }

    public void setLine_item_price(double line_item_price) {
        this.line_item_price = line_item_price;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
  
}
