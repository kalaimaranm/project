/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.buisnesslayer;

import com.mordernmart.dao.mysqlimpl.DbSelection;
import com.mordernmart.dao.mysqlimpl.MySqlKhataBookDaoImpl;
import com.mordernmart.dao.mysqlimpl.UserDaoImpl;
import com.mordernmart.daointerface.KhataBookDao;
import com.mordernmart.daointerface.UserDao;
import com.mordernmart.model.User;
import java.util.Objects;

/**
 *
 * @author bas200186
 */
public class UserBuisnessLogicImpl implements UserBuisnessLogic
{
    private DbSelection getdb;
    public UserBuisnessLogicImpl(String a)
    {
        System.out.println("UserBuisnessLogicImpl");
        this.getdb=new DbSelection(a);
    }

    @Override
    public User createUser(User user) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean validateUser(User user)
    {
        System.out.println(user.getUserName());
        System.out.print("from validate user");
        if(Objects.nonNull(user.getUserName())&&Objects.nonNull(user.getPassWord()))
        {
         System.out.println("hello");
         if(getdb.getGetdb().getUserDao().validateUser(user))
         {
             return true;
         }
         else
         {
             return false;
        }
        }
        return false;
    }

    @Override
    public boolean deleteUser(int userid) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean updateUser() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public User viewUser(int userid) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
 
    
}
