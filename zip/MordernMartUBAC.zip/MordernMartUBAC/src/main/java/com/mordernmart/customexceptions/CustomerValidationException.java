/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mordernmart.customexceptions;

/**
 *
 * @author bas200186
 */
public class CustomerValidationException extends RuntimeException 
{

    public CustomerValidationException() {
    }

    public CustomerValidationException(String message) {
        super(message);
    }

    public CustomerValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public CustomerValidationException(Throwable cause) {
        super(cause);
    }

    public CustomerValidationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    
}
