
package com.mordernmart.model;

import java.time.LocalDate;
import java.util.List;

public class Order 
{
    private int cust_id;
    private int order_id;
    private double total_amount;
    private int lineitems;
    private int quantity;
    private LocalDate date;
    private List lineitem;
      private String orderstatus;

    public Order(int cust_id, int order_id, double total_amount, int quantity, LocalDate date, String orderstatus) {
        this.cust_id = cust_id;
        this.order_id = order_id;
        this.total_amount = total_amount;
        this.quantity = quantity;
        this.date = date;
        this.orderstatus = orderstatus;
    }

    public String getOrderstatus() {
        return orderstatus;
    }

    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }
    

    
    
    public Order(int cust_id,  double total_amount, int lineitems, int quantity,  LocalDate date) {
        this.cust_id = cust_id;
        this.total_amount = total_amount;
        this.lineitems = lineitems;
        this.quantity = quantity;
        this.date = date;
    }


    public int getCust_id() {
        return cust_id;
    }

    public void setCust_id(int cust_id) {
        this.cust_id = cust_id;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public double getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(double total_amount) {
        this.total_amount = total_amount;
    }

    public int getLineitems() {
        return lineitems;
    }

    public void setLineitems(int lineitems) {
        this.lineitems = lineitems;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
  
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public List getLineitem() {
        return lineitem;
    }

    public void setLineitem(List lineitem) {
        this.lineitem = lineitem;
    }
    @Override
    public String toString() {
        return "Order{" + "cust_id=" + cust_id + ", order_id=" + order_id + ", total_amount=" + total_amount + ", lineitems=" + lineitems + ", quantity=" + quantity +  ", date=" + date + '}';
    }
  
}
