const username1=document.querySelector('.username');
const password1=document.querySelector('.passwordtext');
const loginbutton=document.querySelector('.login-button');
loginbutton.addEventListener('click',function()
{
    console.log(username1.value);
    console.log(password1.value);
});
