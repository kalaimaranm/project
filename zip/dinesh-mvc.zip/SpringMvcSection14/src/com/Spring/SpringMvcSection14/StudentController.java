package com.Spring.SpringMvcSection14;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class StudentController 
{	
@RequestMapping("/showForm")
public String showForm(Model theModel)
{
	theModel.addAttribute("student",new Student());
	return "StudentMainMenu";
}
@RequestMapping("/processForm")
public String processForm(@ModelAttribute("student")Student theStudent)
{
	System.out.println(theStudent.getFirstName());
	System.out.println(theStudent.getLastName());
	return "ConfirmStudent";
}
}
