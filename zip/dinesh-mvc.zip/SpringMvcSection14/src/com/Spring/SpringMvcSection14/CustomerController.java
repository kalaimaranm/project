package com.Spring.SpringMvcSection14; 

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CustomerController {
	@InitBinder
	public void initBinder(WebDataBinder dataBinder)
	{
		//for trimming the String
		System.out.println("Start of initBinder");
		StringTrimmerEditor stringTrimmerEditor=new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class,stringTrimmerEditor);
		System.out.println("End of initBinder");

    }
	@RequestMapping("/")
	public String showForm()
	{
		return "MainMenu";
	}
	@RequestMapping("/showForm")
	public String showForm(Model theModel)
	{
		System.out.println("Starting of showForm");
		theModel.addAttribute("customer",new Customer());
		System.out.println("Ending of showForm");

		return "CustomerForm";
	}
	@RequestMapping("/SpringMvcSection14")
	public String SpringMvcSection14()
	{

		return "showForm";
	}
	@RequestMapping("/processForm")
	public String processForm
	(@Valid @ModelAttribute("customer") Customer theCustomer ,BindingResult theBindingResult)
	{
		
		System.out.println("Starting of processForm");
		System.out.println(theBindingResult);

		if(theBindingResult.hasErrors())
		{
			System.out.println("Ending of processForm");

			return "CustomerForm";
		}
		else 
		{
			System.out.println("Ending of processForm");

			return "CustomerConfirmation";
		}
	}
}
