package com.Spring.SprTwo;

public class TrackCoach implements Coach
{
	  private FortuneService fortuneCookie;

	    public TrackCoach(FortuneService fortuneCookie) {
	        this.fortuneCookie = fortuneCookie;
	    }

	    TrackCoach() {
	    }
	     @Override
	    public String getDailyWorkout()
	    {
	        return "Run 5KM hard";
	    }

	    @Override
	    public String getDailyFortune() {
	        return "Track coach Fortune";// Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
	    }

}
