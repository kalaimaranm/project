package com.Spring.SprOne;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringLoader {
	public static void main(String[]args) {
	 //load the Spring configuration file
    ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext4.xml");
   
    //REtrive the Bean from the Spring Container
   TennisCoach thecoach=context.getBean("tennisCoach",TennisCoach.class);
    //call the methods on the bean
    System.out.println(thecoach.getDailyWorkout()); 
    System.out.println(thecoach.getEmail()); 
    System.out.println(thecoach.getTeam());

    
    
    //Dependency Injection
//     System.out.println( thecoach.getDailyFortune());
//     System.out.println(thecoach.getEmail());
//     System.out.println(thecoach.getTeam());
    //close the context
    context.close();
	}
}
