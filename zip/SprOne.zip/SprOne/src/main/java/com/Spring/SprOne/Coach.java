package com.Spring.SprOne;

public interface Coach
{
    public String getDailyWorkout();

}
