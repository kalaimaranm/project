package com.Spring.SprTwo;

public class BaseBallCoach implements Coach
{
	 private FortuneService fortuneCookie;
     private String team;
     private int no;

 public BaseBallCoach(FortuneService fortuneCookie) {
     this.fortuneCookie = fortuneCookie;
 }

 BaseBallCoach() {
 }

 public BaseBallCoach(String team, int no) {
     this.team = team;
     this.no = no;
 }

public String getDailyWorkout()  
{
   return "Spend 30 minutes on batting practise";
}

 @Override
 public String getDailyFortune() {
      return "BaseballCoach Fortune";// Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
 }
}
