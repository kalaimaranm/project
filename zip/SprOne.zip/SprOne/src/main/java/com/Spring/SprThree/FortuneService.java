package com.Spring.SprThree;

public interface FortuneService {
public String getDailyFortune();
}
