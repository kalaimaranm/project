package com.Spring.SprThree;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TennisCoach implements Coach 
{
private FortuneService thefortune;
//
//@Autowired
//public TennisCoach(FortuneService thefortune) {
//	this.thefortune = thefortune;
//}
TennisCoach()
{
	System.out.println("In Constructor");
	}

	@Override
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "TennisCoach Class";
	}
	public FortuneService getThefortune() {
		return thefortune;
	}
	@Autowired
	public void setThefortune(FortuneService thefortune) {
		System.out.println("In the Setter Fortune");
		this.thefortune = thefortune;
	}
	@Override
public String getDailyFortune()
{
	return thefortune.getDailyFortune();
	}

}
