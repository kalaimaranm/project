package com.Spring.SprOne;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringLoader2 {
	public static void main(String[]args) {
		 //load the Spring configuration file
	    AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(SportConfig.class);
	   
	    //REtrive the Bean from the Spring Container
	  SwimCoach thecoach=context.getBean("swim",SwimCoach.class);
	    //call the methods on the bean
//	    System.out.println(thecoach.getDailyWorkout()); 
	    System.out.println(thecoach.getEmail()); 
	    System.out.println(thecoach.getTeam());

	    
	    
	    //Dependency Injection
//	     System.out.println( thecoach.getDailyFortune());
//	     System.out.println(thecoach.getEmail());
//	     System.out.println(thecoach.getTeam());
	    //close the context
	    context.close();
		}
}
