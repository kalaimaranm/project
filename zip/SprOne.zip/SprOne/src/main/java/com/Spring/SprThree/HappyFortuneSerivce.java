package com.Spring.SprThree;

import org.springframework.stereotype.Component;

@Component
public class HappyFortuneSerivce implements FortuneService {

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
			return "Fortune For TennisCoach";

	}


}
