package com.Spring.SprTwo;

public interface FortuneService {
    public String getFortune();


}
