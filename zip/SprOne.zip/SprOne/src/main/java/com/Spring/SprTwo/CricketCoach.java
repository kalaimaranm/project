package com.Spring.SprTwo;

public class CricketCoach implements Coach
{
	private FortuneService fortuneCookie;
    private String email;
    private String team;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    CricketCoach(FortuneService fortuneCookie,String email,String team) {
    System.out.println("Argument constructor in CricketCoach");

        this.fortuneCookie = fortuneCookie;
        this.email=email;
        this.team=team;
    }

   

    CricketCoach() 
    {
        System.out.println("No argm Constructor in CricketCoach");
    }
 public void setFortuneCookie(FortuneService fortuneCookie) {
             System.out.println("Setter method in CricketCoach");

    }
    @Override
    public String getDailyWorkout() {
        return "Cricket daily exersices"; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getDailyFortune() {
        return "Cricket daily fortune"; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
