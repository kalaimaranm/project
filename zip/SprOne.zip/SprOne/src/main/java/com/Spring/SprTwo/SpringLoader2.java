package com.Spring.SprTwo;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringLoader2 {
	public static void main(String[] args) 
    {
       //load the Spring configuration file
       ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext2.xml");
       System.out.println("Please Select The Coach");
       System.out.println("1)BaseBall Coach");
       System.out.println("2)Track Coach");
       System.out.println("3)Cricket Coach");

       Scanner sc=new Scanner(System.in); 
       int a=sc.nextInt();
       String str="";
       switch(a)
       {
           case 1:str="BaseBall";
                   break;
           case 2:str="TrackBall";
                  break;
           case 3:str="CricketBall";
                  break;
       }
        
       System.out.println("Please Select The Coach");
       System.out.println("1)BaseBall Coach");
       System.out.println("2)Track Coach");
       System.out.println("3)Cricket Coach");

       int a1=sc.nextInt();
       String str1="";
       switch(a)
       {
           case 1:str1="BaseBall";
                   break;
           case 2:str1="TrackBall";
                  break;
           case 3:str1="CricketBall";
                  break;
       }
       //REtrive the Bean from the Spring Container
      Coach thecoach=context.getBean(str,Coach.class);
      Coach thecoach1=context.getBean(str1,Coach.class);

       //call the methods on the bean
       System.out.println(thecoach.getDailyWorkout());  
       
       //Dependency Injection
        System.out.println( thecoach.getDailyFortune());
        
        System.out.println(thecoach+"!+"+thecoach1);
        //for trackcoach seperate obj
        //for Trackcoach same obj

//        System.out.println(thecoach.getEmail());
//        System.out.println(thecoach.getTeam());
       //close the context
       context.close();
}
}
