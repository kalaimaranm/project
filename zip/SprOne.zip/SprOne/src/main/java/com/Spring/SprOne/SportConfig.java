package com.Spring.SprOne;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:sport2.properties")
public class SportConfig {
@Bean
public Coach swim()
{
	SwimCoach s1=new SwimCoach();
	return s1;
	}
}
