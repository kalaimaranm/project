package com.Spring.SprTwo;

public class MyApp {
	 public static void main(String[] args) {
	       Coach thecoach=new BaseBallCoach();
	       System.out.println(thecoach.getDailyWorkout());
	       Coach trackcoach=new TrackCoach();
	       
	    }
}
