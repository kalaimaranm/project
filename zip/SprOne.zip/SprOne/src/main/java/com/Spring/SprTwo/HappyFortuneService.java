package com.Spring.SprTwo;

public class HappyFortuneService implements FortuneService {
	 public String getFortune()
	 {
	     return "Bad Day For U";
	 }    
}
