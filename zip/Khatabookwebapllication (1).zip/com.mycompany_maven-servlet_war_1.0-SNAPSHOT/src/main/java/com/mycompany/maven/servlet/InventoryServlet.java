
package com.mycompany.maven.servlet;

import dao.mysql.KhataBookDaoImpl;
import idao.KhataBookDao;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import model.Inventory;


public class InventoryServlet extends GenericServlet {

  @Override
  public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
    KhataBookDao kbd = new KhataBookDaoImpl();
    PrintWriter pw = response.getWriter();
    if (this.getServletContext().getInitParameter("Database").equals("mysql")) {
      int i = Integer.parseInt(request.getParameter("k"));
      switch (i) {
        case 1 -> {

          Inventory inv = new Inventory();
          int proId = Integer.parseInt(request.getParameter("productid"));
          inv.setProductId(proId);
          inv.setProName(request.getParameter("productname"));
          int quan = Integer.parseInt(request.getParameter("quantity"));
          double price = Double.parseDouble(request.getParameter("price"));
          inv.setQuantity(quan);
          inv.setPrice(price);
          int k = kbd.getProductDaoObj().addProduct(inv);
          if (k != 0) {
            pw.print("<h1>product added successfully</h1>");
          } else {
            pw.print("<h1>product not added successfully</h1>");
          }
        }
        case 2 -> {

          List<Inventory> viewProduct = kbd.getProductDaoObj().viewAll();
          pw.print(" <h1>Product Details <h1> ");
          pw.print(" <table border=1 rules=all>  ");
          pw.print(" <tr>");
          pw.println(" <th>PRODUCT ID</th> ");
          pw.println(" <th>PRODUCT NAME</th> ");
          pw.println("<th>QUANTITY</th>");
          pw.println(" <th>PRICE</th>");

          pw.println(" </tr>");
          for (Inventory inv : viewProduct) {
            pw.println(" <tr> ");
            pw.println(" <td>" + inv.getProductId() + "</td>");
            pw.println(" <td>" + inv.getProName() + "</td>");
            pw.println(" <td>" + inv.getQuantity() + "</td>");
            pw.println(" <td>" + inv.getPrice() + "</td>");

            pw.println(" </tr> ");
          }
          pw.print(" </table >  ");
          pw.print("""   
                                 <form action='inventorymenu.html'><input type='submit' value='back'></form>                                  """);
        }
        case 3 -> {
          // pw.print(request.getParameter("getpd"));
          List<Inventory> viewParInventory = kbd.getProductDaoObj().viewProduct(Integer.parseInt(request.getParameter("getpd")));
          pw.print(" <h1>Product Detail <h1> ");
          pw.print(" <table border=1 rules=all>  ");
          pw.print(" <tr>");
          pw.print(" <table border=1 rules=all>  ");
          pw.print(" <tr>");
          pw.println(" <th>PRODUCT ID</th> ");
          pw.println(" <th>PRODUCT NAME</th> ");
          pw.println("<th>QUANTITY</th>");
          pw.println(" <th>PRICE</th>");

          pw.println(" </tr>");
          for (Inventory inv : viewParInventory) {
            pw.println(" <tr> ");
            pw.println(" <td>" + inv.getProductId() + "</td>");
            pw.println(" <td>" + inv.getProName() + "</td>");
            pw.println(" <td>" + inv.getQuantity() + "</td>");
            pw.println(" <td>" + inv.getPrice() + "</td>");

            pw.println(" </tr> ");
          }
          pw.print(" </table >  ");
          pw.print("""   
                    <form action='inventorymenu.html'><input type='submit' value='back'></form>   """);

        }
        case 4 -> {
          Inventory inventory = new Inventory();
          inventory.setProductId(Integer.parseInt(request.getParameter("paid")));
          inventory.setQuantity(Integer.parseInt(request.getParameter("quantity")));
          int update = kbd.getProductDaoObj().updateProduct(inventory);
          if (update != 0) {
            pw.print("<h1>Data updated Successfully</h1>");
          } else {
            pw.print("<h1>Not updated</h1>");
          }

        }


      }
    }
  }

}
