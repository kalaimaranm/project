
package dao.mysql;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class Input {
  static BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
 }
