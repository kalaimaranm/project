
package dao.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MySqlConnection {

  public static  Connection createConnection() throws SQLException, ClassNotFoundException {
    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
    } catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
    String url = "jdbc:mysql://bassure.in:3306/vj_db8";
    String uname = "vjarr";
    String pass = "arr2009";
    Class.forName("com.mysql.jdbc.Driver");
    return DriverManager.getConnection(url, uname, pass);
  }
}
