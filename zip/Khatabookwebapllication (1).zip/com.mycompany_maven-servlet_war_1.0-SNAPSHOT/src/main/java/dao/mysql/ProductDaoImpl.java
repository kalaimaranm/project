package dao.mysql;

import static dao.mysql.CustomerDaoImpl.mys;
import idao.ProductDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Inventory;

public class ProductDaoImpl implements ProductDao {

    @Override
    public Inventory getProductDetails(int product_id) {
        Inventory inv = null;
        try {
            String viewQuery = "select * from Inventory where product_id=?";

            PreparedStatement ps_e = MySqlConnection.createConnection().prepareStatement(viewQuery);

            ps_e.setInt(1, product_id);
            ResultSet rs3 = ps_e.executeQuery();
            rs3.next();
            inv = new Inventory(rs3.getInt(1), rs3.getString(2), rs3.getInt(3), rs3.getDouble(4));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return inv;
    }

    @Override
    public void stockUpdate(Inventory inv) {
        try {
            PreparedStatement ps_h = MySqlConnection.createConnection().prepareStatement("update product set quantity=? where product_id=?");
            ps_h.setInt(1, inv.getQuantity());
            ps_h.setInt(2, inv.getProductId());
            ps_h.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public int addProduct(Inventory p) {
        int r = 0;
        String addProd = "insert into Inventory values(?,?,?,?)";
        try (Connection con = mys.createConnection()) {
            PreparedStatement ps_d = con.prepareStatement(addProd);
            ps_d.setInt(1, p.getProductId());
            ps_d.setString(2, p.getProName());
            ps_d.setInt(3, p.getQuantity());
            ps_d.setDouble(4, p.getPrice());
            r = ps_d.executeUpdate();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return r;
    }

    @Override
    public List<Inventory> viewProduct(int productId) {
        List<Inventory> l = new ArrayList<>();
        try {
            String viewQuery = "select * from Inventory where product_id=?";
            Connection con = mys.createConnection();
            PreparedStatement ps_e = con.prepareStatement(viewQuery);

            ps_e.setInt(1, productId);
            ResultSet rs3 = ps_e.executeQuery();

            while (rs3.next()) {
                l.add(new Inventory(rs3.getInt(1), rs3.getString(2), rs3.getInt(3), rs3.getDouble(4)));
            }

        } catch (SQLException sqe) {
            System.err.println(sqe);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return l;
    }

    @Override
    public int updateProduct(Inventory i) {
        int update = 0;
        ProductDaoImpl pd = new ProductDaoImpl();
        try {
            String updQuery = "update Inventory set quantity=? where product_id=?";
            Connection connection = mys.createConnection();
            PreparedStatement ps_c = connection.prepareStatement(updQuery);
            Inventory i1 = pd.getProductDetails(i.getProductId());
            int updquantity = i1.getQuantity();
            ps_c.setInt(1, i.getQuantity() + updquantity);
            ps_c.setInt(2, i.getProductId());
            update = ps_c.executeUpdate();

        } catch (SQLException sqe) {
            sqe.printStackTrace();
            System.err.println(sqe);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return update;
    }

    @Override
    public List<Inventory> viewAll() {
        List<Inventory> inventoryList = new ArrayList<>();
        try (Connection con = mys.createConnection();) {
            String view_all = "Select * from Inventory";
            PreparedStatement ps_d = con.prepareStatement(view_all);
            ResultSet rs2 = ps_d.executeQuery();
            while (rs2.next()) {
                inventoryList.add(new Inventory(rs2.getInt(1), rs2.getString(2), rs2.getInt(3), rs2.getDouble(4)));
            }

        } catch (SQLException sqe) {
            sqe.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return inventoryList;
    }
}
