
package dao.mysql;

import idao.LineItemDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.LineItems;

public class LineItemDaoImpl implements LineItemDao {

  @Override
  public void addLineItems(Connection con, int orderId, int productId, String p_name, int quantity, double price) {
    LineItems li = new LineItems(orderId, productId, p_name, quantity, price);
    PreparedStatement ps_l;
    try {
      ps_l = con.prepareStatement("insert into lineitems values(?,?,?,?,?)");

      ps_l.setInt(1, li.getOrderId());
      ps_l.setInt(2, li.getProductId());
      ps_l.setString(3, li.getProName());
      ps_l.setInt(4, li.getQuantity());
      ps_l.setDouble(5, li.getPrice());
      ps_l.executeUpdate();
    } catch (SQLException sqe) {
      sqe.printStackTrace();

    }
  }
}
