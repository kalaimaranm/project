
package model;


public class Inventory {

  private int productId;
  private String proName;
  private int quantity;
  private double price;

  public Inventory() {

  }

  public Inventory(int productId, String proName, int quantity, double price) {
    this.productId = productId;
    this.proName = proName;
    this.quantity = quantity;
    this.price = price;

  }



  public int getProductId() {
    return productId;
  }

  public void setProductId(int productId) {
    this.productId = productId;
  }

  public String getProName() {
    return proName;
  }

  public void setProName(String proName) {
    this.proName = proName;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  public double getPrice() {
    return price;
  }

  public void setPrice(double price) {
    this.price = price;
  }

}
