
package idao;


public interface KhataBookDao {

  public CustomerDao getCustomerDaoObj();

  public ProductDao getProductDaoObj();

  public OrderDao getOrderDaoObj();

  public LineItemDao getLineItemDao();

  public PaymentDao getPaymentDaoObj();

}
