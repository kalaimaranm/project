
package idao;

import java.sql.Connection;


public interface LineItemDao {
  public void addLineItems(Connection con, int orderId, int productId, String p_name, int quantity, double price);
  
}
