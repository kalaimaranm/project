
package idao;

import java.sql.Connection;
import model.Payment;


public interface PaymentDao {
  public int pay(Payment p);
  
}
