
package idao;

import java.sql.Connection;
import java.util.List;
import model.Inventory;


public interface ProductDao {

  public int addProduct(Inventory p);

  public List<Inventory> viewProduct(int productId);

  public int updateProduct(Inventory p);

  public List<Inventory> viewAll();

  public Inventory getProductDetails(int product_id);

  public void stockUpdate(Inventory inv);

}
