
package idao;

import java.sql.Connection;
import model.LineItems;
import model.Orders;


public interface OrderDao {
  public boolean addOrder(Orders o,LineItems []l);
  public void show();
  
}
