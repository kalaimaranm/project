
package idao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import model.Customer;
import model.OrderedDetails;


public interface CustomerDao {

  public int addCustomer(Customer c);

  public int updateCustomer(Customer customerr);

  public List<Customer> viewCustomer(String MobileNumber);

  public List<Customer> viewAll();

  public void statistics(Connection con);

  public int updateCustomerBalance(Customer c);

  public Customer getCusdetails(String phone_no);

  public ArrayList<OrderedDetails> viewDetails();

  public Customer viewCustomerr(String mobileNumber);
  
  public int updateCustomerBalance(int cusId,double amount) ;
}

