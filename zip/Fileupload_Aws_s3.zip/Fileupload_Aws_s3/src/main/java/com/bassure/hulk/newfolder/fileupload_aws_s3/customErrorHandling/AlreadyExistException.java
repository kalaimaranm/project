package com.bassure.hulk.newfolder.fileupload_aws_s3.customErrorHandling;

public class AlreadyExistException extends RuntimeException{
    
    public AlreadyExistException(String message){
        super(message);
    }
}
