package com.bassure.hulk.newfolder.fileupload_aws_s3.customErrorHandling;

public class NotFoundException extends RuntimeException{

    public NotFoundException(String message) {
        super(message);
    }
    
}
