package com.bassure.hulk.newfolder.fileupload_aws_s3.service;

import com.bassure.hulk.newfolder.fileupload_aws_s3.response.FileResponse;
import com.bassure.hulk.newfolder.fileupload_aws_s3.response.ResponseInfo;
import java.util.List;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {

    public ResponseInfo uploadFile(MultipartFile file);

    public ByteArrayResource downloadFile(String fileName);

    public ResponseInfo deleteFile(String fileName);

    public ResponseInfo updateFile(String fileName, String bucketName, MultipartFile file);
    
}
