package com.bassure.hulk.newfolder.fileupload_aws_s3.serviceImplementation;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.util.IOUtils;
import com.bassure.hulk.newfolder.fileupload_aws_s3.customErrorHandling.AlreadyExistException;
import com.bassure.hulk.newfolder.fileupload_aws_s3.customErrorHandling.FileNameNotFoundException;
import com.bassure.hulk.newfolder.fileupload_aws_s3.customErrorHandling.FilePathNotFoundException;
import com.bassure.hulk.newfolder.fileupload_aws_s3.customErrorHandling.NotFoundException;
import com.bassure.hulk.newfolder.fileupload_aws_s3.model.FileUpload;
import com.bassure.hulk.newfolder.fileupload_aws_s3.repository.FileUploadRepository;
import com.bassure.hulk.newfolder.fileupload_aws_s3.response.FileResponse;
import com.bassure.hulk.newfolder.fileupload_aws_s3.response.ResponseInfo;
import com.bassure.hulk.newfolder.fileupload_aws_s3.service.FileUploadService;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileUploadServiceImplementation implements FileUploadService {

    @Value("${application.bucket.name}")
    private String bucketName;

    @Autowired
    private AmazonS3 s3Client;

    @Autowired
    private FileUploadRepository fileUploadRepository;

//    private String filePath = "D:\\arun\\uploaded files\\";
    private String filePath = "/home/bassure/Desktop/New Folder/";

    @Override
    public ResponseInfo uploadFile(MultipartFile file) {
//        File fileObj = convertMultiPartFileToFile(file);
        FileResponse fileResponse = new FileResponse();
        ResponseInfo responseInfo = new ResponseInfo();

        String fileName = file.getOriginalFilename();
        if (Objects.isNull(file.getOriginalFilename())) {
            throw new FileNameNotFoundException("File Name Must not be Null.");
        }
        String checkFileName = fileUploadRepository.existsByFilename(fileName);
        if (Objects.nonNull(checkFileName)) {
            fileName = fileName + java.time.LocalDateTime.now() + "";
        }

        if (Objects.nonNull(fileUploadRepository.removeFile(fileName))) {
            throw new AlreadyExistException(fileName + " is already exists");
        }

//        s3Client.putObject(new PutObjectRequest(bucketName, fileName, fileObj));
        try {
            file.transferTo(new File(filePath + fileName));
        } catch (IOException ex) {
            throw new FilePathNotFoundException("File Path error in Server.");
        }

        FileUpload fileUpload = new FileUpload();
        fileUpload.setFileName(fileName);
        fileUpload.setBucketName(bucketName);
        fileUpload.setUploadedTime(java.time.LocalDateTime.now() + "");
        fileUploadRepository.save(fileUpload);

        fileResponse.setBucketName(bucketName);
        fileResponse.setFileName(fileName);
        fileResponse.setFilePath(filePath + fileName);

//            fileObj.delete();
        responseInfo.setCode("1300");
        responseInfo.setValue(fileResponse);
        responseInfo.setError(null);
        return responseInfo;

    }

    @Override
    public ByteArrayResource downloadFile(String fileName) {
//        S3Object s3Object = s3Client.getObject(bucketName, fileName);
//        S3ObjectInputStream inputStream = s3Object.getObjectContent();

        File fileDownload = new File(filePath + fileName);
        InputStream inputStream = null;
        byte[] content = null;
        ByteArrayResource resource = null;

        try {
            inputStream = new FileInputStream(fileDownload);
            if (Objects.isNull(inputStream)) {
                throw new NullPointerException(fileName + " not found");
            }
        } catch (FileNotFoundException ex) {
            try {
                throw new FileNotFoundException(fileName + " not found");
            } catch (FileNotFoundException ex1) {
                Logger.getLogger(FileUploadServiceImplementation.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }

        try {
            content = IOUtils.toByteArray(inputStream);
            resource = new ByteArrayResource(content);
        } catch (IOException e) {
            try {
                throw new FileNotFoundException(fileName + " not found");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FileUploadServiceImplementation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return resource;
    }

    @Override
    public ResponseInfo updateFile(String fileName, String bucketName, MultipartFile file) {
        ResponseInfo responseInfo = new ResponseInfo();
        FileUpload fileUpdate = fileUploadRepository.removeFile(fileName);

        if (Objects.isNull(fileUpdate)) {
            try {
                throw new FileNotFoundException(fileName + " not found");
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FileUploadServiceImplementation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        fileUpdate.setUploadedTime(java.time.LocalDateTime.now() + "");
//        File fileObj = convertMultiPartFileToFile(file);
//        s3Client.deleteObject(bucketName, fileName);
//        s3Client.putObject(new PutObjectRequest(bucketName, fileName, fileObj));
        try {
            File fileToDelete = new File(filePath + fileName);
            fileToDelete.delete();
            file.transferTo(new File(filePath + fileName));
        } catch (IOException ex) {
            throw new FilePathNotFoundException("File Path error in Server.");
        }
        fileUploadRepository.save(fileUpdate);
        responseInfo.setCode("1300");
        responseInfo.setValue(fileName + " Updated Succesfully");
        responseInfo.setError(null);
        return responseInfo;
    }

    @Override
    public ResponseInfo deleteFile(String fileName) {
//        s3Client.deleteObject(bucketName, fileName);
        ResponseInfo responseInfo = new ResponseInfo();
        FileUpload fileupload = fileUploadRepository.removeFile(fileName);
        System.out.println(fileupload);
        fileupload.setDeleted(true);
        fileupload.setDeleteTime(java.time.LocalDateTime.now() + "");
        fileUploadRepository.save(fileupload);
        responseInfo.setCode("1300");
        responseInfo.setValue(fileName + " Removed Successfully");
        responseInfo.setError(null);
        return responseInfo;
    }

//    public List<ResponseInfo> uploadMultipleFiles(List<MultipartFile> files) {
//        List<ResponseInfo> fileResponses = new ArrayList<>();
//        for (MultipartFile file : files) {
//            ResponseInfo upload = uploadFile(file);
//            fileResponses.add(upload);
//        }
//        return fileResponses;
//    }
}
