package com.bassure.hulk.newfolder.fileupload_aws_s3.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name = "fileupload")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class FileUpload {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "file_id")
    private int fileId;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "bucket_name")
    private String bucketName;

    @Column(name = "uploaded_time")
    private String uploadedTime;
    
    @Column(name="is_delete")
    private boolean deleted = Boolean.FALSE;
    
    @Column(name="deleted_date")
    private String deleteTime;
    
    
}
