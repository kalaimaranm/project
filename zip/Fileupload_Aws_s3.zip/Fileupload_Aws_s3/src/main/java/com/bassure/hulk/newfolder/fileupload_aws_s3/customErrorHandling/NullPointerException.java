package com.bassure.hulk.newfolder.fileupload_aws_s3.customErrorHandling;

public class NullPointerException extends RuntimeException{

    public NullPointerException(String message) {
        super(message);
    }
    
}
