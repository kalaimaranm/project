package com.bassure.hulk.newfolder.fileupload_aws_s3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fileupload_Aws_s3 {

    public static void main(String[] args) {
        SpringApplication.run(Fileupload_Aws_s3.class, args);
    }
}
