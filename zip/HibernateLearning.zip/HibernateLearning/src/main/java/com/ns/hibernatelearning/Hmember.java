package com.ns.hibernatelearning;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "hibmember")
public class Hmember implements Serializable {

    @Id
    @Column(name = "member_id")
    private long memberId;

     @Column(name = "name")
    private String name;

      @Column(name = "mobile")
    private String mobile;

    public Hmember() {
    }

    public Hmember(long memberId, String name, String mobile) {
        this.memberId = memberId;
        this.name = name;
        this.mobile = mobile;
    }

    public long getMemberId() {
        return memberId;
    }

    public void setMemberId(long memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    @Override
    public String toString() {
        return "Hmember{" + "memberId=" + memberId + ", name=" + name + ", mobile=" + mobile + '}';
    }

    
}
