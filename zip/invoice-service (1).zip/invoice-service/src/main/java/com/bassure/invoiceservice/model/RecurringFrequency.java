/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bassure.invoiceservice.model;

/**
 *
 * @author SathishKumar
 */
public enum RecurringFrequency {
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY
}
