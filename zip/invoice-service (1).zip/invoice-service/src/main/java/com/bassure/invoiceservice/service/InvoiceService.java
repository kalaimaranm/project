package com.bassure.invoiceservice.service;

import com.bassure.invoiceservice.exception.InvoiceNotFoundException;
import com.bassure.invoiceservice.model.Invoice;
import com.bassure.invoiceservice.repository.InvoiceRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    public Invoice createInvoice(Invoice invoice) {
        invoice.getInvoiceContent().stream().forEach(cnsmr -> cnsmr.setInvoice(invoice));
        return invoiceRepository.save(invoice);
    }

    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }
    
    public List<Invoice> getAllInvoicesByTenantId(Integer tenantId) {
        return invoiceRepository.findAllByTenantId(tenantId);
    }
    
    public List<Invoice> getAllInvoicesByClientId(Integer tenantId , Integer clientId) {
        return invoiceRepository.findAllByClientId(tenantId,clientId);
    }
    
    public Invoice getInvoice(Integer tenantId , Integer clientId , Integer invoiceId) {
        return invoiceRepository.findById(tenantId,clientId,invoiceId).orElseThrow(() -> new InvoiceNotFoundException());
    }

    
}
