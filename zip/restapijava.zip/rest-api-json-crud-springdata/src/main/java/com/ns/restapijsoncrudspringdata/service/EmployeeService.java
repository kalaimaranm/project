package com.ns.restapijsoncrudspringdata.service;

import com.ns.restapijsoncrudspringdata.entity.Employee;
import java.util.List;
//import ns.main.restapijsoncrud.entity.Employee;

public interface EmployeeService {
    
    public List<Employee> findAll();
    
    public Employee findById(int id);
    
    public void deleteById(int id);
    
    public Employee save(Employee employee);
    
    
    
}
