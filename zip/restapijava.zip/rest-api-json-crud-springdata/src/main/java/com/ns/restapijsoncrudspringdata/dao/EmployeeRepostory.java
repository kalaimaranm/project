package com.ns.restapijsoncrudspringdata.dao;

import com.ns.restapijsoncrudspringdata.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepostory extends JpaRepository<Employee, Integer> {

    

}
