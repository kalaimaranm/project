package com.ns.restapijsoncrudspringdata.rest;

import com.ns.restapijsoncrudspringdata.entity.Employee;
import com.ns.restapijsoncrudspringdata.service.EmployeeService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@CrossOrigin()
public class EmployeeRestController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/employees")
    public List<Employee> findAll() {

        return employeeService.findAll();
    }

    @GetMapping("/employee/{employeeId}")
    public Employee getEmployeeById(@PathVariable int employeeId) {
        System.out.println("iam reached");
        Employee employee = employeeService.findById(employeeId);
        System.out.println(employee);

        if (employee == null) {

            throw new EmployeeNotFound("Employee Not found " + employeeId);
        }

        return employee;
    }

    @PostMapping("/employees")
    public Employee addEmployee(@RequestBody Employee employee) {

        Employee emp = employeeService.save(employee);

        return emp;
    }

    @PutMapping("/employees")

    public Employee updateEmployee(@RequestBody Employee employee) {

        Employee emp = employeeService.save(employee);

        return emp;

    }

    @DeleteMapping("/employees/{employeeId}")
    public void deleteEmployee(@PathVariable int employeeId) {

        Employee emp = employeeService.findById(employeeId);

        if (emp == null) {
            throw new RuntimeException("EmployeeNotFound");
        }

        employeeService.deleteById(employeeId);

        //return "Deleted EmployeeId=" + employeeId;

    }

}
