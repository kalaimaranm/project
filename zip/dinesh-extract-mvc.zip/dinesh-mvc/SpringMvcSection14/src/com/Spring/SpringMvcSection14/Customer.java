package com.Spring.SpringMvcSection14;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.Spring.CustomValidation.CourseCode;

public class Customer {
@Pattern(regexp="^[a-zA-Z]{3,18}",message="Only alphabets are allowed length must be 3 to 18")
private String firstName;
@Pattern(regexp="^[a-zA-Z]{3,18}",message="Only alphabets are allowed length must be 3 to 18")
@NotNull(message="is Required")
@Size(min=3,message="Atleast 3 characters are Required")
private String lastName;
@NotNull(message="is Required")
@Min(value=0,message="Must be greater than or equal to Zero")
@Max(value=16,message="Must be greater than or equal to eigteen")
private Integer freePass;
@NotNull(message="is Required")
@Pattern(regexp="^[a-zA-Z0-9]{6}",message="Only 6 charcters or digits")
private String postalCode;

@CourseCode(value="SPR",message="It did not start with Spr")
private String courseCode;
public String getCourseCode() {
	return courseCode;
}
public void setCourseCode(String courseCode) {
	this.courseCode = courseCode;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getPostalCode() {
	return postalCode;
}
public void setPostalCode(String postalCode) {
	this.postalCode = postalCode;
}
public Integer getFreePass() {
	return freePass;
}
public void setFreePass(Integer freePass) {
	this.freePass = freePass;
}

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getlastName() {
	return lastName;
}
public void setlastName(String lastName) {
	this.lastName = lastName;
}

}
