package com.Spring.CustomValidation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CourseCodeConstraintValidator implements ConstraintValidator<CourseCode,String> {

	private String coursePrefix;
	@Override
	public void initialize(CourseCode thecoursecode) 
	{
		//(thecoursecode) The code initialized by the developer
		coursePrefix=thecoursecode.value();
		
	}

	@Override
	public boolean isValid(String thecode, ConstraintValidatorContext theconstraintvalidator)
	{
        boolean result;
        if(thecode!=null)
        {
        	//(thecode given by the user using the app checks with the assigned value coursePrefix)
        	result=thecode.startsWith(coursePrefix);
        }
        else 
        {
        	return true;
        }
		return result;
	}

}
