import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

export default function DeleteUser() {
  const param = useParams();

  let navigate = useNavigate();

  useEffect( ()=>{
    deleteUser()
  }

  )

  const deleteUser = async () => {
    const result = await axios.delete(
      `http://localhost:8080/api/employees/${param.id}`
    );
    navigate("/");
  };

  return (<div>


  </div>);
}
