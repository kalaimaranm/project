import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

export default function EditUser() {
  const param = useParams();

  let navigate = useNavigate();

  const [user, setUser] = useState({
    id: `${param.id}`,
    firstName: "",
    lastName: "",
    email: "",
  });
  //deconstructor

  const { id,firstName, lastName, email } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.put("http://localhost:8080/api/employees", user);
    navigate("/");
  };

  const loadUser=async ()=>{

    const result=await axios.get(`http://localhost:8080/api/employee/${param.id}`)
    setUser(result.data)
  }
  useEffect(()=>{
    loadUser();
  },[])

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6  offset-md-3 border rounded  p-4 mt-2 shadow">
          <h2 className="text-center m-4">Edit user details</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Name" className="form-label">
                user ID
              </label>
              <input
                placeholder="id"
                type="text"
                readOnly
                
                className="form-control"
                name="id"
                value={param.id}
                onChange={(e) => onInputChange(e)}
              ></input>

              <label htmlFor="Name" className="form-label">
                firstName
              </label>
              <input
                placeholder="Enter the firstName"
                type="text"
                className="form-control"
                name="firstName"
                value={firstName}
                onChange={(e) => onInputChange(e)}
              ></input>

              <label htmlFor="Name" className="form-label">
                lastName
              </label>
              <input
                placeholder="Enter the lastName"
                type="text"
                className="form-control"
                name="lastName"
                value={lastName}
                onChange={(e) => onInputChange(e)}
              ></input>

              <label htmlFor="Name" className="form-label">
                Email
              </label>
              <input
                placeholder="Enter the email"
                type="text"
                className="form-control"
                name="email"
                value={email}
                onChange={(e) => onInputChange(e)}
              ></input>
            </div>
            <button type="submit" className=" btn btn-outline-primary">
              
              submit
            </button>
            <Link
              type="submit"
              className=" btn btn-outline-danger m-2"
              to={"/"}
            >
              cancel
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
