import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar() {
    return (
        <div>
            <nav class="navbar navbar-expand-lg bg-body-tertiary navbar-dark bg-primary">
                <div className="container-fluid">
                    <a class="navbar-brand" href="#">Navbar</a>
                    <button className="navbar-toggler" type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation">
                        
                    </button>
                    <Link className=" btn-primary bprder- just btn btn-outline-light" to="/adduser">AddUser</Link>
                </div>
            </nav>

        </div>
    )
}
    