package in.bassure.skilling.s8.spring_web;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UsersRepository {

    private JdbcTemplate jdbcTemplate;

    public UsersRepository(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public boolean addNewUser(User user) {
        try {
            jdbcTemplate.update("INSERT INTO users VALUES(0, ?, ?)",
                    user.getName(), user.getPlanType());
            return true;
        } catch (Exception ex) {
            return false;
        }

    }

    public List<User> getUsers() {
        return jdbcTemplate.query("SELECT * FROM users", new UserRowMapper());
    }
}
