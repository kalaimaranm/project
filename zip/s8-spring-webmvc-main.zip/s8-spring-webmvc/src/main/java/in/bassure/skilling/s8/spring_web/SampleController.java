package in.bassure.skilling.s8.spring_web;

import java.time.LocalDateTime;
import java.util.Objects;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SampleController {

    @GetMapping(path = "/newUser3", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public User getNewUser3() {
        return new User(0, "Pawan", "GOLD");
    }

    @GetMapping(path = "/newUser2", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public User getNewUser2() {
        return new User(0, "Pawan", "GOLD");
    }

    @GetMapping("/newUser")
//    @ResponseBody
    public String getNewUser(ModelMap data) {
        data.addAttribute("user", new User(0, "James", "GOLD"));
        return "newUserPage";
    }

    @GetMapping("/hi/{userId}")
    @ResponseBody
    public String sayHello(
            @RequestParam(name = "un", required = false) String name,
            @PathVariable(name = "userId", required = false) Integer userId) {
        if (Objects.nonNull(name) && !name.isEmpty()) {
            if (Objects.nonNull(userId)) {
                return "Hello " + name + "with ID: " + userId + ", it's Now: " + LocalDateTime.now();
            } else {
                return "Hello " + name + ", it's Now: " + LocalDateTime.now();
            }
        } else {
            return "Hello, it's Now: " + LocalDateTime.now();
        }
    }

}
