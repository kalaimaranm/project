package in.bassure.skilling.s8.spring_web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/viewUsers")
    public String viewUsers(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "viewUsersPage";
    }

    @GetMapping("/addUserForm")
    public String newUserForm(Model model) {
        model.addAttribute("user", new User());
        return "addUser";
    }

    @PostMapping("/addUser")
    public String addNewUser(@ModelAttribute("user") User user, BindingResult bResult) {
        System.out.println(user);
        if (user.getName().length() < 3) {
            bResult.addError(new ObjectError("user.name", "Name too short"));
        }

        if (bResult.hasErrors()) {
            return "addUser";
        }
        userService.addNewUser(user);
        return "redirect:viewUsers";
    }

    @PostMapping("/addUser1")
    public String addNewUser1(@ModelAttribute("user") User user) {
        System.out.println(user);
        if (user.getName().length() < 3) {
            throw new IllegalArgumentException("Name is too small");
        }
        return "addUser";
    }

    @ExceptionHandler({IllegalArgumentException.class, NumberFormatException.class})
    public void handleExceptions(Throwable ex) {
        ex.printStackTrace();

    }
}
