package in.bassure.skilling.s8.spring_web;

public class User {

    private int userId;
    private String _name;
    private String planType;

    public User() {
        super();
    }

    @Override
    public String toString() {
        return "User{" + "userId=" + userId + ", _name=" + _name + ", planType=" + planType + '}';
    }

    public User(int userId, String name, String planType) {
        this.userId = userId;
        this._name = name;
        this.planType = planType;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return _name;
    }

    public void setName(String name) {
        this._name = name;
    }

    public String getPlanType() {
        return planType;
    }

    public void setPlanType(String planType) {
        this.planType = planType;
    }

}
