package in.bassure.skilling.s8.spring_web;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UsersRepository usersRepo;
    
    public boolean addNewUser(User user){
        return usersRepo.addNewUser(user);
    }
    
    public List<User> getAllUsers(){
        return usersRepo.getUsers();
    }
}
