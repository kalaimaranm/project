package com.kalai.hibernate.springhibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringhibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
