package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.AddressDAO;
import com.mycompany.khattabookweb.model.Customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
//import khatta.dao.AddressDAO;
//import khatta.dao.KhattaBookDAO;
//import khatta.model.Customer;

public class AddressDAOImpl implements AddressDAO {

    @Override
    public boolean insertAddress(Customer cus) {
        boolean isAddressCreated = false;
        String addInsert = "insert into kh_address values(?,?,?,?,?,?)";
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            PreparedStatement addPst = con.prepareStatement(addInsert);

            //assing customer address data
            addPst.setString(1, cus.getAddress().getDoorno());
            addPst.setString(2, cus.getAddress().getStreetname());
            addPst.setString(3, cus.getAddress().getCity());
            addPst.setString(4, cus.getAddress().getPincode());
            addPst.setInt(5, cus.getCustomerId());
            addPst.setString(6, cus.getCustomerId() + " add");
            //addPst.executeUpdate();

            if (addPst.executeUpdate() > 0) {
                isAddressCreated = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();

        }

        return isAddressCreated;
    }

    @Override
    public boolean updateAddress(Customer cus) {

        boolean isAddressUpdated = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String query = "update kh_address set door_no=?,street_name=?,city=?,pincode=? where customer_id=?";

            PreparedStatement addPst = con.prepareStatement(query);

            addPst.setString(1, cus.getAddress().getDoorno());
            addPst.setString(2, cus.getAddress().getStreetname());
            addPst.setString(3, cus.getAddress().getCity());
            addPst.setString(4, cus.getAddress().getPincode());
            addPst.setInt(5, cus.getCustomerId());

            isAddressUpdated = addPst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return isAddressUpdated;
    }

}
