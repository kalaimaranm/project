package com.mycompany.khattabookweb.dao;

import com.mycompany.khattabookweb.model.Customer;


public interface AddressDAO {

    public boolean insertAddress(Customer customer);

    public boolean updateAddress(Customer cus);

//    public void viewAAddress(int customerId);
//    public void viewAAddress(String phoneNumber);
    //public void viewAAddress();
    //public boolean updateCustomerName(String name);
    //public boolean updateCustomerPhoneNumber(String number);
//    public boolean updateDoorNo(String doornumber);
//    public boolean updateStreetName(String streetName);
//    public boolean updateCity(String city);
//    public boolean updatePincode(int pincode);
    //public boolean updateGender(String gender);
}
