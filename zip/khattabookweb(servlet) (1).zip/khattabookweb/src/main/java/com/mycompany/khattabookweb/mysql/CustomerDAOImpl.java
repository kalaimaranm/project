package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.CustomerDAO;
import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.model.Customer;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
//import khatta.dao.CustomerDAO;
//import khatta.dao.KhattaBookDAO;
//import khatta.model.Customer;
//import khatta.util.Design;

public class CustomerDAOImpl implements CustomerDAO {

    @Override
    public int getCustomerCount() {
        int count = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String countQuery = "select count(*) from kh_customers";
            PreparedStatement countPst = con.prepareStatement(countQuery);
            ResultSet rs = countPst.executeQuery();
            rs.next();
            count = rs.getInt(1);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public boolean isCustomerExists(int customerId) {
        boolean isExists = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String countQuery = "select count(*) from kh_customers where customer_id=?";
            PreparedStatement pst = con.prepareStatement(countQuery);

            pst.setInt(1, customerId);
            ResultSet rs = pst.executeQuery();
            rs.next();

            isExists = rs.getInt(1) > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isExists;

    }

    @Override
    public boolean addCustomerBalance(int customerId, double totalPrice) {
        boolean isPriceAdded = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String balanceAdded = "update kh_customers set balance=? where customer_id=?";
            PreparedStatement pst = con.prepareStatement(balanceAdded);
            pst.setDouble(1, totalPrice);
            pst.setInt(2, customerId);

            isPriceAdded = pst.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e);
        }

        return isPriceAdded;
    }

    @Override
    public int getLastId() {
        int id = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String countQuery = "select customer_id from kh_customers";
            PreparedStatement countPst = con.prepareStatement(countQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = countPst.executeQuery();
            rs.last();
            id = rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    @Override
    public boolean insertCustomer(Customer cus, KhattaBookDAO mydb) {
        boolean isCustomerCreated = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String cusInsert = "insert into kh_customers values(?,?,?,?,?,?)";

            PreparedStatement cusPst = con.prepareStatement(cusInsert);

            //assing customer data
            cusPst.setInt(1, cus.getCustomerId());
            cusPst.setBoolean(2, cus.getStatus());
            cusPst.setString(3, cus.getName());
            cusPst.setString(4, cus.getPhonenumber());
            cusPst.setDouble(5, cus.getBalance());
            cusPst.setString(6, cus.getGender());
            //cusPst.executeUpdate();

            //update query
            if (cusPst.executeUpdate() > 0) {
                if (mydb.getAddress().insertAddress(cus)) {

                    isCustomerCreated = true;
                } else {
                    String delCus = "delete from kh_customers where customer_id=?";
                    PreparedStatement delPst = con.prepareStatement(delCus);
                    delPst.setInt(1, cus.getCustomerId());
                    delPst.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isCustomerCreated;
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        boolean isDeleted = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {

            String delete = "update kh_customers set status=0 where customer_id=?";
            PreparedStatement delPst = con.prepareStatement(delete);
            delPst.setInt(1, customerId);
            isDeleted = delPst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isDeleted;
    }

    @Override
    public List<Customer> viewAllCustomer() {
        List<Customer> customers = new ArrayList<>();
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {

            String cus_query = "select * from kh_customers where status=1";
            String add_query = "select * from kh_address";

            PreparedStatement cus_pst = con.prepareStatement(cus_query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            PreparedStatement add_pst = con.prepareStatement(add_query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

            ResultSet cusRs = cus_pst.executeQuery();
            ResultSet addRs = add_pst.executeQuery();

            while (cusRs.next()) {
                addRs.next();

                while (cusRs.getInt(1) != addRs.getInt(5)) {
                    addRs.next();
                }

                int customerId = cusRs.getInt(1);
                boolean status = cusRs.getBoolean(2);
                String name = cusRs.getString(3);
                String phone = cusRs.getString(4);
                double balance = cusRs.getDouble(5);
                String gender = cusRs.getString(6);

                String doorNo = addRs.getString(1);
                String street = addRs.getString(2);
                String city = addRs.getString(3);
                String pincode = addRs.getString(4);

                customers.add(new Customer(status, name, phone, doorNo, street, city, pincode, customerId, balance, 0, gender));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }

    @Override
    public Customer viewACustomer(int customerId) {
        Customer customer = null;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String cusQuery = "select * from kh_customers where customer_id=?";
            String addQuery = "select * from kh_address where customer_id=?";

            PreparedStatement cusPst = con.prepareStatement(cusQuery);
            PreparedStatement addPst = con.prepareStatement(addQuery);

            cusPst.setInt(1, customerId);
            addPst.setInt(1, customerId);

            ResultSet cusRs = cusPst.executeQuery();
            ResultSet addRs = addPst.executeQuery();

            while (cusRs.next()) {
                addRs.next();

                while (cusRs.getInt(1) != addRs.getInt(5)) {
                    addRs.next();
                }

                boolean status = cusRs.getBoolean(2);
                String name = cusRs.getString(3);
                String phone = cusRs.getString(4);
                double balance = cusRs.getDouble(5);
                String gender = cusRs.getString(6);

                String doorNo = addRs.getString(1);
                String street = addRs.getString(2);
                String city = addRs.getString(3);
                String pincode = addRs.getString(4);

                customer = new Customer(status, name, phone, doorNo, street, city, pincode, customerId, balance, 0, gender);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }

    @Override
    public int getCustomerIdByPhonenumber(String phonenumber) {
        int customerId = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String query = "select customer_id from kh_customers where phonenumber=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, phonenumber);

            ResultSet rs = pst.executeQuery();

            rs.next();
            customerId = rs.getInt(1);

        } catch (SQLException e) {
            System.out.println(e);
        }
        return customerId;
    }

    @Override
    public boolean updateCustomer(Customer cus, KhattaBookDAO mydb) {
        boolean isUpdated = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {

            String query = "update kh_customers set customer_name=?,phonenumber=?,gender=? where customer_id=?";
            PreparedStatement updPst = con.prepareStatement(query);
            updPst.setString(1, cus.getName());
            updPst.setString(2, cus.getPhonenumber());
            updPst.setString(3, cus.getGender());
            updPst.setInt(4, cus.getCustomerId());

            isUpdated = updPst.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e);
        }

        return isUpdated & (mydb.getAddress().updateAddress(cus));

    }

//    @Override
//    public boolean updateCustomer(Customer cus, int column, KhattaBookDAO mydb) {
//        boolean isUpdated = false;
//        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
//            if (column < 7) {
//
//                String updateColumn = "";
//                String newValue = "";
//
//                switch (column) {
//                    case 3:
//                        updateColumn = "customer_name";
//                        newValue = "'" + cus.getName() + "'";
//                        break;
//                    case 4:
//                        updateColumn = "phonenumber";
//                        newValue = "'" + cus.getPhonenumber() + "'";
//                        break;
//                    case 6:
//                        updateColumn = "gender";
//                        newValue = "'" + cus.getGender() + "'";
//                        break;
//
//                }
//                String query = "update kh_customers set " + updateColumn + "=" + newValue + " where customer_id=?";
//                PreparedStatement updPst = con.prepareStatement(query);
//                updPst.setInt(1, cus.getCustomerId());
//
//                isUpdated = updPst.executeUpdate() > 0;
//
//            } else {
//
//                isUpdated = mydb.getAddress().updateAddress(cus, column - 6);
//
//            }
//
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//
//        return isUpdated;
//    }
}
