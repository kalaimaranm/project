package com.mycompany.khattabookweb.util;

import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.model.Customer;
import com.mycompany.khattabookweb.model.Orders;
import com.mycompany.khattabookweb.model.Stock;
import com.mycompany.khattabookweb.mysql.MysqlKhattaBookDAOImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;
//import khatta.dao.KhattaBookDAO;
//import khatta.main.CustomerMenu;
//import khatta.model.Customer;
//import khatta.model.Orders;
//import khatta.mysql.MysqlKhattaBookDAOImpl;

public class Testing {

    public static void main(String[] args) {
        List<Stock> stocks=new MysqlKhattaBookDAOImpl().getStock().getStockHistory(501);
        System.out.println(stocks);
    }
    
    
    public static void main5(String[] args) {
        
        Testing test=new Testing();
        
        test.updateAddress(new Customer());
    }
     
    public boolean updateAddress(Customer cus) {

        boolean isAddressUpdated = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String query = "update kh_address set door_no=?,street_name=?,city=?,pincode=? where customer_id=?";

            PreparedStatement addPst = con.prepareStatement(query);
            System.out.println(cus);

            addPst.setString(1, "88");
            addPst.setString(2, "Ponneri");
            addPst.setString(3, "chennai");
            addPst.setString(4,"623423");
            addPst.setInt(5, 1008);

            isAddressUpdated = addPst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return isAddressUpdated;
    }

    
    
    
    
    
    public static void main4(String[] args) {
        
        //CustomerMenu cm=new CustomerMenu();
        KhattaBookDAO mydb=new MysqlKhattaBookDAOImpl();
        Orders order=mydb.getOrders().getOrder(601, mydb);
        
        //cm.printBill(mydb, order);
        
    }
    
    public static void main3(String[] args) {
        System.out.println("Testing");
        System.out.println(Design.CORRECT+"Testing"+Design.RESET);
        System.out.println(Design.HEAD+"Testing");
        System.out.println(Design.HEAD+"\u2620");
        
    }
    
    public static void main2(String[] args) {
        int[] i = new int[3];

        System.out.println(Arrays.toString(i));

        addFive(i);

        System.out.println(Arrays.toString(i));

    }

    private static void addFive(int[] i) {

        i[0] = 10;
        i[1] = 20;
        i[2] = 30;

    }

    public int getCustomerCount() {
        int count = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {

            String countQuery = "select customer_id from kh_customers";
            PreparedStatement countPst = con.prepareStatement(countQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = countPst.executeQuery();
            con.close();
            rs.last();
            count = rs.getInt(1);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    public void viewCustomer(Customer cus) {
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {

            String column = "";
            String value = "";
            if (cus.getCustomerId() > 0) {

                column = "customer_id";
                value = cus.getCustomerId() + "";
            } else {
                column = "phonenumber";
                value = cus.getPhonenumber();

            }
            String query = "select * from kh_customers where " + column + "=" + value;

            ResultSet cusRs = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE).executeQuery(query);
            cusRs.next();
            ResultSet addRs = con.createStatement().executeQuery("select * from kh_address where customer_id=" + cusRs.getInt(1));
            cusRs.previous();

            if (cusRs.next()) {
                addRs.next();
                System.out.printf("\n|%-5d|%-15s|%-12s|%-7s|%-25s|%-8s|%-8d|%9.2f|",
                        cusRs.getInt(1), cusRs.getString(3), cusRs.getString(4), addRs.getString(1), addRs.getString(2), addRs.getString(3), addRs.getInt(4), cusRs.getDouble(5));
            } else {
                System.out.println("rs empty...!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main1(String[] args) {
        Testing t = new Testing();
//        Customer cus = new Customer();
//        //cus.setCustomerId(1010);
//        //System.out.println(t.getCustomerCount());
//        cus.setPhonenumber("9876543210");
//        t.viewCustomer(cus);
//System.out.println(t.getCustomerCount());
//System.out.println(new MysqlKhattaBookDAOImpl().getStock().getLastId());
        for (String a : args) {
            System.out.println(a);
        }
        System.out.println(args.length);

    }

}
