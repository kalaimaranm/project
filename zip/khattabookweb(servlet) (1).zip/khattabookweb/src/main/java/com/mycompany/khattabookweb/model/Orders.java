package com.mycompany.khattabookweb.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Orders {

    private final int ORDERID;
    private final int CUSID;
    private double totalprice;
    private LocalDate orddate;

    private List<LineItems> itemList;

    public Orders() {
        this.ORDERID = 0;
        this.CUSID = 0;
    }

    public Orders(int ORDERID, int CUSID, LocalDate dat) {
        this.ORDERID = ORDERID;
        this.CUSID = CUSID;
        this.orddate = dat;
        this.itemList = new ArrayList();
        this.totalprice = 0;
    }

     public void setTotalPrice(double totprice) {
        this.totalprice += totprice;
    }
    
    public LocalDate getOrddate() {
        return orddate;
    }

    public void setOrddate(LocalDate orddate) {
        this.orddate = orddate;
    }

    public List<LineItems> getItemList() {
        return itemList;
    }

    public void setItemList(List<LineItems> itemList) {
        this.itemList = itemList;
    }

    public Orders(int ORDERID, int CUSID, LocalDate dat, double totalprice) {
        this(ORDERID, CUSID, dat);
        this.totalprice = totalprice;
        this.itemList = new ArrayList();

    }

    public double getTotalPrice() {
        return totalprice;
    }

   

    public LocalDate getDate() {
        return orddate;
    }

    public int getORDERID() {
        return ORDERID;
    }

    @Override
    public String toString() {
        return "Orders{" + "ORDERID=" + ORDERID + ", CUSID=" + CUSID + ", totalprice=" + totalprice + ", orddate=" + orddate + ", itemList=" + itemList + '}';
    }

    public int getCUSID() {
        return CUSID;
    }

//    public double getPrice(int p, ShopData sd) {
//        double pri = 0;
//        for (int i = 0; i < sd.prods.length; i++) {
//            if (sd.prods[i].getPRODUCTID() == p) {
//                pri = sd.prods[i].getPrice();
//            }
//        }
//        return pri;
//    }
//    public String getName(int a, ShopData sd) {
//        String res = "";
//
//        for (int i = 0; i < sd.prods.length; i++) {
//            if (sd.prods[i].getPRODUCTID() == a) {
//                res = sd.prods[i].getProductName();
//                break;
//            }
//        }
//        return res;
//    }
}
