package com.mycompany.khattabookweb.model;

import java.io.Serializable;

public class Customer 
//        implements Serializable, Comparable 
{

    private boolean status = true;

    private String name;
    private String phonenumber;
    private Address address;
    private int customerId;
    private double balance;
    private double paid;
    private String gender;

    public Customer(int customerId, String name, String phonenumber, String doorno, String streetname, String city, String pincode, String gender) {
        this.customerId = customerId;
        this.name = name;
        //this.phonenumber = new String[1];
        this.phonenumber = phonenumber;
        this.address = new Address(doorno, streetname, city, pincode);
        this.gender = gender;
    }

    public Customer(boolean status, String name, String phone, String dno, String strname, String city, String pincode, int cusId, double balance, double paid, String gender) {
        this(cusId, name, phone, dno, strname, city, pincode, gender);
        this.status = status;
        this.balance = balance;
        this.paid = paid;
    }

    public Customer(int customerId, String name, String phonenumber, String doorno, String streetname, String city, String pincode, double balance, String gender) {
        this(customerId, name, phonenumber, doorno, streetname, city, pincode, gender);
        this.balance = balance;
    }

    public Customer() {
        this.customerId = 0;
        this.name = "";
        //this.phonenumber = new String[1];

        this.address = new Address(null, null, null, null);
        this.gender = null;
    }

    public Customer(int customerId, boolean status, String name, String phonenumber, double balance, String gender) {
        this.customerId = customerId;
        this.status = status;
        this.name = name;
        this.phonenumber = phonenumber;
        this.balance = balance;
        this.gender = gender;
    }

//    public String[] addphonenum() {
//        String[] tem = phonenumber;
//        phonenumber = new String[phonenumber.length + 1];
//        for (int i = 0; i < tem.length; i++) {
//            phonenumber[i] = tem[i];
//        }
//        return phonenumber;
//    }
    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setPaid(double paid) {
        this.paid = paid;
    }

    public double getPaid() {
        return paid;
    }

    public String getName() {
        return name;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public Address getAddress() {
        return address;
    }

    public double getBalance() {
        return balance;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String toString() {
        return String.format("\n|%-5s|%-15s|%-12s|%-7s|%-25s|%-8s|%-8s|%9.2f|",
                customerId, name, phonenumber,
                address.getDoorno(), address.getStreetname(), address.getCity(), address.getPincode(), balance);

    }

//    @Override
//    public String toString() {
//        return "Customer{" + "status=" + status + ", name=" + name + ", phonenumber=" + phonenumber + ", address=" + address + ", customerId=" + customerId + ", balance=" + balance + ", paid=" + paid + ", gender=" + gender + '}';
//    }
    

//    public int compareTo(Customer t) {
//        return this.customerId < t.customerId ? -1 : 1;
//    }
//    @Override
//    public int compareTo(Object t) {
//        if (t instanceof Customer cus) {
//            return this.customerId - cus.customerId;
//        }
//        return 0;
//    }
}
