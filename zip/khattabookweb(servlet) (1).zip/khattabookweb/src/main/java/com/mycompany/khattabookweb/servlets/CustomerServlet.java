/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.khattabookweb.servlets;

import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.model.Customer;
import com.mycompany.khattabookweb.model.LineItems;
import com.mycompany.khattabookweb.model.Orders;
import com.mycompany.khattabookweb.model.Product;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

public class CustomerServlet extends GenericServlet {

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {

        PrintWriter pw = response.getWriter();
        String opt = "";
        int id = 0;
        id = Objects.nonNull(request.getParameter("id")) ? Integer.parseInt(request.getParameter("id")) : 0;
        opt = request.getParameter("opt");

        switch (opt) {
            case "add":
                if (addCustomer(request, response)) {
                    pw.print("<h1 style='color:#0f0;'>Customer Successfully Added...</h1>");
                } else {
                    pw.print("<h1 style='color:#f00;'>Customer Registration failed...</h1>");
                }
                break;
            case "view":
                viewCustomers(request, response);
                break;
            case "view1":
                viewCustomer(id, response);
                break;
            case "delete":
                if (DbSelectorServlet.getMydb().getCustomer().deleteCustomer(id)) {
                    pw.print("<h1 style='color:#0f0;'>Customer Successfully Deleted...</h1>");
                } else {
                    pw.print("<h1 style='color:#f00;'>Customer Deletion failed..</h1>");
                }
                break;
            case "update":
//                pw.print("<h1>" + request.getParameter("id") + "</h1>");

                Customer cus = DbSelectorServlet.getMydb().getCustomer().viewACustomer(Integer.parseInt(request.getParameter("id")));

                customerData(cus, pw);
                break;
            case "filter":
                int filterId = Integer.parseInt(request.getParameter("findId"));
                if (DbSelectorServlet.getMydb().getCustomer().isCustomerExists(filterId)) {
                    viewCustomer(filterId, response);
                } else {
                    pw.print("<h1 style='color:#f00;'>Customer not available...</h1>");
                }
                break;

            case "edit":
                if (editCustomer(request, id)) {
                    pw.print("<h1 style='color:#0f0;'>Customer successfully Updated...</h1>");
                } else {
                    pw.print("<h1 style='color:#f00;'>Customer updation failed..</h1>");
                }

                break;
            case "orderpage":
                addItems(request, id, pw);

                break;
            case "placeorder":
                orderPlacing(request, pw);

                break;
            default:
                pw.print(request.getParameter("id"));
                pw.print("Invalid input");

        }

//        DbSelectorServlet.getMydb();
    }

    private boolean addCustomer(ServletRequest request, ServletResponse response) {
        boolean status = true;
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        double balance = 0;
        String gender = request.getParameter("gender");
        String doorno = request.getParameter("doorno");
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        String pincode = request.getParameter("pincode");

        int id = 1001;
        if ((DbSelectorServlet.getMydb().getCustomer().getCustomerCount()) > 0) {
            id = DbSelectorServlet.getMydb().getCustomer().getLastId() + 1;
        }
        Customer customer = new Customer(status, name, phone, doorno, street, city, pincode, id, balance, 0, gender);
        return DbSelectorServlet.getMydb().getCustomer().insertCustomer(customer, DbSelectorServlet.getMydb());

    }

    private void viewCustomers(ServletRequest request, ServletResponse response) throws IOException {
        PrintWriter pw = response.getWriter();
        List<Customer> customerList = DbSelectorServlet.getMydb().getCustomer().viewAllCustomer();

        pw.print("""
                 <head>
                  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
                 </head>
                 
                 <style>
                 *{
                   margin:0;
                  padding:0;
                 }
                div{
                   display:flex;
                   justify-content:space-around;
                 }
                 div main {
                   padding:20px;
                   height:600px;
                   width:60%;
                   overflow-y:scroll;
                 }
                 div main table{
                      margin:40px;
                      border:1px dotted #777;
                      border-radius:10px;
                      font-size:18px;
                 
                 
                 }
                 div main table tr{
                      border:1px solid #777;
                 }
                 div main table tr td a{
                   text-decoration:none;
                   padding:4px 8px;
                   border-radius:5px;
                   color:#fff;
                 }
                 .view{
                    background-color:28b006;
                 }
                 .view:hover{
                    color:#000;
                 }
                 .delete{
                    background-color:fe2b01;
                 }
                 .delete:hover{
                    color:#000;
                 }
                 .edit{
                    background-color:#2424f7;
                    color:#fff;
                 }
                 aside{
                    height:200px;
                    margin:auto;
                    text-align:center;
                 }
                 aside a i{
                 font-size:40px;
                 }
                 aside a{
                 color:#000;
                 text-decoration:none;
                 
                 }
                 div aside section{
                   height:70px;
                    padding:5px;
                   margin:20px 0;
                 }
                 div aside section:hover{
                    border:1px solid #777;
                    border-radius:8px;
                               }
                 div aside a:active{
                        color:#2424f7;
                             }
                 div aside form input{
                          width:145px;
                          height:30px;
                        font-size:17px;
                 }
                 .back{
                   position:absolute;
                   left:5px;
                   top:-10px;
                   text-decoration:none;
                   padding:6px 8px;
                   border-radius:5px;
                   border:1px dotted;
                   margin:30px;
                  color:#000;
                   
                 }
                 </style>
                 """);

        pw.print("<div>"
                + "<a class=\"back\" href='dbselection'><i class=\"fa-regular fa-circle-left\"></i> Back</a>"
                + "<main>");
        pw.print("<table  cellpadding=5px cellspacing=10px >");
        pw.print("<tr><th>Id</th><th>Name</th><th>PhoneNumber</th><th>Door  no</th><th>Street name</th><th>City</th><th>Pincode</th></tr>");
        for (Customer customer : customerList) {
            pw.print("<tr><td>" + customer.getCustomerId() + "</td><td>" + customer.getName() + "</td><td>"
                    + customer.getPhonenumber() + "</td><td>" + customer.getAddress().getDoorno() + "</td><td>"
                    + customer.getAddress().getStreetname() + "</td><td>" + customer.getAddress().getCity() + "</td><td>"
                    + customer.getAddress().getPincode() + "</td> <td><a href='customercrud?opt=view1&id="
                    + customer.getCustomerId() + "'class='view' >viewdetails</a></td>  <td><a href='customercrud?opt=delete&id="
                    + customer.getCustomerId() + "'class='delete' onclick=conf() >delete</a></td>  <td><a href='customercrud?opt=update&id="
                    + customer.getCustomerId() + "' class='edit'>edit</a></td> <tr>");
        }
        pw.print("</table></main>");

        pw.print("""
         <aside>
                 <section>
         <a href="AddCustomerForm.html"><i class="fa-solid fa-user-plus"></i><h3>NewCustomer</h3></a>
                 </section>
         <form action="customercrud?opt=filter" method="post">
         <input type="text" placeholder="customerId" name="findId"/>
         <input type="submit" value= "find"/>
         </form>
         </aside>
         """);
        pw.print("</div>");
    }

    private void viewCustomer(int id, ServletResponse response) throws IOException {
        PrintWriter pw = response.getWriter();
        pw.print("<h1></h1>");

        Customer customer = DbSelectorServlet.getMydb().getCustomer().viewACustomer(id);

        if (customer.getStatus()) {
            pw.print(customer);

            pw.print("""
                  <head>
                      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
                  </head>   
                     
                  <style>
                     *{
                          margine:0;
                          padding:0;
                     }
                      div{
                          width:98%;
                          height:90vh;
//                          border:1px solid;
                          display:flex;
                          justify-content:center;
                     
                           }
                     section{
                             border:1px dotted;
                             width:30%;
                             height:50%;
                             margin:10% 0;
                             border-radius:10px;
                     }
                     i{
                             font-size:40px;
                                          
                           }
                     h3{
                     margin:0;
                     }
                     footer{
                             margin:100px 0;
                             display:flex;
                             justify-content:space-around;
                     }     
                     a{
                       text-decoration:none;
                       color:#000;
                       text-align:center;
                       padding:8px;
                       
                     } 
                     a:hover{
                       border:1px solid;
                       border-radius:8px;
                     }
                     a:active{
                       color:#2424f7;
                     
                     }
                     .balance{
                        color:#28b006;
                     }
                  </style>
                     """);

            pw.print(""" 
                      
                     <body>
                     <div>
                     <section>
                     <h4>%d</h4>
                     <center>   <h1>%s</h1>
                                <h1 class="balance">&#8377 %.2f</h1></center>
                     <footer>
                     <a href="customercrud?opt=orderpage&id=%d"><i class="fa-solid fa-cart-shopping"></i><h3>NewOrder</h3></a>
                     <a href="customercrud?opt=orderpage&id=%d"><i class="fa-solid fa-boxes-stacked"></i><h3>OrderHistory</h3></a>
                     </footer>
                     </section>
                     </div>
                     </body>
                     """.formatted(customer.getCustomerId(), customer.getName(), customer.getBalance(), customer.getCustomerId(), customer.getCustomerId()));

        } else {
            pw.print("<h1 style='color:#f00;'>Customer not available...</h1>");
        }
    }

    private void customerData(Customer cus, PrintWriter pw) throws IOException {

        pw.print("""
                     
                   <style>
             
                  .Registeration{
                                 display: flex;
                                 justify-content: center;
                                 align-items: center;
                                 font-size:17px;
                                 height: inherit;
//                                 border:1px dotted;
                                     
                 }
                
                 form{
                     border:1px dotted;
                     border-radius:10px;
                 }
                .buttons{
                     margin: 20px;
                     position: relative;
                     left: 60px;
                         }
                .buttons input{
                     border-radius:10px;
                     margin: 0 20px;
                     cursor: pointer;
                     font-size: 18px;
                     padding:6px;
                     border:none;
                             }
                 
                form input[type="submit"]{
                     background-color:#28b006;
                     color:#fff;
                        }
                form input[type="button"]{
                      background-color:#b02806;
                      color:#fff;
                                  
                              }
                 
                 form input[type="radio"]{
                                 width:20px;
                                 height:20px;
                             }
                             .name,.phone{
                                 display: inline-block;
                             }
                             .gender{
                                 padding:20px;
                             }
                             label{
                                 font-size: 20px;
                             }
                             form input[type="text"]{
                                 height:36px;
                                 width:190px;
                                 font-size: 17px;
                                 border-radius:10px;
                                 background: transparent;
                                 text-indent:6px;
                                 border:1px dotted #777;
                                 outline: none;
                             }
                             form input[type="text"]:focus~.title,form input[type="text"]:valid~.title {
                                 font-size:15px;
                                 top:-8px;
                                 color:#000;
                                 background-color: #fff;
                                 z-index: 1;
                                 transition:0.5s;
                          }
                 
                                      form div{
                                          margin:10px;
                                          position: relative;
                                      }
                                      .title{
                                          color:#777;
                                          position:absolute;
                                          left:7px;
                                          top:10px;
                                          z-index: -1;
                                          transition:0.5s;
                                      }
                 
                 
                 
                                  
                   </style>
                 <main>
                 <div class="Registeration">
                    <form action="customercrud?opt=edit&id=%d" method="post">
                         <h1><center>Update Form</center></h1>
                                         <div><input type="text" name="name" value=%s /><label class="title">CustomerName</label></div>
                                         <div><input type="text" name="phone" value=%s /><label class="title">Phonenumber</label></div>
                         
                                         <div class="gender">
                                             <label>Gender</label><br/>
                                             <p id="getgender">%s</p>
                                             <label for="Male">Male</label><input type="radio" name="gender" value="M" id="Male" />
                                             <label for="Female">Female</label><input type="radio" name="gender" value="F" id="Female"/>
                                             <label for="Other">Other</label><input type="radio" name="gender" value="O" id="Other"/>
                                         </div>
                         
                                         <div class="Address">
                                             <label>Address</label><br/>
                                             <div><input type="text"  class="name" name="doorno" value=%s /><label class="title">Door no</label></div>
                                             <div><input type="text"  class="name" name="street" value=%s /><label class="title">Street name</label></div>
                                             <div><input type="text" class="name" name="city" value=%s /><label class="title">City</label></div>
                                             <div><input type="text" class="name" name="pincode" value=%s /><label class="title">Pincode</label></div>
                                         </div>
                                         <div class="buttons">
                         
                                             <input type="submit" value="Submit"/>
                                             <input type="button" value="Cancel"/>
                         
                         
                                         </div>
                    </form>
                 </div>
                 </main>
                         """.formatted(cus.getCustomerId(), cus.getName(), cus.getPhonenumber(), cus.getGender(), cus.getAddress().getDoorno(), cus.getAddress().getStreetname(), cus.getAddress().getCity(), cus.getAddress().getPincode()));

        pw.print("""
                         <script>
                         var gender=document.getElementById("getgender").innerText;
                         
                         if(gender=="M"){
                         document.getElementById("Male").checked=true;
                         }else if(gender=="F"){
                         document.getElementById("Female").checked=true;
                         }else if(gender=="O")
                         {
                         document.getElementById("Other").checked=true;
                         }
                         document.getElementById("getgender").innerText="";
                         
                         </script>
                         """);

    }

    private boolean editCustomer(ServletRequest request, int id) {

        Customer cus = new Customer(id, request.getParameter("name"), request.getParameter("phone"), request.getParameter("doorno"), request.getParameter("street"), request.getParameter("city"), request.getParameter("pincode"), request.getParameter("gender"));
        return DbSelectorServlet.getMydb().getCustomer().updateCustomer(cus, DbSelectorServlet.getMydb());

    }

    private void addItems(ServletRequest request, int id, PrintWriter pw) {

        pw.print("""
                 <head>
                   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
                 </head> 
                 <style>
                    .container{
                      border:1px solid;
                      display:flex;
                      justify-cotent:space-around;
                      width:100%;
                      height:80vh;
                 }
                 main{
                   overflow-x:scroll;
                 }
                 
                 main,aside{
                 border:1px solid;
                 width:50%;
                 } 
                 
                 article{
                     padding:5px;
                     display:inline-block;
                 }
                 article lable,article input[type="text"]{
                 font-size:17px;
                 }
                 form input[type="submit"]{
                    background-color:28b006;
                    font-size:16px;
                    color:#fff;
                    border:none;
                    border-radius:5px;
                    cursor:pointer;
                    padding:4px;
                 }
                 aside{
                    overflow-x:scroll;
                 }
                 .cart{
                     margin:30px 0 0 60px;
                 }
//                 .cart th, .cart td{
//                      padding:10px 20px;
//                 }
                 
                 table{
                       margin:40px;
                       border:1px dotted #777;
                       border-radius:10px;
                       font-size:18px;
                       }
                 
                 i{
                    cursor:pointer;
                   font-size:17px;
                   color:#2424f7;
                 }
                 aside table tr td input{
                       font-size:16px;
                       width:60px;
                 }
                 
                 
                 </style>
                 """);
        pw.print("<h1>Available Products</h1>");
        Customer customer = DbSelectorServlet.getMydb().getCustomer().viewACustomer(id);
        List<Product> products = DbSelectorServlet.getMydb().getProduct().viewProduct();
        pw.print("<div class='container'>");
        pw.print("<main>");
        pw.print("<table cellpadding=5px cellspacing=10px >");
        pw.print("<tr> <th>ProductId</th>  <th>Brand</th> <th>ProductName</th>  <th>Price</th>  <th>Availability</th></tr>");
        for (Product prod : products) {
            pw.print("""
                 <tr> <td>%d</td> <td>%s</td> <td>%s</td> <td>%.2f</td> 
                     <td>%d</td> 
                     <td><button onclick=addcart(%d,%d) type="button"><i class="fa-solid fa-cart-plus"></i></button></td> </tr>
                 """.formatted(prod.getPRODUCTID(), prod.getBRAND(), prod.getProductName(),
                    prod.getPrice(), prod.getAvailable(), prod.getPRODUCTID(), prod.getAvailable()));
        }
        pw.print("</table>");
        pw.print("</main>");
        
        pw.print("<aside>");
        pw.print("<form action='customercrud?opt=placeorder' method='post'>");
        pw.print("<article><lable>Customer Id :</lable><input type='text' value=%d name='customerId' readonly /> </article> ".formatted(id));
        pw.print("<article><lable>Customer Name :</lable><input type='text' value=%s name='customername' readonly /></article> ".formatted(customer.getName()));
        pw.print("<article><lable>Order Date :</lable><input type='text' value=%s name='orderdate' readonly /></article>".formatted(LocalDate.now()));
//        pw.print("<a href='customercrud?opt=placeorder'>Place Order</a>");
        pw.print("<input type=submit value='PlaceOrder'  />");
        pw.print("""
                 <table id="items"  class="cart" cellpadding=5px cellspacing=10px>
                 <tr> <th>Product Id</th> <th>Quantity</th> </tr>
                 </table>
                 </form>
                </aside>
        </div>
                  <script>
                  function addcart(id,available){
                
                  
                  const added=document.getElementById("items");
                 
                  const item=document.createElement("tr");
                  const itemid=document.createElement("td");
                  const quan=document.createElement("td");
                  const removeitem=document.createElement("td");
                 
                  const textid=document.createElement("input");
                  const textqu=document.createElement("input");
                  const removebutton=document.createElement("button");
                 
                  const removelogo=document.createElement("i");
                 
                  removebutton.onclick=function(){
                         this.closest("tr").remove();
//                 document.write(this);
                 }
                 
                  removelogo.class="fa-solid fa-trash"
                 
                  removebutton.type="button";
                 removebutton.innerText="Remove";
                 
                  textid.name="item";
                  textid.value=id;
                  textid.readOnly=true;
                 
                 textqu.name="quantity";
                 textqu.type="number";
                 textqu.min=1;
                 textqu.max=available;

                 removebutton.appendChild(removelogo);
                 
                  added.appendChild(item);
                  item.appendChild(itemid).appendChild(textid);
                  item.appendChild(quan).appendChild(textqu);
                  item.appendChild(removeitem).appendChild(removebutton);
                
//                  document.write(this);
                
                 
                 }
                 
                 function del(obj){
                 document.write(obj);
                 }
                 
                  function conf(){
                  alert("deleting");
                  } 
                 
                </script>
                 """);

    }

    private void orderPlacing(ServletRequest request, PrintWriter pw) {

//        pw.print("OrdetPlaced...");
        String[] productids = request.getParameterValues("item");
        String[] quantities = request.getParameterValues("quantity");
        int customerId = Integer.parseInt(request.getParameter("customerId"));
        LocalDate date = LocalDate.parse(request.getParameter("orderdate"));
        int orderid = 601;

        pw.print("<h1>OrderPlaced</h1>");

        if (DbSelectorServlet.getMydb().getOrders().getOrderCount() > 0) {
            orderid = DbSelectorServlet.getMydb().getOrders().getLastId() + 1;
        }
        pw.print(date);

        Orders orders = new Orders(orderid, customerId, date);

        for (int i = 0; i < productids.length; i++) {
//        int prodId,int quantity,double eachprice
            int prodId = Integer.parseInt(productids[i]);
            int quantity = Integer.parseInt(quantities[i]);
            double eachprice = DbSelectorServlet.getMydb().getProduct().getPrice(prodId);
            LineItems lineitem = new LineItems(prodId, quantity, eachprice);
            orders.getItemList().add(lineitem);
        }

        orders.setTotalPrice(orders.getItemList().stream().mapToDouble(n -> n.getPrice()).sum());

        KhattaBookDAO mydb = DbSelectorServlet.getMydb();

        mydb.getOrders().insertOrder(orders, mydb);
        mydb.getCustomer().addCustomerBalance(customerId, orders.getTotalPrice());

        for (LineItems item : orders.getItemList()) {
            mydb.getProduct().deductQuantity(item.getProdId(), item.getQuantity());
        }

        pw.print("<table rules='all' cellpadding=5px>");

        pw.print("<tr> <td>ProductId</td> <td>Name</td> <td>EachPrice</td> <td>Quantity</td> <td>Price</td> </tr>");

        for (LineItems item : orders.getItemList()) {
//            mydb.getProduct().deductQuantity(item.getProdId(), item.getQuantity());
            pw.print("<tr> <td>%d</td> <td>%s</td> <td>%.2f</td> <td>%d</td> <td>%.2f</td>  </tr>"
                    .formatted(item.getProdId(), mydb.getProduct().getProductName(item.getProdId()), item.getEachprice(), item.getQuantity(), item.getPrice()));
        }

        pw.print("</table>");
        pw.print(orders.getTotalPrice());
    }

}
