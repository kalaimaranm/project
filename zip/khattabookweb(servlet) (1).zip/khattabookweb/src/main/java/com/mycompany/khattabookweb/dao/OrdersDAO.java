package com.mycompany.khattabookweb.dao;

import com.mycompany.khattabookweb.model.Orders;


public interface OrdersDAO {
    
    public int getOrderCount();

    public int getLastId();
    
    public boolean insertOrder(Orders order,KhattaBookDAO mydb);
    
    public Orders getOrder(int OrderId,KhattaBookDAO mydb);
    
}
