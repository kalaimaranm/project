/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.khattabookweb.util;

/**
 *
 * @author bas200192
 */
public class Design {
    
    public static final String RESET = "\033[0m";
    public static final String LINE = "\033[0;37m";
    public static final String HEAD = "\033[44m";
    public static final String WRONG = "\033[0;31m";
    public static final String CORRECT="\033[0;32m";
    
}
