package com.mycompany.khattabookweb.model;

import java.io.Serializable;

public class Address implements Serializable{

      private String doorno;
      private String streetname,city;
      private String pincode;

    public String getDoorno() {
        return doorno;
    }

    public void setDoorno(String doorno) {
        this.doorno = doorno;
    }

    public String getStreetname() {
        return streetname;
    }

    public void setStreetname(String streetname) {
        this.streetname = streetname;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
      
      Address(String doorno,String streetname,String city,String pincode){
        
          this.doorno=doorno;
          this.streetname=streetname;
          this.city=city;
          this.pincode=pincode;
      }
    
}
