
package com.mycompany.khattabookweb.model;

public class LineItems {

     int prodId;
     int quantity;
     double eachprice;
     double price;
     
     LineItems()
     {}
     
    public LineItems(int prodId,int quantity,double eachprice){
     this.prodId=prodId;
     this.quantity=quantity;
     this.eachprice=eachprice;
     this.price=eachprice*quantity;
     }

    public int getProdId() {
        return prodId;
    }

    public void setProdId(int prodId) {
        this.prodId = prodId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getEachprice() {
        return eachprice;
    }

    public void setEachprice(double eachprice) {
        this.eachprice = eachprice;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
     
     
     
     
     
     
     public String toString(){
         
     return String.format("|%-7d|%-9d|%10.2f|%9.2f|",prodId,quantity,eachprice,(quantity*eachprice));
     
     }
    
}
