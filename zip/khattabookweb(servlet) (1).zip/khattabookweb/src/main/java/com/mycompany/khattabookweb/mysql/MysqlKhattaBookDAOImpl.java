package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.AddressDAO;
import com.mycompany.khattabookweb.dao.CustomerDAO;
import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.dao.LineItemsDAO;
import com.mycompany.khattabookweb.dao.OrdersDAO;
import com.mycompany.khattabookweb.dao.PaymentDAO;
import com.mycompany.khattabookweb.dao.ProductDAO;
import com.mycompany.khattabookweb.dao.StockDAO;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import com.mysql.cj.jdbc.exceptions.CommunicationsException;

//import khatta.dao.AddressDAO;
//import khatta.dao.CustomerDAO;
//import khatta.dao.KhattaBookDAO;
//import khatta.dao.LineItemsDAO;
//import khatta.dao.OrdersDAO;
//import khatta.dao.PaymentDAO;
//import khatta.dao.ProductDAO;
//import khatta.dao.StockDAO;

public class MysqlKhattaBookDAOImpl implements KhattaBookDAO {

    @Override
    public CustomerDAO getCustomer() {
        return new CustomerDAOImpl();
    }

    @Override
    public AddressDAO getAddress() {
        return new AddressDAOImpl();
    }

    @Override
    public LineItemsDAO getLineItems() {
        return new LineItemsDAOImpl();
    }

    @Override
    public OrdersDAO getOrders() {
        return new OrdersDAOImpl();
    }

    @Override
    public PaymentDAO getPayment() {
        return new PaymentDAOImpl();
    }

    @Override
    public ProductDAO getProduct() {
        return new ProductDAOImpl();
    }

    @Override
    public StockDAO getStock() 
    {

        //Object o = Class.forName("StockDAOImpl").newInstance();
        return new StockDAOImpl();
        //StockDAO stk = StockDAOImpl.class.cast(o);
        //return stk;

    }

   public static Connection getConnection() throws SQLException {
        try {
            String url = "jdbc:mysql://bassure.in:3306/nebula_8";
            String user = "arunnn";
            String pass = "arun123";
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            return DriverManager.getConnection(url, user, pass);
        } catch (CommunicationsException  come) {
            System.out.println("Please check your internet connection...");
        }catch(ClassNotFoundException cnfe){
            System.out.println(cnfe);
        }
        return null;
    }

}
