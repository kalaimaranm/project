package com.mycompany.khattabookweb.model;

import java.time.LocalDate;

public class Stock {

    int loadQuantity;
    LocalDate loaddate;
    double buyingPrice;
    int stockId;
    int productId;

    public Stock(int loadQuantity, LocalDate loaddate, double buyingPrice, int prodId, int stockId) {
        this.loadQuantity = loadQuantity;
        this.buyingPrice = buyingPrice;
        this.loaddate = loaddate;
        this.productId = prodId;
        this.stockId = stockId;
    }

    public int getStockId() {
        return stockId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setStockId(int stockId) {
        this.stockId = stockId;
    }

    public LocalDate getLoaddate() {
        return loaddate;
    }

    public void setLoaddate(LocalDate loaddate) {
        this.loaddate = loaddate;
    }

    public double getBuyingPrice() {
        return buyingPrice;
    }

    public void setBuyingPrice(double buyingPrice) {
        this.buyingPrice = buyingPrice;
    }

    public int getLoadQuantity() {
        return loadQuantity;
    }

    public void setLoadQuantity(int loadQuantity) {
        this.loadQuantity = loadQuantity;
    }

    @Override
    public String toString() {
        return "Stock{" + "loadQuantity=" + loadQuantity + ", loaddate=" + loaddate + ", buyingPrice=" + buyingPrice + ", stockId=" + stockId + ", productId=" + productId + '}';
    }

}
