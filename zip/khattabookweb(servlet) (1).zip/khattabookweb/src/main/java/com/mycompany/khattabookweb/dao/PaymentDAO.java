package com.mycompany.khattabookweb.dao;

public interface PaymentDAO {
    
}
