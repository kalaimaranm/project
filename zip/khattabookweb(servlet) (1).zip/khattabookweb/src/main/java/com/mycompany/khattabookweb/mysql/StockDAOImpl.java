package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.dao.StockDAO;
import com.mycompany.khattabookweb.model.Stock;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
//import khatta.dao.KhattaBookDAO;
//import khatta.dao.StockDAO;
//import khatta.model.Product;
//import khatta.model.Stock;

public class StockDAOImpl implements StockDAO {

    @Override
    public int getStockCount() {
        int count = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String countQuery = "select count(*) from kh_stock";
            PreparedStatement countPst = con.prepareStatement(countQuery);
            ResultSet rs = countPst.executeQuery();
            rs.next();
            count = rs.getInt(1);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public int getLastId() {
        int id = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String idQuery = "select * from kh_stock";
            PreparedStatement countPst = con.prepareStatement(idQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = countPst.executeQuery();
            rs.last();
            id = rs.getInt(5);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    @Override
    public boolean insertStock(Stock stock, KhattaBookDAO mydb) {
        boolean isStockInserted = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String insertStock = "insert into kh_stock values(?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(insertStock);

            pst.setInt(1, stock.getProductId());
            pst.setDate(2, Date.valueOf(stock.getLoaddate()));
            pst.setDouble(3, stock.getBuyingPrice());
            pst.setInt(4, stock.getLoadQuantity());
            pst.setInt(5, stock.getStockId());

            isStockInserted = pst.executeUpdate() > 0 & mydb.getProduct().addQuantity(stock.getProductId(), stock.getLoadQuantity());

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isStockInserted;
    }

    @Override
    public boolean loadStock(Stock stock, KhattaBookDAO mydb) {
        boolean isLoaded = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String stockLoadQuery = "insert into kh_stock values(?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(stockLoadQuery);
            pst.setInt(1, stock.getProductId());
            pst.setDate(2, Date.valueOf(stock.getLoaddate()));
            pst.setDouble(3, stock.getBuyingPrice());
            pst.setInt(4, stock.getLoadQuantity());
            pst.setInt(5, stock.getStockId());

            isLoaded = pst.executeUpdate() > 0 && mydb.getProduct().addQuantity(stock.getProductId(), stock.getLoadQuantity());

        } catch (SQLException e) {
            System.out.println(e);
        }
        return isLoaded;
    }

    @Override
    public Stock getLastStock(int id) {
        Stock stock = null;
        String query = "select * from kh_stock where product_id=? order by loaddate limit 1";

        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, id);

            ResultSet rs = pst.executeQuery();
                rs.next();

                int productid = rs.getInt(1);
                LocalDate loaddate = rs.getDate(2).toLocalDate();
                double buyingprice = rs.getDouble(3);
                int quantity = rs.getInt(4);
                int stockid = rs.getInt(5);

                stock = new Stock(quantity, loaddate, buyingprice, productid, stockid);
            
        } catch (SQLException e) {
            System.out.println(e);
        }
        return stock;
    }

    @Override
    public List<Stock> getStockHistory(int id) {
        List<Stock> stocks = new ArrayList<>();
        String query = "select * from kh_stock where product_id=? order by loaddate";
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {

                int productid = rs.getInt(1);
                LocalDate date = rs.getDate(2).toLocalDate();
                double buyingprice = rs.getDouble(3);
                int quantity = rs.getInt(4);
                int stockId = rs.getInt(5);

                stocks.add(new Stock(quantity, date, buyingprice, productid, stockId));
            }

        } catch (SQLException e) {
            System.out.println(e);
        }

        return stocks;
    }

}
