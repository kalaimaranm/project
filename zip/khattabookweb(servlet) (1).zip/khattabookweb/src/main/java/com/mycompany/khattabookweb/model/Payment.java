package com.mycompany.khattabookweb.model;

import java.time.LocalDate;

public class Payment {

    private int paymentId;
    private LocalDate paydate;
    private double amount;
    private int customerId;

    public Payment(int paymentId, double amount, int customerId) {
        this.paymentId = paymentId;
        this.paydate = LocalDate.now();
        this.amount = amount;
        this.customerId = customerId;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public LocalDate getPaydate() {
        return paydate;
    }

    public void setPaydate(LocalDate paydate) {
        this.paydate = paydate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getAmt() {
        return amount;
    }

    public void setAmt(double amt) {
        this.amount = amt;
    }

}
