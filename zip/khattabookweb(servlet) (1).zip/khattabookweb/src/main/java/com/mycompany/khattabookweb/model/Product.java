package com.mycompany.khattabookweb.model;

import java.time.LocalDate;
import java.util.Arrays;

public class Product {

    private int PRODUCTID;
    private String BRAND;
    private double price;
    private String productName;
    int available;
    public Stock stock;

//    public Product(int productId, String productName, double price, String BRAND) {
//        this.PRODUCTID = productId;
//        this.productName = productName;
//        this.price = price;
//        this.BRAND = BRAND;
//    }
    //create new product
    public Product(int productId, String productName, double price, String BRAND, int quantity, double buyingprice,int stockId) {
       this(productId,productName,price,BRAND,quantity);
        stock = new Stock(quantity, LocalDate.now(), buyingprice,productId,stockId);

    }

//reloading constructor
    public Product(int productId, String productName, double price, String BRAND, int available) {
        this.PRODUCTID=productId;
        this.productName=productName;
        this.price=price;
        this.BRAND=BRAND;
        this.available=available;
    }
    
    
    
    public void setBRAND(String BRAND) {
        this.BRAND = BRAND;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setAvailable(int available) {
        this.available = available;
    }

    public void setStock(Stock stock) {
        this.stock = stock;
    }

//    public Product() {
//        PRODUCTID = 0;
//        BRAND = "";
//        this.stock = new Stock[this.stockload.length + 1];
//
//    }
//    Product(int productid, String brand, double price, String productname, int available) {
//        this.PRODUCTID = productid;
//        this.BRAND = brand;
//        this.price = price;
//        this.productName = productname;
//        this.available = available;
//
//    }
    public void setPRODUCTID(int PRODUCTID) {
        this.PRODUCTID = PRODUCTID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getPRODUCTID() {
        return PRODUCTID;
    }

    public String getBRAND() {
        return BRAND;
    }

    public int getAvailable() {
        return available;
    }

    public Stock getStock() {
        return stock;
    }

    @Override
    public String toString() {

        return String.format("\n|%-8d|%-20s|%-20s|%8s|%-14s|", PRODUCTID, BRAND, productName, price, available);
    }

}
