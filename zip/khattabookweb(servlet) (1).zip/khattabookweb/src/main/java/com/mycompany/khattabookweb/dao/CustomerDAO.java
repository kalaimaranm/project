package com.mycompany.khattabookweb.dao;

import com.mycompany.khattabookweb.model.Customer;
import java.util.List;


public interface CustomerDAO {

    public int getCustomerCount();

    public int getLastId();

    public boolean isCustomerExists(int customerId);
    
    public boolean addCustomerBalance(int customerId,double totalPrice);
    
    public int getCustomerIdByPhonenumber(String phonenumber);

    public boolean insertCustomer(Customer customer, KhattaBookDAO mydb);

    public boolean deleteCustomer(int customerId);

    public List<Customer> viewAllCustomer();

    public Customer viewACustomer(int customerId);

//    public boolean updateCustomer(Customer cus, int column, KhattaBookDAO mydb);
    public boolean updateCustomer(Customer cus,KhattaBookDAO mydb);

}
