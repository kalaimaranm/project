package com.mycompany.khattabookweb.dao;

import com.mycompany.khattabookweb.model.Stock;
import java.util.List;


public interface StockDAO {
    public int getStockCount();
    
    public int getLastId();
    
    public boolean insertStock(Stock stock,KhattaBookDAO mydb);
    
    public boolean loadStock(Stock stock,KhattaBookDAO mydb);
    
    public Stock getLastStock(int id);
    
    public List<Stock> getStockHistory(int id);
    
    
    
}
