package com.mycompany.khattabookweb.dao;

public interface KhattaBookDAO{
    
    public CustomerDAO getCustomer();
    public AddressDAO getAddress();
    public LineItemsDAO getLineItems();
    public OrdersDAO getOrders();
    public PaymentDAO getPayment();
    public ProductDAO getProduct();
    public StockDAO getStock();
}
