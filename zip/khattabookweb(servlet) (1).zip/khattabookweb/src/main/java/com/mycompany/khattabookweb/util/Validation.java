package com.mycompany.khattabookweb.util;

import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
//import khatta.dao.KhattaBookDAO;

public class Validation {

    public static BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));

    //validated integer input
    public static int readInput() throws IOException {
        String opt = "";
        while (true) {
            opt = scan.readLine();
            if (opt.matches("[0-9]+")) {
                break;
            } else {
                System.out.println(Design.WRONG + "Please Enter Numeric Input...!" + Design.RESET);
            }
        }
        return Integer.parseInt(opt);
    }

    //validated characters string
    public static String readName() throws IOException {
        String name = "";
        while (true) {
            System.out.print("\nEnter the customerName :");
            name = scan.readLine();
            if (name.matches("[a-zA-Z]+")) {
                break;
            } else {
                System.out.println(Design.WRONG + "Please enter valid Input...!" + Design.RESET);
            }
        }
        return name;
    }

    //method to getiing pincode
    public static String readPincode() throws IOException {
        String pin = "";
        while (true) {
            System.out.println("\nEnter pincode :");
            pin = scan.readLine();
            if (pin.matches("[0-9]{6}")) {
                break;
            } else {
                System.out.println(Design.WRONG + "Please enter valid Input...!" + Design.RESET);
            }
        }
        return pin;
    }

    //method to getting phone number
    static public String readPhoneNumber() throws IOException {
        String phone = "";
        while (true) {
            System.out.print("\nEnter the phonenumber :");
            phone = scan.readLine();
            if (phone.matches("[0-9]{10}")) {
                break;
            } else {
                System.out.println(Design.WRONG + "Please enter valid Input...!" + Design.RESET);
            }
        }
        return phone;
    }

    //method to getting gender
    public static String readGender() throws IOException {
        int gen = 0;
        while (true) {
            System.out.print("\nSelect your gender :");
            System.out.print("\n1.Male");
            System.out.print("\n2.Female");
            System.out.print("\n3.Others\n");

            gen = readInput();
            if ((gen >= 1) && (gen <= 3)) {
                break;
            }
        }
        return gen == 1 ? "M" : gen == 2 ? "F" : "O";
    }

    //validated double input
    public static double readPrice() throws IOException {
        double price = 0;
        while (true) {
            try {
                price = Double.parseDouble(scan.readLine());
                if (price >= 0) {
                    break;
                } else {
                    throw new NumberFormatException();
                }

            } catch (InputMismatchException | NumberFormatException e) {

                System.out.println(Design.WRONG + "Please enter number Input..." + Design.RESET);
            }
        }
        return price;
    }

//    //method to get product Id to check
    public static int readProductId(KhattaBookDAO mydb) throws IOException {
        int prodId = 0;

        while (true) {
            System.out.print("\nEnter ProductId :");
            prodId = readInput();

            if (mydb.getProduct().isProductExists(prodId)) {

                break;

            } else {
                System.out.println(Design.WRONG + "Product Id not available..." + Design.RESET);
            }
        }

        return prodId;
    }
//
    //get quantity
//    public int getQuantity(int proid, List<Orderlist> ltmlst) throws IOException {
//        int qua = 0;
//        if (prod_Con.getQua(proid) > 0) {
//            while (true) {
//                System.out.println("Enter the quantity");
//                qua = getInput();
//
//                int avai_Stock = getAvaiStock(proid, ltmlst);
//                if (qua <= avai_Stock) {
//                    break;
//                } else {
//                    System.out.println("Your product not that much quantity available...");
//                }
//            }
//        }
//        return qua;
//    }

//    public int getAvaiStock(int proid, List ltmlst) {
//        int avaiqua = prod_Con.getQua(proid);
//        Iterator lst = ltmlst.iterator();
//        while (lst.hasNext()) {
//            if (lst.next() instanceof Orderlist ls) {
//                if (ls.getProdId() == proid) {
//                    avaiqua = avaiqua - ls.quantity;
//
//                }
//            }
//
//        }
//        return avaiqua;
//    }
//
//    public void printBill(Customer cus, List ltmlst, Orders ord) throws SQLException {
//        System.out.print("\n+" + "-".repeat(76) + "+");
//        System.out.format("\n|%2s %-16s %-8s %7s|%s%38s|", " ", "Customer Name :", cus.getName(), " ", "/", " ");
//        System.out.format("\n|%2s %-16s %-8.2f %7s|%s%33s|", " ", "Old Balance :", cus.getBalance(), " ", "\\ mart", " ");
//        System.out.print("\n+" + "-".repeat(76) + "+");
//
//        System.out.format("\n|%-4s|%-11s|%-20s|%-15s|%-9s|%-12s|",
//                "S.No", "ProductId", "Product Name", "Price of each", "Quantity", "Price");
//        System.out.print("\n+" + "-".repeat(76) + "+");
//
//        Iterator lsit = ltmlst.iterator();
//        int i = 1;
//
//        while (lsit.hasNext()) {
//            if (lsit.next() instanceof Orderlist ls) {
//
//                System.out.format("\n|%-4d|%-11d|%-20s|%-15.2f|%-9d|%12.2f|",
//                        (i++),
//                        ls.getProdId(), prod_Con.getProdname(ls.getProdId()),
//                        prod_Con.getPrice(ls.getProdId()), ls.quantity, ls.price);
//            }
//        }
//        System.out.print("\n+" + "-".repeat(76) + "+");
//        System.out.format("\n|%s%53s|%12.2f|", ord.orddate, "Total", ord.totalprice);
//        System.out.print("\n+" + "-".repeat(76) + "+");
//
//    }
}
