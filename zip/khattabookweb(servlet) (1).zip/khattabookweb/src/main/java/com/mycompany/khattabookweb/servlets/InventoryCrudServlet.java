package com.mycompany.khattabookweb.servlets;

import com.mycompany.khattabookweb.model.Product;
import com.mycompany.khattabookweb.model.Stock;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

public class InventoryCrudServlet extends GenericServlet {

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {

        String opt = request.getParameter("opt");
        int productid = Objects.nonNull(request.getParameter("id")) ? Integer.parseInt(request.getParameter("id")) : 0;
        PrintWriter pw = response.getWriter();
//        pw.print(opt);
        switch (opt) {
            case "Inventory":
                getProducts(pw);
                break;
            case "addstock":
                getStockDetails(pw, productid);
                break;
            case "updatestock":
                if (updateStock(productid, request)) {
                    pw.print("<h1 style='color:#0f0;'>Stock successfully added...</h1>");
                } else {
                    pw.print("<h1 style='color:#f00;'>Action failed</h1>");
                }
                break;
            case "details":
                getStockDetails(productid, pw);
                break;
            case "addproduct":
                if (addNewProduct(pw, request)) {
                    pw.print("<h1 style='color:#0f0;'>Product successfully added...</h1>");
                } else {
                    pw.print("<h1 style='color:#f00;'>Action failed</h1>");
                }

                break;
            default:
                pw.print("<h1>Option not available</h1>");
        }

    }

    private void getProducts(PrintWriter pw) {

        List<Product> products = DbSelectorServlet.getMydb().getProduct().viewProduct();
        pw.print("<div>");
        pw.print("<table rules='all' cellpadding='10'>");
        pw.print("<tr> <th>ProductId</th>  <th>Brand</th> <th>ProductName</th>  <th>Price</th>  <th>Availability</th></tr>");
        for (Product prod : products) {
            pw.print("""
                 <tr> <td>%d</td> <td>%s</td> <td>%s</td> <td>%.2f</td> <td>%d</td> <td><a href='inventorycrud?opt=details&id=%d'>Stockdetails</a></td><td><a href='inventorycrud?opt=addstock&id=%d'>Addstock</a></td> </tr>
                 """.formatted(prod.getPRODUCTID(), prod.getBRAND(), prod.getProductName(), prod.getPrice(), prod.getAvailable(), prod.getPRODUCTID(), prod.getPRODUCTID()));
        }
        pw.print("</table>");

        pw.print("""
         <section>
          <a href="newproductform.html">New Product</a>
         </section>
         """);

        pw.print("<div>");
    }

    private void getStockDetails(PrintWriter pw, int id) {
        pw.print("<h1>Stock load</h1>");
        String productName = DbSelectorServlet.getMydb().getProduct().getProductName(id);
        Stock laststock = DbSelectorServlet.getMydb().getStock().getLastStock(id);

        pw.print("""
                 <form method="post" action="inventorycrud?opt=updatestock&id=%d">
                 
                    <label>ProductId</label><input type="text" readonly value=%d />
                    <label>ProductName</label><input type="text" readonly value=%s />
                    <br>
                 
                    <label>Load date</label><input type="text" readonly name="date" value="%s" />
                    <br>
                 
                    <label>Quantity</label><input type="text" name="quantity" />
                    <label>Buying price</label><input type="text" name="price" value="%.2f" />
                    <br>
                   <input type="submit" value="Add Stock" />
                   <input type="button" value="cancel" />
                 </form>
                 """.formatted(id, id, productName, LocalDate.now(), laststock.getBuyingPrice()));
    }

    private boolean updateStock(int id, ServletRequest request) {

        int quantity = Integer.parseInt(request.getParameter("quantity"));
        LocalDate date = LocalDate.parse(request.getParameter("date"));
        double price = Double.parseDouble(request.getParameter("price"));
        int stockid = DbSelectorServlet.getMydb().getStock().getLastId() + 1;
        Stock stock = new Stock(quantity, date, price, id, stockid);

        return DbSelectorServlet.getMydb().getStock().insertStock(stock, DbSelectorServlet.getMydb());

    }

    private void getStockDetails(int id, PrintWriter pw) {

        List<Stock> stocks = DbSelectorServlet.getMydb().getStock().getStockHistory(id);
        pw.print("<h1>" + DbSelectorServlet.getMydb().getProduct().getProductName(id) + "</h1>");
        pw.print("<table rules='all' cellpadding='5'>");
        pw.print("<tr> <th>Load date</th> <th>Buying price</th> "
                + "<th>Quantity</th> <th>Stock id</th> </tr>");
        for (Stock stock : stocks) {
            pw.print("""
                  <tr> <td>%s</td> <td>%.2f</td> 
                       <td>%d</td> <td>%d</td> </tr>
                  """.formatted(stock.getLoaddate(), stock.getBuyingPrice(), stock.getLoadQuantity(), stock.getStockId()));
        }
        pw.print("</table>");
    }

    private boolean addNewProduct(PrintWriter pw, ServletRequest request) {
        pw.print("<h1>new product</h1>");

        int productid = 501;
        if (DbSelectorServlet.getMydb().getProduct().getProductCount() > 0) {
            productid = DbSelectorServlet.getMydb().getProduct().getLastId() + 1;
        }
        
        String productName = request.getParameter("product");
        String brand = request.getParameter("brand");
        double sellingprice = Double.parseDouble(request.getParameter("sprice"));
        double buyingprice = Double.parseDouble(request.getParameter("bprice"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        int stockid = DbSelectorServlet.getMydb().getStock().getLastId() + 1;

        Product product = new Product(productid, productName, sellingprice, brand, quantity, buyingprice, stockid);
        return DbSelectorServlet.getMydb().getProduct().insertProduct(product, DbSelectorServlet.getMydb());

    }

}
