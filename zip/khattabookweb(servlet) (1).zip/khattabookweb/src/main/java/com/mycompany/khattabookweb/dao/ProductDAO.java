package com.mycompany.khattabookweb.dao;

import com.mycompany.khattabookweb.model.Product;
import java.util.List;


public interface ProductDAO {

    public int getProductCount();

    public int getLastId();
    
    public boolean deductQuantity(int productId, int orderedQuantity);
    
    public double getPrice(int productId);

    public boolean insertProduct(Product prod, KhattaBookDAO mydb);

    public List<Product> viewProduct();

    public boolean isProductExists(int prodId);

    public int getProductQuantity(int prodId);

    public boolean addQuantity(int prodId, int loadQuantity);
    
    public String getProductName(int prodId);
}
