package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.LineItemsDAO;
import com.mycompany.khattabookweb.model.LineItems;
import com.mycompany.khattabookweb.model.Orders;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
//import khatta.dao.LineItemsDAO;
//import khatta.model.LineItems;
//import khatta.model.Orders;

public class LineItemsDAOImpl implements LineItemsDAO {

    @Override
    public boolean insertLineItems(Orders order) {
        boolean isLineItemInserted = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {

            String orderInsertQuery = "insert into kh_itemlist values(?,?,?,?,?)";

            PreparedStatement pst = con.prepareStatement(orderInsertQuery);

            pst.setInt(1, order.getORDERID());

            for (LineItems item : order.getItemList()) {
                pst.setInt(2, item.getQuantity());
                pst.setDouble(3, item.getEachprice());
                pst.setDouble(4, item.getPrice());
                pst.setInt(5, item.getProdId());

                isLineItemInserted = pst.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        return isLineItemInserted;
    }

    public List<LineItems> getLineItems(int orderId) {

        List<LineItems> items = new ArrayList();

        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String lineItemsQuery = "select * from kh_itemlist where order_id=?";
            PreparedStatement pst = con.prepareStatement(lineItemsQuery);
            pst.setInt(1, orderId);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                items.add(new LineItems(rs.getInt(5), rs.getInt(2), rs.getDouble(3)));
            }

        } catch (SQLException e) {
            System.out.println(e);

        }

        return items;
    }

}
