package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.PaymentDAO;


public class PaymentDAOImpl implements PaymentDAO{
    
}
