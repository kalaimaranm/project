package com.mycompany.khattabookweb.servlets;

import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.mysql.MysqlKhattaBookDAOImpl;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class DbSelectorServlet extends GenericServlet {

//    private static KhattaBookDAO mydb = null;
    private static String database;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        String db = this.getServletConfig().getInitParameter("db");
        PrintWriter pw = response.getWriter();
        database = db;

        pw.print("""
                 <head>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
                 </head>
                 <style>
                 *{
                     margin:0;
                     padding:0;

                 }
                   .menu{
                     width:60%;
                     margin:auto;
                     padding:100px;
                 }
             header{
                     width:60%;
                     margin:auto;
                 
                    }
              menu{
                     width:60%;
                     margin:80px auto;
                     padding:10px;
                     border:1px dotted #777;
                     border-radius:15px;
                     display:flex;
                     align-item:center;
                     justify-content:space-around;
                     padding:20px;
                     height:65px;
                 }
                 
                 section{
                    text-align:center;
                    padding:10px;
                    height:50px;
                 }
                 i{
                    font-size:40px;
                 }
                 div menu section a{
                    text-decoration:none;
                    color:#000;
                     
                 }
                 div menu section:hover{

                     border:1px solid #777;
                     border-radius:8px;
                         }
                 div menu section a:active{
                     color:#2424f7;
                 }
                 
                 </style>
                 <div class="menu">
             
                 <header>
                 <img src="Resource/Khatabook.svg.png"  height=150px />
                 </header>
                 
                 <menu>
                 <section>
                    <a href='customercrud?opt=view'><i class="fa-solid fa-users"></i>
                    <h3>Customer</h3></a>
                 </section>
                 
                 <section>
                     <a href='inventorycrud?opt=Inventory'><i class="fa-solid fa-warehouse"></i>
                     <h3>Inventory</h3></a>
                 </section>
                 </menu>
                 
                 
                 </div>
                 """);
    }

    public static KhattaBookDAO getMydb() {
        KhattaBookDAO mydb = null;
//        System.out.println(database+"$".repeat(10));
        switch (database) {

            case "Mysql":
                mydb = new MysqlKhattaBookDAOImpl();
//                    System.out.println(database + "$".repeat(30));
                break;

            case "MongoDb":
//                    System.out.println(database + "&".repeat(30));
                break;
            default:
//                    System.out.println(database + "#".repeat(30));
            }
        return mydb;
    }

}
