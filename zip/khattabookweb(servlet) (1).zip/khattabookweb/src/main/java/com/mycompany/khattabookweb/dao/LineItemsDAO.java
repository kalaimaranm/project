package com.mycompany.khattabookweb.dao;

import com.mycompany.khattabookweb.model.LineItems;
import com.mycompany.khattabookweb.model.Orders;
import java.util.List;


public interface LineItemsDAO {
    
    public boolean insertLineItems(Orders order);
    
    public List<LineItems> getLineItems(int orderId);
    
    
    
}
