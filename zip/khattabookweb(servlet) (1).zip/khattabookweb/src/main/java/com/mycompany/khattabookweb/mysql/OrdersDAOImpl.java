package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.dao.OrdersDAO;
import com.mycompany.khattabookweb.model.Orders;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
//import khatta.dao.KhattaBookDAO;
//import khatta.dao.OrdersDAO;
//import khatta.model.Orders;

public class OrdersDAOImpl implements OrdersDAO {

    @Override
    public int getOrderCount() {
        int count = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String countQuery = "select count(*) from kh_orders";
            PreparedStatement countPst = con.prepareStatement(countQuery);
            ResultSet rs = countPst.executeQuery();
            rs.next();
            count = rs.getInt(1);

        } catch (SQLException e) {
            System.out.println(e);
        }
        return count;
    }

    @Override
    public int getLastId() {
        int id = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String countQuery = "select order_id from kh_orders";
            PreparedStatement countPst = con.prepareStatement(countQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = countPst.executeQuery();
            rs.last();
            id = rs.getInt(1);
        } catch (SQLException e) {
            System.out.println(e);
        }
        return id;

    }

    @Override
    public boolean insertOrder(Orders order, KhattaBookDAO mydb) {
        boolean isOrderInserted = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String orderInsertQuery = "insert into kh_orders values(?,?,?,?)";

            PreparedStatement pst = con.prepareStatement(orderInsertQuery);
            pst.setInt(1, order.getORDERID());
            pst.setInt(2, order.getCUSID());
            pst.setDate(3, Date.valueOf(order.getDate()));
            pst.setDouble(4, order.getTotalPrice());

            if (pst.executeUpdate() > 0) {
                isOrderInserted = mydb.getLineItems().insertLineItems(order);
            }

        } catch (SQLException e) {
            System.out.println(e);

        }
        return isOrderInserted;

    }

    @Override
    public Orders getOrder(int orderId, KhattaBookDAO mydb) {
        Orders order = null;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String getOrderQuery = "select * from kh_orders where order_id=?";
            PreparedStatement pst = con.prepareStatement(getOrderQuery);
            pst.setInt(1, orderId);

            ResultSet rs = pst.executeQuery();

            rs.next();

            order = new Orders(rs.getInt(1), rs.getInt(2), rs.getDate(3).toLocalDate(), rs.getDouble(4));

            order.setItemList(mydb.getLineItems().getLineItems(orderId));
        } catch (SQLException e) {
            System.out.println(e);

        }

        return order;
    }

}
