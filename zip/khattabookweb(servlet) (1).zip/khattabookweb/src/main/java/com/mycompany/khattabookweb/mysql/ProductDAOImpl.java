package com.mycompany.khattabookweb.mysql;

import com.mycompany.khattabookweb.dao.KhattaBookDAO;
import com.mycompany.khattabookweb.dao.ProductDAO;
import com.mycompany.khattabookweb.model.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//import khatta.dao.KhattaBookDAO;
//import khatta.dao.ProductDAO;
//import khatta.model.Product;

public class ProductDAOImpl implements ProductDAO {

    @Override
    public int getProductCount() {
        int count = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String countQuery = "select count(*) from kh_products";
            PreparedStatement countPst = con.prepareStatement(countQuery);
            ResultSet rs = countPst.executeQuery();
            rs.next();
            count = rs.getInt(1);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public int getLastId() {
        int id = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String idQuery = "select product_id from kh_products";
            PreparedStatement countPst = con.prepareStatement(idQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = countPst.executeQuery();
            rs.last();
            id = rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    @Override
    public boolean insertProduct(Product prod, KhattaBookDAO mydb) {
        boolean isProductInserted = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String prodInsertquery = "insert into kh_products values(?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(prodInsertquery);

            pst.setInt(1, prod.getPRODUCTID());
            pst.setString(2, prod.getBRAND());
            pst.setDouble(3, prod.getPrice());
            pst.setString(4, prod.getProductName());
            pst.setInt(5, 0);

            isProductInserted = pst.executeUpdate() > 0 && mydb.getStock().insertStock(prod.getStock(), mydb);

        } catch (SQLException e) {
            System.out.println(e);
        }

        return isProductInserted;

    }

    @Override
    public List<Product> viewProduct() {
        List<Product> products = new ArrayList<>();
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String viewProductQuery = "select * from kh_products";
            ResultSet productRs = con.prepareStatement(viewProductQuery).executeQuery();
            while (productRs.next()) {
                products.add(new Product(productRs.getInt(1), productRs.getString(4), productRs.getDouble(3), productRs.getString(2), productRs.getInt(5)));
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        return products;

    }

    @Override
    public boolean isProductExists(int prodId) {
        boolean isExists = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String existsQuery = "select count(*) from kh_products where product_id=?";
            PreparedStatement pst = con.prepareStatement(existsQuery);
            pst.setInt(1, prodId);

            ResultSet rs = pst.executeQuery();
            rs.next();
            isExists = rs.getInt(1) > 0;

        } catch (SQLException e) {
            System.out.println(e);
        }
        return isExists;
    }

    @Override
    public int getProductQuantity(int prodId) {
        int quantity = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String quantityQuery = "select available from kh_products where product_id=?";
            PreparedStatement pst = con.prepareStatement(quantityQuery);
            pst.setInt(1, prodId);

            ResultSet rs = pst.executeQuery();
            rs.next();
            quantity = rs.getInt(1);

        } catch (SQLException e) {
            System.out.println(e);
        }

        return quantity;
    }

    @Override
    public boolean addQuantity(int prodId, int loadQuantity) {

        boolean isQuantityAdded = false;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String addQuantityQuery = "update kh_products set available=? where product_id=?";
            PreparedStatement pst = con.prepareStatement(addQuantityQuery);
            pst.setInt(1, getProductQuantity(prodId) + loadQuantity);
            pst.setInt(2, prodId);

            isQuantityAdded = pst.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e);

        }
        return isQuantityAdded;

    }

    @Override
    public double getPrice(int productId) {
        double price = 0;
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String quantityQuery = "select price from kh_products where product_id=?";
            PreparedStatement pst = con.prepareStatement(quantityQuery);
            pst.setInt(1, productId);

            ResultSet rs = pst.executeQuery();
            rs.next();
            price = rs.getInt(1);

        } catch (SQLException e) {
            System.out.println(e);

        }

        return price;
    }

    @Override
    public boolean deductQuantity(int productId, int orderedQuantity) {
        boolean isDeducted = false;

        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String productDeduction = "update kh_products set available=available-? where product_id=?";
            PreparedStatement pst = con.prepareStatement(productDeduction);
//            pst.setInt(1, getProductQuantity(productId) - orderedQuantity);
            pst.setInt(1, orderedQuantity);
            pst.setInt(2, productId);

            isDeducted = pst.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e);
        }

        return isDeducted;
    }

    @Override
    public String getProductName(int prodId) {
        String productName = "";
        try (Connection con = MysqlKhattaBookDAOImpl.getConnection()) {
            String quantityQuery = "select product_name from kh_products where product_id=?";
            PreparedStatement pst = con.prepareStatement(quantityQuery);
            pst.setInt(1, prodId);

            ResultSet rs = pst.executeQuery();
            rs.next();
            productName = rs.getString(1);

        } catch (SQLException e) {
            System.out.println(e);
        }

        return productName;
    }

}
