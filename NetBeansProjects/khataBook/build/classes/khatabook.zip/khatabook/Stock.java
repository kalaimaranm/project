/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package khatabook;
import java.time.LocalDate;
import java.time.LocalTime;
/**
 *
 * @author bas200193
 */
public class Stock {
    LocalDate date;
    LocalTime time;
    int quantity;
    double price;
    double profit;

    public Stock(LocalDate date, LocalTime time, int quantity, double price, double profit) {
        this.date = date;
        this.time = time;
        this.quantity = quantity;
        this.price = price;
        this.profit = profit;
    }
    public Stock(){
        
    }
    
}
