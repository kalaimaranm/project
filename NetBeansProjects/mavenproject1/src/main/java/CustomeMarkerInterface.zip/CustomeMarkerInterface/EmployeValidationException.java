
package CustomeMarkerInterface;

/**
 *
 * @author bas200193
 */
public class EmployeValidationException extends Exception{

    public EmployeValidationException(String message) {
        super(message);
    }
    
}
