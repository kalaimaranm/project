package CustomeMarkerInterface;

/**
 *
 * @author bas200193
 */
public class Checking {

    public static void main(String[] args) throws EmployeValidationException {
        Employe emp = new Employe();
    }
}
