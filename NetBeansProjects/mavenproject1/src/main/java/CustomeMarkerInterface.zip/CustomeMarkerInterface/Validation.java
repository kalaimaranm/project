
package CustomeMarkerInterface;

/**
 *
 * @author bas200193
 */
public interface Validation {
    
}
