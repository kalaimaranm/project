
package CustomeDSA.Stack;

public class StackException {
    
}
