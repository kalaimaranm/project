package khatabook;

public class Data {

}
