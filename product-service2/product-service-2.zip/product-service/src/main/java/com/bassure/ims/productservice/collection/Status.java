package com.bassure.ims.productservice.collection;

public enum Status {

    ACTIVE,
    INACTIVE

}
