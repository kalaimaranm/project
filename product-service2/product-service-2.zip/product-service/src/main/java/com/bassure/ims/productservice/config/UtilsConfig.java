package com.bassure.ims.productservice.config;

import lombok.Getter;

public class UtilsConfig {

    @Getter
    private static final int SUCCESS_CODE = 600;
    @Getter
    private static final int ERROR_CODE = 602;
}
