package com.bassure.ims.productservice.service;

import com.bassure.ims.productservice.request.AssertRequest;
import com.bassure.ims.productservice.response.ResponseEntity;

public interface AssetService {

    public ResponseEntity addAssert(AssertRequest anAssert);

    public ResponseEntity getAssert();

    public ResponseEntity getAssertById(String productId);

    public ResponseEntity getAggregatedProducts();

    public ResponseEntity retrieveAggregatedAssert();

    public ResponseEntity updateAssert(String assertId, AssertRequest anAssertRequest);

    public ResponseEntity deleteAssert(String id);
}
