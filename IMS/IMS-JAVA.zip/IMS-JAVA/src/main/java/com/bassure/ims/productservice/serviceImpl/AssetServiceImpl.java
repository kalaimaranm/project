package com.bassure.ims.productservice.serviceImpl;

import com.bassure.ims.productservice.collection.Asset;
import com.bassure.ims.productservice.config.HttpStatusCode;
import com.bassure.ims.productservice.config.HttpStatusMessage;
import com.bassure.ims.productservice.config.UtilsConfig;
import com.bassure.ims.productservice.config.UtilsResponse;
import com.bassure.ims.productservice.repository.AssertRepository;
import com.bassure.ims.productservice.request.AssertRequest;
import com.bassure.ims.productservice.response.ResponseEntity;
import com.bassure.ims.productservice.service.AssetService;
import com.mongodb.client.result.UpdateResult;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AssetServiceImpl implements AssetService {

    @Autowired
    private AssertRepository assertRepository;

    @Autowired
    private SequenceGeneratorService sequenceGeneratorService;

    @Autowired
    private HttpStatusCode httpStatusCode;

    @Autowired
    private HttpStatusMessage httpStatusMessage;

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public ResponseEntity addAssert(AssertRequest assertsRequest) {
        Asset anAsset = new Asset();
        anAsset.setAssetId(sequenceGeneratorService.generateSequence(UtilsConfig.getASSET_SEQUENCE_NAME()));
        System.out.println(assertsRequest);
        BeanUtils.copyProperties(assertsRequest, anAsset);
        System.out.println(anAsset);
        Asset savedAssert = assertRepository.save(anAsset);
        if (Objects.nonNull(savedAssert.getAssetName())) {
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), httpStatusMessage.getAddMessage());
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getError(), Map.of());
        }
    }

    @Override
    public ResponseEntity getAssert() {
        List<Asset> all = assertRepository.findAll();
        if (!all.isEmpty()) {
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), all);
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getNoData(), Map.of());
        }
    }

    @Override
    public ResponseEntity getAssertById(String productId) {
        Optional<Asset> product = assertRepository.findById(productId);
        if (product.isPresent()) {
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), product);
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getNoData(), Map.of());
        }
    }

    @Override
    public ResponseEntity getAggregatedProducts() {
        List<Asset> assets = assertRepository.retrieveAggregatedProducts();
        if (!assets.isEmpty()) {
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), assets);
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getNoData(), Map.of());
        }
    }

    @Override
    public ResponseEntity retrieveAggregatedAssert() {
        LookupOperation lookupBrand = LookupOperation.newLookup()
                .from("brand")
                .localField("brand_id")
                .foreignField("_id")
                .as("brandData");

        LookupOperation lookupOrder = LookupOperation.newLookup()
                .from("Order")
                .localField("order_id")
                .foreignField("_id")
                .as("orderData");

        UnwindOperation unwindOrder = Aggregation.unwind("orderData");

        List<AggregationOperation> supplierPipeline = new ArrayList<>();
        supplierPipeline.add(Aggregation.replaceRoot("orderData"));

        LookupOperation lookupSupplier = LookupOperation.newLookup()
                .from("supplier")
                .localField("supplier_id")
                .foreignField("_id")
                .as("supplierData");

//        AggregationOperation lookupSupplierOperation = Aggregation.lookup("Order")
//                .applyAggregationOperations(supplierPipeline)
//                .applyAggregationOperation(lookupSupplier)
//                .as("supplierData");
//        Aggregation aggregation = Aggregation.newAggregation(
//                lookupBrand,
//                lookupOrder,
//                unwindOrder,
//                lookupSupplierOperation
//        );
        Aggregation aggregation = null;

        List<Asset> product = mongoTemplate.aggregate(aggregation, "product", Asset.class).getMappedResults();
        if (!product.isEmpty()) {
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), product);
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getNoData(), Map.of());
        }
    }

    @Override
    public ResponseEntity updateAssert(String assertId, AssertRequest anAssertRequest) {
        Optional<Asset> optionalAssert = assertRepository.findById(assertId);
        if (optionalAssert.isPresent()) {
            Asset anAsset = new Asset();
            anAsset.setAssetId(optionalAssert.get().getAssetId());
            BeanUtils.copyProperties(anAssertRequest, anAsset);
            assertRepository.save(anAsset);
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), "updated success");
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getNoData(), Map.of());
        }
    }

    @Override
    public ResponseEntity deleteAssert(String id) {

       if (getAssertById(id).getHeader().getCode() == httpStatusCode.getSuccess()) {

           Query query = new Query(Criteria.where("id").is(id));
           Update update = new Update().set("status", "INACTIVE");
           UpdateResult result = mongoTemplate.updateFirst(query, update, Asset.class);
           if(result.getModifiedCount() > 0) {
               return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), "product deleted successfully id - ");
           }

       }

        return UtilsResponse.responsesEntity(httpStatusCode.getFailed(), Map.of("", "product deleteion failed"));
    }


}
