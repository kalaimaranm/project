package com.bassure.ims.productservice.serviceImpl;

import com.bassure.ims.productservice.collection.Category;
import com.bassure.ims.productservice.config.HttpStatusCode;
import com.bassure.ims.productservice.config.UtilsConfig;
import com.bassure.ims.productservice.config.UtilsResponse;
import com.bassure.ims.productservice.repository.CategoryRepository;
import com.bassure.ims.productservice.request.CategoryRequest;
import com.bassure.ims.productservice.response.ResponseEntity;
import com.bassure.ims.productservice.service.CategoryService;
import com.mongodb.client.result.UpdateResult;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private HttpStatusCode httpStatusCode;

    @Autowired
    private SequenceGeneratorService sequenceGeneratorService;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public ResponseEntity addCategory(CategoryRequest categoryRequest) {
        Category category = new Category();
        category.setCategoryId(sequenceGeneratorService.generateSequence(UtilsConfig.getCATEGORY_SEQUENCE_NAME()));
        System.out.println(category);
        BeanUtils.copyProperties(categoryRequest, category);
        System.out.println(category);
        Category saved = categoryRepository.save(category);
        System.out.println(saved);
        if (!Objects.isNull(saved.getCategoryName())) {
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), "added success");
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getError(), Map.of());
        }
    }

    @Override
    public ResponseEntity getAllCategory() {
//        List<Category> parentCategory = new ArrayList<>();
//        List<Category> subCategory = new ArrayList<>();
//        List<Category> allCategory = categoryRepository.findAll();
//        for (Category ca : allCategory) {
//            if (ca.getParentCategoryId() == null) {
//                parentCategory.add(ca);
//            } else {
//                subCategory.add(ca);
//            }
//        }
//        System.out.println("parentCategory : " + parentCategory);
//        System.out.println("parentCategory : " + subCategory);
        List<Category> categoryList = categoryRepository.findAll();
        if(!categoryList.isEmpty()){
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), categoryList);
        }else {
            return UtilsResponse.responsesEntity(httpStatusCode.getNoData(), Map.of());
        }
    }

    @Override
    public ResponseEntity getCategoryById(String parentId) {
        Optional<List<Category>> parentCategoryId = categoryRepository.findByParentCategoryId(parentId);
        if (parentCategoryId.isPresent()){
            List<Category> getCategory;
            List<Category> all = categoryRepository.findAll();
            if (parentId == null) {
                getCategory = all.stream()
                        .filter(data -> data.getParentCategoryId() == null)
                        .collect(Collectors.toList());
            } else {
                getCategory = all.stream()
                        .filter(data -> data.getParentCategoryId() != null)
                        .collect(Collectors.toList());
            }
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), getCategory);
        }else {
            return UtilsResponse.responsesEntity(httpStatusCode.getError(), Map.of());
        }
    }

    @Override
    public ResponseEntity editCategory(String categoryId, CategoryRequest categoryRequest) {
        Optional<Category> optionalCategory = categoryRepository.findById(categoryId);
        if (optionalCategory.isPresent()) {
            Category category = new Category();
            category.setCategoryId(optionalCategory.get().getCategoryId());
            BeanUtils.copyProperties(categoryRequest, category);
            categoryRepository.save(category);
            return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), "updated success");
        } else {
            return UtilsResponse.responsesEntity(httpStatusCode.getNoData(), Map.of());
        }
    }


    @Override
    public ResponseEntity deleteCategory(String id) {

        if(getCategoryById(id).getHeader().getCode() == httpStatusCode.getSuccess()) {
            Query query = new Query(Criteria.where("id").is(id));
            Update update = new Update().set("status","INACTIVE");
            UpdateResult result = mongoTemplate.updateFirst(query, update, Category.class);
            if(result.getModifiedCount() > 0) {

                return UtilsResponse.responsesEntity(httpStatusCode.getSuccess(), "category deleted successfully id - ");
            }

        }
        return UtilsResponse.responsesEntity(httpStatusCode.getFailed(), "category failed to delete" + id);
    }
}
