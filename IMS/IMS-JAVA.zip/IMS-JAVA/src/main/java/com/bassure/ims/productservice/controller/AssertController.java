package com.bassure.ims.productservice.controller;

import com.bassure.ims.productservice.request.AssertRequest;
import com.bassure.ims.productservice.response.ResponseEntity;
import com.bassure.ims.productservice.service.AssetService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/assert")
public class AssertController {

    @Autowired
    private AssetService assetService;

    @PostMapping("/addassert")
    public ResponseEntity addProduct(@Valid @RequestBody AssertRequest anAssert) {
        return assetService.addAssert(anAssert);
    }

    @GetMapping("/getallassert")
    public ResponseEntity findAllProducts() {
        return assetService.getAssert();
    }

    @GetMapping("assertbyid/{assertId}")
    public ResponseEntity findProductById(@PathVariable String assertId) {
        return assetService.getAssertById(assertId);
    }

//    @GetMapping("/aggregatedProducts")
//    public List<Assert> getAggregatedProducts() {
//        return assertService.getAggregatedProducts();
//    }

    @GetMapping("/aggregatedProducts")
    public ResponseEntity retrieveAggregatedProducts() {
        return assetService.retrieveAggregatedAssert();
    }


    @PutMapping("/updateProduct/{assertId}")
    public ResponseEntity updateAssert(@PathVariable String assertId, @RequestBody AssertRequest anAssertRequest) {
        return assetService.updateAssert(assertId, anAssertRequest);
    }

    @DeleteMapping("/deleteasset/{id}")
    public ResponseEntity deleteAssert(@PathVariable String id) {

        return assetService.deleteAssert(id);
    }

}
