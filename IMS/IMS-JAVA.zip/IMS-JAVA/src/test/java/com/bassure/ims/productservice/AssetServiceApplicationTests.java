package com.bassure.ims.productservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
