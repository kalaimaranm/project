import React from 'react';
import Sidebar from '../Components/sidebar';

export default function Routers() {
    return (
        <>
            <Sidebar />
        </>
    );
}
