export const commonPath = {
    viewAsset : '/',
    addAsset:'/addAsset'
}