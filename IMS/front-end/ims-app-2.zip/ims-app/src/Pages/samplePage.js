import { Box, Button, Card, Typography } from '@mui/material';
import React from 'react';

export default function SamplePage() {
    return (
        <>
            {/* <Typography variant='discountText' >Hello World!</Typography>
            <Card sx={{ backgroundColor: (theme) => theme.palette.neutral[900] }} > mmmmm</Card>
            <Box sx={{ backgroundColor: 'success.dark' }}>kkkkkk</Box>
            <Button variant='outlined'  >gggg</Button>
            <Box sx={{
                height: "100px", width: "200px",
                backgroundColor: 'action.active', boxShadow: (theme) => theme.shadows[1]
            }}>kkkkkk</Box> */}
            <Typography variant=''>jjjjj</Typography>
        </>
    );
}

