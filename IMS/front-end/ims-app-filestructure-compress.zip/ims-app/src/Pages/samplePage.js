import { Typography } from '@mui/material';
import React from 'react';

export default function SamplePage() {
    return ( 
    <Typography variant='h6' color={'primary.main'}>Hello World!</Typography>
    );
}

