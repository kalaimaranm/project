package com.bassure.ims.productservice.serviceImpl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SupplierServiceImplTest {

    @Test
    void addSupplier() {
    }

    @Test
    void getSupplierById() {
    }

    @Test
    void getAllSupplier() {
    }

    @Test
    void deleteSupplierById() {
    }

    @Test
    void updateSupplier() {
    }
}