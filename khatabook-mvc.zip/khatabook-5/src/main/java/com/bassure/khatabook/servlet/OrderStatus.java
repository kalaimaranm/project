package com.bassure.khatabook.servlet;

public enum OrderStatus {

    PENDING,
    ACCEPTED,
    CANCELLED,
    SUCCESSFULL

}
